exports.id=3340,exports.ids=[3340],exports.modules={25:(a,b,c)=>{"use strict";c.d(b,{a:()=>f});var d=c(5735),e=c(31245);function f({data:a}){return(0,d.jsx)("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:(0,e.nK)(a)}})}},297:(a,b,c)=>{"use strict";c.d(b,{Yu:()=>i,dE:()=>k});var d=c(78853),e=c(8313),f=c(64442),g=c(71189);let h=["sku","product_slug","status","name_bn","name_en","short_bn","short_en","size_bn","size_en","categories","price_bdt","sale_price_bdt","stock","featured"],i={path:"/export.csv",method:"get",handler:async a=>{if(!(0,d.hf)(a.user,"admin","manager","editor"))return Response.json({error:"Forbidden"},{status:403});let b=await (0,g.N)(a,()=>a.payload.find({collection:"products",locale:"all",depth:1,limit:5e3,pagination:!1,req:a,overrideAccess:!0})),c=[];for(let a of b.docs){let b=a.categories.map(a=>"object"==typeof a?a.slug:a).join("|");for(let d of a.variants??[])c.push([d.sku,a.slug,a.status,a.name?.bn??"",a.name?.en??"",a.shortDescription?.bn??"",a.shortDescription?.en??"",d.label?.bn??"",d.label?.en??"",b,(0,f.r$)(d.price),(0,f.r$)(d.salePrice),d.stock??0,a.featured?"yes":"no"])}return new Response((0,f.gD)([...h],c),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":`attachment; filename="products-${new Date().toISOString().slice(0,10)}.csv"`,"Cache-Control":"no-store"}})}},j=a=>{let b=a.trim().replace(/,/g,"");if(!b)return null;if(!/^\d+(\.\d{1,2})?$/.test(b))return"invalid";let[c,d=""]=b.split(".");return 100*Number(c)+Number(d.padEnd(2,"0"))},k={path:"/import",method:"post",handler:async a=>{if(!(0,d.hf)(a.user,"admin","manager"))return Response.json({error:"Forbidden"},{status:403});let b=await a.formData?.().catch(()=>null),c=b?.get("file");if(!c||"string"==typeof c)return Response.json({error:'Attach a CSV file in the "file" field.'},{status:400});if(c.size>2097152)return Response.json({error:"CSV is larger than 2 MB."},{status:400});let g=(0,f.Wk)(await c.text()),h=g.shift()?.map(a=>a.trim().toLowerCase())??[],i=["sku","product_slug","name_bn","price_bdt"].filter(a=>!h.includes(a));if(i.length)return Response.json({error:`Missing columns: ${i.join(", ")}`},{status:400});if(g.length>2e3)return Response.json({error:"At most 2000 rows per import."},{status:400});let k=new Map((await a.payload.find({collection:"categories",limit:500,depth:0,pagination:!1,req:a,overrideAccess:!0})).docs.map(a=>[a.slug,a.id])),l=0,m=0,n=[];for(let[b,c]of g.entries()){let d=a=>(c[h.indexOf(a)]??"").trim(),f=b+2;try{let b=d("sku").toUpperCase(),c=(0,e.Y)(d("product_slug")),f=j(d("price_bdt")),g=j(d("sale_price_bdt"));if(!b||!c)throw Error("sku and product_slug are required");if("invalid"===f||null===f||"invalid"===g)throw Error("invalid price");let h=d("categories").split("|").map(a=>k.get(a.trim())).filter(a=>"number"==typeof a),i="published"===d("status")?"published":"draft"===d("status")?"draft":void 0,n=d("featured")?["yes","true","1"].includes(d("featured").toLowerCase()):void 0,o=Math.max(0,Math.floor(Number(d("stock"))||0)),p=await a.payload.find({collection:"products",where:{"variants.sku":{equals:b}},limit:1,depth:0,req:a,overrideAccess:!0,locale:"bn"}),q=p.docs[0]?null:await a.payload.find({collection:"products",where:{slug:{equals:c}},limit:1,depth:0,req:a,overrideAccess:!0,locale:"bn"}),r=p.docs[0]??q?.docs[0];if(!r){if(!h.length)throw Error("new products need at least one valid category slug");let e=await a.payload.create({collection:"products",locale:"bn",req:a,overrideAccess:!0,data:{name:d("name_bn")||d("name_en"),shortDescription:d("short_bn")||void 0,slug:c,status:i??"draft",featured:n??!1,categories:h,variants:[{label:d("size_bn")||d("size_en")||"১টি",sku:b,price:f,salePrice:g??void 0,stock:o}]}});d("name_en")&&await a.payload.update({collection:"products",id:e.id,locale:"en",req:a,overrideAccess:!0,data:{name:d("name_en"),shortDescription:d("short_en")||void 0,variants:(e.variants??[]).map(a=>({...a,label:d("size_en")||a.label}))}}),l++;continue}let s=(r.variants??[]).map(({stock:a,...b})=>({...b})),t=s.find(a=>a.sku===b);if(t?(t.price=f,t.salePrice=g??null,d("size_bn")&&(t.label=d("size_bn"))):s.push({label:d("size_bn")||d("size_en")||b,sku:b,price:f,salePrice:g??null,stock:o}),await a.payload.update({collection:"products",id:r.id,locale:"bn",req:a,overrideAccess:!0,data:{...d("name_bn")?{name:d("name_bn")}:{},...d("short_bn")?{shortDescription:d("short_bn")}:{},...i?{status:i}:{},...void 0!==n?{featured:n}:{},...h.length?{categories:h}:{},variants:s}}),d("name_en")||d("short_en")||d("size_en")){let c=await a.payload.findByID({collection:"products",id:r.id,locale:"en",depth:0,req:a,overrideAccess:!0});await a.payload.update({collection:"products",id:r.id,locale:"en",req:a,overrideAccess:!0,data:{...d("name_en")?{name:d("name_en")}:{},...d("short_en")?{shortDescription:d("short_en")}:{},variants:(c.variants??[]).map(({stock:a,...c})=>c.sku===b&&d("size_en")?{...c,label:d("size_en")}:c)}})}m++}catch(a){n.push(`row ${f}: ${a instanceof Error?a.message:"error"}`)}}return Response.json({created:l,updated:m,errors:n})}}},1935:(a,b,c)=>{"use strict";c.d(b,{AC:()=>o,AF:()=>m,au:()=>k,bQ:()=>n,bZ:()=>l});var d=c(78853),e=c(14915),f=c(8313),g=c(89556),h=c(79252),i=c(99795);let j=(a="published")=>({name:"status",type:"select",required:!0,defaultValue:a,index:!0,options:[{label:"Published",value:"published"},{label:"Hidden (draft)",value:"draft"}],admin:{position:"sidebar"}}),k={slug:"faqs",labels:{singular:"FAQ",plural:"FAQs"},admin:{group:"Content",useAsTitle:"question",defaultColumns:["question","topic","showOnHome","status","translationStatus"]},defaultSort:"sortOrder",access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["question","answer"])]},fields:[{name:"question",type:"text",required:!0,localized:!0,validate:i.E},{name:"answer",type:"textarea",required:!0,localized:!0,validate:i.E},{name:"topic",type:"select",defaultValue:"orders",options:[{label:"Orders",value:"orders"},{label:"Delivery",value:"delivery"},{label:"Packaging",value:"packaging"},{label:"Payment",value:"payment"},{label:"Availability",value:"availability"},{label:"Returns",value:"returns"}],admin:{position:"sidebar"}},{name:"showOnHome",type:"checkbox",defaultValue:!0,admin:{position:"sidebar"}},{name:"sortOrder",type:"number",defaultValue:0,admin:{position:"sidebar"}},j(),(0,g.I)()]},l={slug:"testimonials",labels:{singular:"Customer review",plural:"Customer reviews"},admin:{group:"Content",useAsTitle:"customerName",defaultColumns:["customerName","rating","moderation","consentToPublish","createdAt"],description:"Publish only real reviews from real customers, with their permission."},access:{read:({req:a})=>!!a.user||{and:[{moderation:{equals:"approved"}},{consentToPublish:{equals:!0}}]},create:d.Xl,update:d.Xl,delete:d.Xl},fields:[{name:"customerName",type:"text",required:!0},{name:"location",type:"text",localized:!0,admin:{description:'e.g. "Dhaka" — optional'}},{name:"quote",type:"textarea",required:!0,localized:!0,validate:i.E,admin:{description:"Use the customer’s own words. Translate for the other language if needed."}},{name:"rating",type:"number",min:1,max:5,admin:{description:"1–5, optional. Only enter the rating the customer actually gave."}},{name:"product",type:"relationship",relationTo:"products",admin:{position:"sidebar"}},{name:"order",type:"relationship",relationTo:"orders",admin:{position:"sidebar",description:"Verified purchase (optional)"}},{name:"moderation",type:"select",required:!0,defaultValue:"pending",options:[{label:"Pending review",value:"pending"},{label:"Approved",value:"approved"},{label:"Rejected",value:"rejected"}],admin:{position:"sidebar"}},{name:"consentToPublish",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"The customer agreed to this review being shown."}},{name:"source",type:"text",admin:{position:"sidebar",description:"Where it came from (Facebook comment, WhatsApp, phone call…). Internal."}}]},m={slug:"posts",labels:{singular:"Blog post",plural:"Blog posts"},admin:{group:"Content",useAsTitle:"title",defaultColumns:["title","publishedAt","status","translationStatus"],preview:(a,{locale:b})=>`/${b||"bn"}/blog/${a.slug}?preview=1`},defaultSort:"-publishedAt",access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["title","excerpt"])],afterChange:[(0,h.L)("post")]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"title",type:"text",required:!0,localized:!0,validate:i.E},{name:"excerpt",type:"textarea",localized:!0,maxLength:300},{name:"coverImage",type:"upload",relationTo:"media"},{name:"content",type:"richText",localized:!0}]},{label:"SEO",fields:[(0,e.Z)()]}]},(0,f.O)("title"),j("draft"),{name:"publishedAt",type:"date",admin:{position:"sidebar",date:{pickerAppearance:"dayAndTime"}},defaultValue:()=>new Date().toISOString()},{name:"author",type:"text",admin:{position:"sidebar"}},{name:"relatedProducts",type:"relationship",relationTo:"products",hasMany:!0,admin:{position:"sidebar"}},(0,g.I)()]},n={slug:"pages",labels:{singular:"Page",plural:"Pages & policies"},admin:{group:"Content",useAsTitle:"title",defaultColumns:["title","slug","kind","status","translationStatus"],preview:(a,{locale:b})=>`/${b||"bn"}/pages/${a.slug}?preview=1`},access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["title"])],afterChange:[(0,h.L)("page")]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"title",type:"text",required:!0,localized:!0,validate:i.E},{name:"intro",type:"textarea",localized:!0},{name:"content",type:"richText",localized:!0}]},{label:"SEO",fields:[(0,e.Z)()]}]},(0,f.O)("title"),{name:"kind",type:"select",defaultValue:"info",options:[{label:"Information page",value:"info"},{label:"Policy",value:"policy"}],admin:{position:"sidebar"}},j(),(0,g.I)()]},o={slug:"redirects",labels:{singular:"Redirect",plural:"Redirects"},admin:{group:"Settings",useAsTitle:"fromSlug",defaultColumns:["type","fromSlug","toSlug","automatic"],description:"Old URLs that permanently redirect to new ones. Created automatically when a slug changes."},access:{read:d.ZZ,create:d.Xl,update:d.Xl,delete:d.qc},fields:[{name:"type",type:"select",required:!0,options:[{label:"Product",value:"product"},{label:"Category",value:"category"},{label:"Blog post",value:"post"},{label:"Page",value:"page"}]},{name:"fromSlug",type:"text",required:!0,index:!0},{name:"toSlug",type:"text",required:!0},{name:"automatic",type:"checkbox",defaultValue:!1,admin:{readOnly:!0}}]}},2033:(a,b,c)=>{"use strict";function d(a,b){var c;let d;if(!a||"object"!=typeof a)return null;let e=(b?a.sizes?.[b]?.url:null)||a.url||null;return e?(c=e,(d=/^https?:\/\/[^/]+(\/api\/media\/file\/.*)$/.exec(c))?d[1]:c):null}function e(a,b){if(!a||"object"!=typeof a)return null;let c=b?a.sizes?.[b]:null,d=c?.width??a.width,e=c?.height??a.height;return d&&e?{width:d,height:e}:null}c.d(b,{SG:()=>d,YX:()=>e})},2186:(a,b,c)=>{Promise.resolve().then(c.bind(c,20876)),Promise.resolve().then(c.t.bind(c,2116,23)),Promise.resolve().then(c.t.bind(c,73836,23)),Promise.resolve().then(c.bind(c,71985)),Promise.resolve().then(c.bind(c,34184)),Promise.resolve().then(c.bind(c,96315)),Promise.resolve().then(c.bind(c,29650)),Promise.resolve().then(c.bind(c,15506)),Promise.resolve().then(c.bind(c,87224)),Promise.resolve().then(c.bind(c,71788)),Promise.resolve().then(c.bind(c,35642))},3380:(a,b,c)=>{"use strict";function d(a){let{admin:b,...c}=a;return{type:"number",min:0,validate:(a,{required:b})=>null==a?!b||"This field is required.":Number.isInteger(a)?!(a<0)||"Amount cannot be negative.":"Amount must be whole poisha (max 2 decimal places in taka).",...c,admin:{...b,components:{Field:"/components/admin/MoneyField#MoneyField",Cell:"/components/admin/MoneyCell#MoneyCell",...b?.components}}}}c.d(b,{$:()=>d})},3449:(a,b,c)=>{"use strict";c.d(b,{WhatsAppButton:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call WhatsAppButton() from the server but WhatsAppButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\whatsapp\\WhatsAppButton.tsx","WhatsAppButton")},4218:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>f});var d=c(48249);c(67484);var e=c(71788);function f({error:a,reset:b}){let{dict:c}=(0,e.s)();return(0,d.jsxs)("div",{className:"container-page flex min-h-[50vh] flex-col items-start justify-center py-16",children:[(0,d.jsx)("h1",{className:"text-[clamp(2rem,5vw,3rem)] text-primary",children:c.error.title}),(0,d.jsx)("p",{className:"mt-3 text-lg text-ink-soft",children:c.error.body}),(0,d.jsx)("button",{type:"button",onClick:b,className:"mt-8 inline-flex h-12 items-center rounded-[var(--radius-control)] bg-primary px-6 font-medium text-white hover:bg-primary-deep",children:c.common.tryAgain})]})}},6166:(a,b,c)=>{"use strict";c.d(b,{D:()=>h});var d=c(16332),e=c(37355),f=c(24942);let g=a=>a.replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[a]);async function h(a,b){if(!e._.SMTP_HOST)return;let c=b.locale||"bn",h=`${e._.NEXT_PUBLIC_SERVER_URL}${(0,f.fG)(c,b.orderNumber)}`,i=(b.items??[]).map(a=>`<tr><td>${g(a.productName)}${a.variantLabel?` — ${g(a.variantLabel)}`:""}</td><td>\xd7 ${a.quantity}</td><td style="text-align:right">${(0,d.$g)(a.lineTotal,c)}</td></tr>`).join(""),j=`<table cellpadding="6" style="border-collapse:collapse;width:100%;max-width:560px">${i}
    <tr><td colspan="2"><strong>${"bn"===c?"সর্বমোট":"Total"}</strong></td><td style="text-align:right"><strong>${(0,d.$g)(b.total,c)}</strong></td></tr></table>`,k=[];if(b.customerEmail){let d="bn"===c?`অর্ডার ${b.orderNumber} গ্রহণ করা হয়েছে`:`Order ${b.orderNumber} received`,e="bn"===c?`প্রিয় ${g(b.customerName)}, আপনার অর্ডারটি আমরা পেয়েছি। পাঠানোর আগে আমরা ফোনে নিশ্চিত করব।`:`Dear ${g(b.customerName)}, we have received your order and will call to confirm before dispatch.`;k.push(a.sendEmail({to:b.customerEmail,subject:d,html:`<p>${e}</p>${j}<p><a href="${h}">${"bn"===c?"অর্ডার দেখুন":"View your order"}</a></p>`}))}for(let c of(e._.ORDER_NOTIFICATION_EMAIL&&k.push(a.sendEmail({to:e._.ORDER_NOTIFICATION_EMAIL,subject:`New order ${b.orderNumber} — ${(0,d.$g)(b.total,"en")} (${b.paymentMethod})`,html:`<p>${g(b.customerName)} \xb7 ${g(b.customerPhone)} \xb7 ${g(b.district??"")}</p>${j}
          <p><a href="${e._.NEXT_PUBLIC_SERVER_URL}/admin/collections/orders/${b.id}">Open in admin</a></p>`})),await Promise.allSettled(k)))"rejected"===c.status&&a.logger.error({err:c.reason,msg:"Order email failed"})}},6180:(a,b,c)=>{"use strict";c.d(b,{L:()=>j});var d=c(78853),e=c(14915),f=c(8313),g=c(89556),h=c(79252),i=c(99795);let j={slug:"categories",labels:{singular:"Category",plural:"Categories"},admin:{useAsTitle:"name",group:"Catalog",defaultColumns:["name","slug","status","featured","sortOrder","translationStatus"],listSearchableFields:["name","slug"],preview:(a,{locale:b})=>`/${b||"bn"}/category/${a.slug}`},defaultSort:"sortOrder",access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["name"])],afterChange:[(0,h.L)("category")]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"name",type:"text",required:!0,localized:!0,validate:i.E},{name:"description",type:"textarea",localized:!0,admin:{description:"One or two sentences shown on category cards and the category page."}},{name:"image",type:"upload",relationTo:"media",admin:{description:"Square-ish image for category cards."}},{name:"banner",type:"upload",relationTo:"media",admin:{description:"Optional wide banner on the category page."}}]},{label:"SEO",fields:[(0,e.Z)()]}]},(0,f.O)("name"),{name:"status",type:"select",required:!0,defaultValue:"published",options:[{label:"Published",value:"published"},{label:"Hidden",value:"draft"}],admin:{position:"sidebar"}},{name:"parent",type:"relationship",relationTo:"categories",admin:{position:"sidebar"},filterOptions:({id:a})=>!a||{id:{not_equals:a}}},{name:"featured",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"Show on the homepage category row."}},{name:"sortOrder",type:"number",defaultValue:0,admin:{position:"sidebar",description:"Lower numbers appear first."}},(0,g.I)()]}},8313:(a,b,c)=>{"use strict";function d(a){return a.normalize("NFKD").replace(/[̀-ͯ]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,80)}function e(a="name"){return{name:"slug",type:"text",required:!0,unique:!0,index:!0,admin:{position:"sidebar",description:'URL part, e.g. "himsagar-mango". Lowercase letters, numbers and dashes. Changing it creates a redirect from the old URL.'},validate:a=>a?!!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(a)||"Use lowercase letters, numbers and single dashes only.":"A slug is required.",hooks:{beforeValidate:[({value:b,data:c,req:e})=>{if("string"==typeof b&&b.trim())return d(b);let f=c?.[a],g="string"==typeof f?f:f&&"object"==typeof f?f.en??f[e.locale??"en"]:"";return g?d(String(g)):b}],beforeDuplicate:[({value:a})=>a?`${a}-copy-${Date.now().toString(36)}`:a]}}}c.d(b,{O:()=>e,Y:()=>d})},9743:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{ao:()=>p});var e=c(78853),f=c(3380),g=c(54027),h=c(47138),i=c(53438),j=c(99879),k=a([h]);h=(k.then?(await k)():k)[0];let l={pending:["confirmed","processing","cancelled"],confirmed:["processing","shipped","cancelled"],processing:["shipped","cancelled"],shipped:["delivered","cancelled"],delivered:[],cancelled:[]},m=()=>!1,n=a=>a.charAt(0).toUpperCase()+a.slice(1),o=async({data:a,originalDoc:b,operation:c,req:d})=>{if("update"!==c||!b)return a;let e=b.status,f=a.status??e,g=b.paymentStatus,i=a.paymentStatus??g;if(f!==e&&!l[e]?.includes(f))throw Error(`An order cannot move from "${n(e)}" to "${n(f)}".`);let j=Array.isArray(b.statusHistory)?[...b.statusHistory]:[];return a.stockRestored=!!b.stockRestored,(f!==e||i!==g)&&j.push({status:f,paymentStatus:i,note:"string"==typeof a.statusNote&&a.statusNote.trim()?a.statusNote.trim():void 0,at:new Date().toISOString(),by:d.user?.email??"system"}),a.statusHistory=j,a.statusNote="","cancelled"!==f||"cancelled"===e||b.stockRestored||(await (0,h.v)(d,b),a.stockRestored=!0),a},p={slug:"orders",labels:{singular:"Order",plural:"Orders"},admin:{useAsTitle:"orderNumber",group:"Sales",defaultColumns:["orderNumber","createdAt","customerName","customerPhone","total","status","paymentStatus","paymentMethod"],listSearchableFields:["orderNumber","customerName","customerPhone","customerEmail"],components:{beforeListTable:["/components/admin/OrdersExport#OrdersExport"]}},defaultSort:"-createdAt",access:{read:e.k3,update:e.k3,create:e.eP,delete:e.qc},endpoints:[i.f,j.N],hooks:{beforeChange:[o]},fields:[{type:"tabs",tabs:[{label:"Order",fields:[{name:"items",type:"array",required:!0,access:{update:m},admin:{readOnly:!0,description:"Snapshot of what was bought, at the price paid. Not affected by later product changes."},fields:[{name:"product",type:"relationship",relationTo:"products"},{name:"productName",type:"text",required:!0},{name:"productNameEn",type:"text"},{name:"variantId",type:"text"},{name:"variantLabel",type:"text"},{name:"sku",type:"text"},(0,f.$)({name:"unitPrice",required:!0}),(0,f.$)({name:"regularPrice"}),{name:"quantity",type:"number",required:!0,min:1},(0,f.$)({name:"lineTotal",required:!0})]},{type:"row",fields:[(0,f.$)({name:"subtotal",required:!0,access:{update:m},admin:{readOnly:!0,width:"25%"}}),(0,f.$)({name:"discount",defaultValue:0,access:{update:m},admin:{readOnly:!0,width:"25%"}}),(0,f.$)({name:"shippingFee",label:"Delivery fee",defaultValue:0,access:{update:m},admin:{readOnly:!0,width:"25%"}}),(0,f.$)({name:"total",required:!0,access:{update:m},admin:{readOnly:!0,width:"25%"}})]},{type:"row",fields:[{name:"couponCode",type:"text",access:{update:m},admin:{readOnly:!0,width:"33%"}},{name:"deliveryMethod",type:"text",access:{update:m},admin:{readOnly:!0,width:"33%"}},{name:"deliveryZone",type:"text",access:{update:m},admin:{readOnly:!0,width:"33%"}}]}]},{label:"Customer & address",fields:[{type:"row",fields:[{name:"customerName",type:"text",required:!0,admin:{width:"34%"}},{name:"customerPhone",type:"text",required:!0,index:!0,admin:{width:"33%"}},{name:"customerEmail",type:"email",admin:{width:"33%"}}]},{type:"row",fields:[{name:"division",type:"text",admin:{width:"33%"}},{name:"district",type:"select",options:g.dn,admin:{width:"33%"}},{name:"area",type:"text",admin:{width:"34%"}}]},{name:"address",type:"textarea",required:!0},{name:"customerNotes",type:"textarea",admin:{readOnly:!0}},{name:"customer",type:"relationship",relationTo:"customers",admin:{readOnly:!0}}]},{label:"History",fields:[{name:"statusHistory",type:"array",admin:{readOnly:!0},fields:[{type:"row",fields:[{name:"status",type:"text",admin:{width:"20%"}},{name:"paymentStatus",type:"text",admin:{width:"20%"}},{name:"at",type:"date",admin:{width:"30%",date:{pickerAppearance:"dayAndTime"}}},{name:"by",type:"text",admin:{width:"30%"}}]},{name:"note",type:"text"}]},{name:"payments",type:"join",collection:"payments",on:"order",admin:{defaultColumns:["provider","status","amount","transactionId","createdAt"]}}]}]},{name:"orderNumber",type:"text",required:!0,unique:!0,index:!0,access:{update:m},admin:{position:"sidebar",readOnly:!0}},{name:"status",label:"Fulfilment status",type:"select",required:!0,defaultValue:"pending",index:!0,options:["pending","confirmed","processing","shipped","delivered","cancelled"].map(a=>({label:n(a),value:a})),admin:{position:"sidebar"}},{name:"paymentStatus",type:"select",required:!0,defaultValue:"unpaid",index:!0,options:["unpaid","pending","paid","failed","refunded","cancelled"].map(a=>({label:n(a),value:a})),admin:{position:"sidebar",description:"Online payments are set automatically after the gateway confirms them server-side."}},{name:"paymentMethod",type:"select",required:!0,options:[{label:"Cash on delivery",value:"cod"},{label:"SSLCommerz",value:"sslcommerz"},{label:"bKash",value:"bkash"},{label:"Nagad",value:"nagad"}],access:{update:m},admin:{position:"sidebar",readOnly:!0}},{name:"statusNote",type:"text",admin:{position:"sidebar",description:"Optional note saved into the history with the next status change."}},{name:"adminNotes",type:"textarea",admin:{position:"sidebar",description:"Internal only."}},{name:"orderActions",type:"ui",admin:{position:"sidebar",components:{Field:"/components/admin/OrderActions#OrderActions"}}},{name:"locale",type:"select",options:["bn","en"],defaultValue:"bn",access:{update:m},admin:{position:"sidebar",readOnly:!0}},{name:"idempotencyKey",type:"text",unique:!0,index:!0,access:{read:()=>!1,update:m},admin:{hidden:!0}},{name:"stockRestored",type:"checkbox",defaultValue:!1,admin:{hidden:!0}}]};d()}catch(a){d(a)}})},11506:(a,b,c)=>{"use strict";function d(a,b="amount"){if(!Number.isFinite(a)||!Number.isInteger(a))throw Error(`${b} must be an integer number of poisha, received ${a}`);return a}function e(a,b){if(d(a,"unit price"),!Number.isInteger(b)||b<0)throw Error("quantity must be a non-negative integer");return a*b}function f(a,b){d(a);let c=Math.round(100*b);if(c<0||c>1e4)throw Error("percent must be between 0 and 100");return Math.floor((a*c+5e3)/1e4)}function g(a){return a.reduce((a,b)=>a+d(b),0)}function h(a,b,c){return Math.min(Math.max(a,b),c)}c.d(b,{cz:()=>g,lw:()=>e,pR:()=>f,qE:()=>h})},11680:(a,b,c)=>{Promise.resolve().then(c.bind(c,4218))},12574:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.r(b),c.d(b,{default:()=>y,dynamic:()=>z,generateMetadata:()=>w,generateStaticParams:()=>x,viewport:()=>A});var e=c(5735);c(90829),c(80931),c(92931),c(28982),c(80305),c(43621),c(38698),c(57479);var f=c(91986),g=c(15759),h=c(68282),i=c(93787),j=c(80814),k=c(14976),l=c(75300),m=c(28878),n=c(25),o=c(3449),p=c(99459),q=c(31245),r=c(14654),s=c(2033),t=c(25006),u=c(48773),v=a([u]);u=(v.then?(await v)():v)[0];let z="force-dynamic",A={themeColor:"#245B32",width:"device-width",initialScale:1,viewportFit:"cover"};async function w({params:a}){let b=await (0,t.rv)(a),{branding:c,analytics:d}=await (0,u.Bm)(b),e=c.siteTitle||c.brandName,f="object"==typeof c.favicon&&c.favicon?(0,s.SG)(c.favicon):null,g="object"==typeof c.defaultShareImage?(0,s.SG)(c.defaultShareImage,"og"):null;return{metadataBase:new URL(r._.NEXT_PUBLIC_SERVER_URL),title:{default:c.defaultSeoTitle||e,template:`%s | ${e}`},description:c.defaultSeoDescription||c.tagline||void 0,applicationName:e,icons:f?{icon:[{url:f}],apple:[{url:f}]}:{icon:[{url:"/brand/favicon.svg",type:"image/svg+xml"}]},openGraph:{siteName:e,images:g?[{url:g}]:void 0,locale:p.ib[b].ogLocale},verification:d.searchConsoleVerification?{google:d.searchConsoleVerification}:void 0,formatDetection:{telephone:!1}}}function x(){return p.IB.map(a=>({lang:a}))}async function y({children:a,params:b}){let c=await (0,t.rv)(b),d=(0,p.TW)(c),[{branding:s,contact:v,navigation:w,analytics:x},z]=await Promise.all([(0,u.Bm)(c),(0,u.VX)(c)]),A=s.brandName||"Shop",B=(0,u.RS)(s.logo,"large"),C=(0,u.RS)(s.logoMobile,"large"),D=(0,u.RS)(s.logoFooter,"large"),E=(0,t.bg)(s.colors),F=[{title:d.footer.shop,links:[{label:d.nav.shop,href:"/shop"},{label:d.nav.mangoes,href:"/category/mango"}]},{title:d.footer.help,links:[{label:d.nav.trackOrder,href:"/track-order"}]}],G=(w.footerColumns??[]).map(a=>({title:a.title,links:(a.links??[]).map(a=>({label:a.label,href:a.href}))})),H=r._.NEXT_PUBLIC_SERVER_URL;return(0,e.jsx)("html",{lang:p.ib[c].htmlLang,style:E,suppressHydrationWarning:!0,children:(0,e.jsxs)("body",{className:"min-h-dvh bg-cream text-ink antialiased",children:[(0,e.jsx)("a",{href:"#main",className:"sr-only z-[60] rounded bg-primary px-4 py-2 text-white focus:not-sr-only focus:fixed focus:left-3 focus:top-3",children:d.common.skipToContent}),(0,e.jsx)(m.I18nProvider,{locale:c,dict:d,children:(0,e.jsxs)(l.CartProvider,{children:[z.announcement?.enabled&&z.announcement.text&&(0,e.jsx)(i.Z,{text:z.announcement.text,href:z.announcement.href,tone:z.announcement.tone,locale:c}),(0,e.jsx)(k.Y,{locale:c,dict:d,brandName:A,logo:B,mobileLogo:C,links:(w.headerLinks??[]).map(a=>({label:a.label,href:a.href}))}),(0,e.jsx)("main",{id:"main",tabIndex:-1,className:"focus:outline-none",children:a}),(0,e.jsx)(j.w,{locale:c,dict:d,brandName:A,logo:D,description:w.footerDescription||s.tagline||"",columns:G.length?G:F,phone:s.phone,email:s.email,address:s.address,socials:(s.socials??[]).map(a=>({platform:a.platform,url:a.url})),paymentNote:w.paymentNote,copyright:w.copyright}),(0,e.jsx)(h.CartDrawer,{}),v.whatsappEnabled&&v.whatsappNumber&&(0,e.jsx)(f.Suspense,{fallback:null,children:(0,e.jsx)(o.WhatsAppButton,{number:v.whatsappNumber,messageBn:v.messageBn||"",messageEn:v.messageEn||"",tooltip:v.tooltip,position:"left"===v.position?"left":"right",showOn:v.showOn??[]})}),(0,e.jsx)(g.Analytics,{ga4Id:x.ga4Id,gtmId:x.gtmId,requireConsent:!1!==x.requireConsent})]})}),(0,e.jsx)(n.a,{data:[(0,q.sw)({name:A,url:H,logoUrl:B?new URL(B.url,H).toString():null,phone:s.phone,email:s.email,sameAs:(s.socials??[]).map(a=>a.url)}),(0,q.cE)({name:s.siteTitle||A,url:`${H}/${c}`,locale:c,searchUrl:`${H}/${c}/shop`})]})]})})}d()}catch(a){d(a)}})},13007:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{f:()=>t});var e=c(84094),f=c(14959),g=c(18512),h=c(8973),i=c(30755),j=c(46747),k=c(54027),l=c(63678),m=c(29734),n=c(71718),o=c(52625),p=c(60601),q=c(61378),r=c(24942),s=a([p]);p=(s.then?(await s)():s)[0];class y extends Error{}async function t(a,b){let c=m.hP.safeParse(b);if(!c.success){let a={};for(let b of c.error.issues)"form"===b.path[0]&&b.path[1]&&(a[String(b.path[1])]=b.message);return{ok:!1,error:"invalid_input",fieldErrors:a}}let d=c.data,{form:r,locale:s}=d,t=await v(a,d.idempotencyKey);if(t)return u(t,!0);let z=(0,n.o)(r.phone),A=d.couponCode?(0,j.Z)(d.couponCode):void 0,[B,C,D,E]=await Promise.all([(0,o.LB)(a,d.items.map(a=>a.productId),s),(0,o.bI)(a,A),(0,o.B1)(a,s),(0,q.u)(a)]),F=D.methods.find(a=>a.code===r.deliveryMethod)??null,G=(0,l.V)(D.zones,r.district);if(!F)return{ok:!1,error:"invalid_input",fieldErrors:{deliveryMethod:"deliveryMethod"}};if(!G)return{ok:!1,error:"delivery_unavailable",fieldErrors:{district:"district"}};let H=(0,i.E)({items:d.items,catalog:B,coupon:C,couponCode:A,zones:D.zones,district:r.district,method:F});if(!H.purchasable||H.couponError)return{ok:!1,error:"cart_issues",totals:H};let I=E.find(a=>a.id===r.paymentMethod);if(!I||null!=I.maxTotal&&H.total>I.maxTotal)return{ok:!1,error:"payment_unavailable",fieldErrors:{paymentMethod:"paymentMethod"}};let J=await (0,e.M)({locale:s},a);await (0,f.n)(J);try{for(let b of H.lines){let c=await (0,p.tz)(a,{productId:b.productId,variantId:b.variantId,quantity:b.quantity},J);if(null===c)throw new y(b.sku)}if(C&&H.discount>0&&!await (0,p._Z)(a,C.id,J))throw new y("coupon");let b=await x(a,J,{name:r.name,phone:z,email:r.email||void 0,division:r.division,district:r.district,area:r.area,address:r.address,total:H.total}),c=await w(a,J),e=await a.create({collection:"orders",req:J,overrideAccess:!0,data:{orderNumber:c,idempotencyKey:d.idempotencyKey,locale:s,status:"pending",paymentStatus:"cod"===r.paymentMethod?"unpaid":"pending",paymentMethod:r.paymentMethod,customer:b,customerName:r.name,customerPhone:z,customerEmail:r.email||void 0,division:(0,k.j5)(r.division,"en"),district:r.district,area:r.area,address:r.address,customerNotes:r.notes||void 0,deliveryMethod:F.code,deliveryZone:G.code,couponCode:H.couponCode,items:H.lines.map(a=>{let b=B.get(String(a.productId)),c=b.variantNames[a.variantId];return{product:Number(a.productId),productName:"bn"===s?b.nameBn:b.nameEn,productNameEn:b.nameEn,variantId:a.variantId,variantLabel:"bn"===s?c?.bn:c?.en,sku:a.sku,unitPrice:a.unitPrice,regularPrice:a.regularPrice,quantity:a.quantity,lineTotal:a.lineTotal}}),subtotal:H.subtotal,discount:H.discount,shippingFee:H.shipping,total:H.total,statusHistory:[{status:"pending",paymentStatus:"cod"===r.paymentMethod?"unpaid":"pending",at:new Date().toISOString(),by:"customer",note:`Placed online (${(0,k.Ce)(r.district,"en")})`}]}});for(let b of H.lines)await a.create({collection:"stock-adjustments",req:J,overrideAccess:!0,data:{sku:b.sku,delta:-b.quantity,reason:"order",product:Number(b.productId),variantId:b.variantId,order:e.id,createdBy:"checkout",systemGenerated:!0,note:e.orderNumber}});for(let b of new Set(H.lines.map(a=>a.productId)))await (0,p.R7)(a,b,J);return await (0,g.w)(J),u(e,!1)}catch(c){if(await (0,h.J)(J),c instanceof y)return{ok:!1,error:"stock_changed",totals:(0,i.E)({items:d.items,catalog:await (0,o.LB)(a,d.items.map(a=>a.productId),s),coupon:await (0,o.bI)(a,A),couponCode:A,zones:D.zones,district:r.district,method:F})};let b=await v(a,d.idempotencyKey);if(b)return u(b,!0);return a.logger.error({err:c,msg:"createOrder failed"}),{ok:!1,error:"server_error"}}}function u(a,b){return{ok:!0,orderId:a.id,orderNumber:a.orderNumber,accessToken:(0,r.gq)(a.orderNumber),paymentMethod:a.paymentMethod,total:a.total,duplicate:b}}async function v(a,b){return(await a.find({collection:"orders",where:{idempotencyKey:{equals:b}},limit:1,depth:0,overrideAccess:!0})).docs[0]??null}async function w(a,b){for(let c=0;c<5;c++){let c=(0,r.XE)();if(0===(await a.count({collection:"orders",where:{orderNumber:{equals:c}},overrideAccess:!0,req:b})).totalDocs)return c}throw Error("Could not allocate a unique order number")}async function x(a,b,c){let d=await a.find({collection:"customers",where:{phone:{equals:c.phone}},limit:1,depth:0,overrideAccess:!0,req:b}),e={division:c.division,district:c.district,area:c.area,address:c.address},f=d.docs[0];return f?(await a.update({collection:"customers",id:f.id,req:b,overrideAccess:!0,data:{name:c.name,email:c.email||f.email,lastAddress:e,orderCount:(f.orderCount??0)+1,totalSpent:(f.totalSpent??0)+c.total,lastOrderAt:new Date().toISOString()}}),f.id):(await a.create({collection:"customers",req:b,overrideAccess:!0,data:{name:c.name,phone:c.phone,email:c.email,lastAddress:e,orderCount:1,totalSpent:c.total,lastOrderAt:new Date().toISOString()}})).id}d()}catch(a){d(a)}})},13972:(a,b,c)=>{"use strict";function d(a){if(!a)return null;let b=a instanceof Date?a.getTime():Date.parse(a);return Number.isNaN(b)?null:b}function e(a,b=new Date){let c=function(a,b=new Date){if(null==a.salePrice||a.salePrice<=0||a.salePrice>=a.price)return!1;let c=d(a.saleStartsAt),e=d(a.saleEndsAt),f=b.getTime();return(null===c||!(f<c))&&(null===e||!(f>e))}(a,b),f=c?a.salePrice:a.price,g=c?Math.floor((a.price-f)*100/a.price):0;return{unitPrice:f,regularPrice:a.price,onSale:c,discountPercent:g}}c.d(b,{n:()=>e})},14657:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,95547,23))},14915:(a,b,c)=>{"use strict";function d(){return{name:"seo",type:"group",label:"SEO",admin:{description:"Optional. Leave empty to use automatic values generated from the title and description."},fields:[{name:"title",type:"text",localized:!0,maxLength:70,admin:{description:"Search result title (≈50–60 characters)."}},{name:"description",type:"textarea",localized:!0,maxLength:200,admin:{description:"Search result snippet (≈140–160 characters)."}},{name:"focusKeyword",type:"text",localized:!0,admin:{description:"For your own reference while writing."}},{name:"ogTitle",label:"Social share title",type:"text",localized:!0},{name:"ogDescription",label:"Social share description",type:"textarea",localized:!0},{name:"ogImage",label:"Social share image",type:"upload",relationTo:"media"},{name:"canonicalUrl",type:"text",admin:{description:"Only if this content officially lives at another URL. Must be an absolute https:// URL."},validate:a=>!!(!a||/^https:\/\/[^\s]+$/.test(a))||"Use an absolute https:// URL or leave empty."},{name:"noindex",type:"checkbox",label:"Hide from search engines (noindex)",defaultValue:!1}]}}c.d(b,{Z:()=>d})},14976:(a,b,c)=>{"use strict";c.d(b,{Y:()=>n});var d=c(5735),e=c(98131),f=c(63059),g=c.n(f),h=c(91986),i=c(89592),j=c(37025),k=c(21184),l=c(70762),m=c(53776);function n({locale:a,dict:b,brandName:c,logo:f,mobileLogo:o,links:p}){let q=(p.length?p:[{label:b.nav.home,href:"/"},{label:b.nav.shop,href:"/shop"},{label:b.nav.mangoes,href:"/category/mango"},{label:b.nav.blog,href:"/blog"},{label:b.nav.trackOrder,href:"/track-order"}]).map(b=>({label:b.label,href:(0,i.l)(b.href,a)})),r=`/${a}/shop`;return(0,d.jsx)("header",{className:"sticky top-0 z-40 border-b border-line bg-cream/95 backdrop-blur supports-[backdrop-filter]:bg-cream/85",children:(0,d.jsxs)("div",{className:"container-page flex h-16 items-center gap-2 md:h-[72px] md:gap-4",children:[(0,d.jsx)(h.Suspense,{fallback:(0,d.jsx)("span",{className:"h-11 w-11 xl:hidden"}),children:(0,d.jsx)(m.MobileMenu,{links:q,searchAction:r})}),(0,d.jsx)(g(),{href:`/${a}`,className:"mr-auto flex shrink-0 items-center xl:mr-4","aria-label":`${c} — ${b.nav.home}`,children:(0,d.jsx)(l.g,{brandName:c,logo:f,mobileLogo:o})}),(0,d.jsx)("nav",{"aria-label":b.common.menu,className:"hidden min-w-0 flex-1 xl:block",children:(0,d.jsx)("ul",{className:"flex items-center gap-0.5",children:q.map(a=>(0,d.jsx)("li",{children:(0,d.jsx)(g(),{href:a.href,className:"whitespace-nowrap rounded-[var(--radius-control)] px-2.5 py-2 text-[0.95rem] text-ink hover:bg-leaf-tint hover:text-primary",children:a.label})},a.href+a.label))})}),(0,d.jsxs)("form",{action:r,method:"get",role:"search",className:"relative hidden 2xl:block",children:[(0,d.jsx)("label",{htmlFor:"header-search",className:"sr-only",children:b.common.search}),(0,d.jsx)("input",{id:"header-search",name:"q",type:"search",placeholder:b.common.searchPlaceholder,className:"h-10 w-44 rounded-[var(--radius-control)] border border-line bg-paper pl-9 pr-3 text-sm placeholder:text-ink-soft focus:w-60 focus:outline-none focus:ring-2 focus:ring-secondary xl:w-56"}),(0,d.jsx)(e.A,{className:"pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft","aria-hidden":!0})]}),(0,d.jsx)(g(),{href:r,"aria-label":b.common.search,className:"inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-control)] text-primary hover:bg-leaf-tint 2xl:hidden",children:(0,d.jsx)(e.A,{className:"h-5 w-5","aria-hidden":!0})}),(0,d.jsx)(h.Suspense,{fallback:null,children:(0,d.jsx)(k.LanguageSwitcher,{className:"hidden sm:flex"})}),(0,d.jsx)(j.CartButton,{})]})})}},15506:(a,b,c)=>{"use strict";c.d(b,{MobileMenu:()=>n});var d=c(48249),e=c(28313),f=c(63120),g=c(45535),h=c(2116),i=c.n(h),j=c(19099),k=c(67484),l=c(71788),m=c(29650);function n({links:a,searchAction:b}){let[c,h]=(0,k.useState)(!1),{dict:o}=(0,l.s)(),p=(0,j.usePathname)(),[q,r]=(0,k.useState)(p);return q!==p&&(r(p),h(!1)),(0,d.jsxs)(e.bL,{open:c,onOpenChange:h,children:[(0,d.jsx)(e.l9,{asChild:!0,children:(0,d.jsx)("button",{type:"button","aria-label":o.common.openMenu,className:"inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-control)] text-primary hover:bg-leaf-tint xl:hidden",children:(0,d.jsx)(f.A,{className:"h-6 w-6","aria-hidden":!0})})}),(0,d.jsxs)(e.ZL,{children:[(0,d.jsx)(e.hJ,{className:"drawer-overlay fixed inset-0 z-50 bg-ink/40"}),(0,d.jsxs)(e.UC,{className:"fixed inset-y-0 left-0 z-50 flex w-[86vw] max-w-sm flex-col bg-cream p-5 shadow-xl focus:outline-none",children:[(0,d.jsxs)("div",{className:"flex items-center justify-between",children:[(0,d.jsx)(e.hE,{className:"font-display text-xl text-primary",children:o.common.menu}),(0,d.jsx)(e.bm,{"aria-label":o.common.close,className:"inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-control)] hover:bg-leaf-tint",children:(0,d.jsx)(g.A,{className:"h-6 w-6","aria-hidden":!0})})]}),(0,d.jsx)(e.VY,{className:"sr-only",children:o.common.menu}),(0,d.jsxs)("form",{action:b,method:"get",role:"search",className:"mt-4",children:[(0,d.jsx)("label",{className:"sr-only",htmlFor:"mobile-search",children:o.common.search}),(0,d.jsx)("input",{id:"mobile-search",name:"q",type:"search",placeholder:o.common.searchPlaceholder,className:"h-11 w-full rounded-[var(--radius-control)] border border-line bg-paper px-3"})]}),(0,d.jsx)("nav",{"aria-label":o.common.menu,className:"mt-4 flex-1 overflow-y-auto",children:(0,d.jsx)("ul",{className:"divide-y divide-line",children:a.map(a=>(0,d.jsx)("li",{children:(0,d.jsx)(i(),{href:a.href,className:"block py-3.5 text-lg text-ink hover:text-primary",children:a.label})},a.href+a.label))})}),(0,d.jsx)(m.LanguageSwitcher,{className:"mt-4 self-start"})]})]})]})}},15759:(a,b,c)=>{"use strict";c.d(b,{Analytics:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call Analytics() from the server but Analytics is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\analytics\\Analytics.tsx","Analytics")},16332:(a,b,c)=>{"use strict";c.d(b,{$g:()=>f});var d=c(99139);let e=new Map;function f(a,b){var c;let f,g,h=(c=2*(a%100!=0),f=`${b}:${c}`,!(g=e.get(f))&&(g=new Intl.NumberFormat(d.ib[b].intl,{minimumFractionDigits:c,maximumFractionDigits:c}),e.set(f,g)),g).format(a/100);return"bn"===b?`৳ ${h}`:`৳${h}`}},16589:(a,b,c)=>{"use strict";c.d(b,{y:()=>f});var d=c(78853),e=c(3380);let f={slug:"payments",labels:{singular:"Payment",plural:"Payments"},admin:{group:"Sales",useAsTitle:"reference",defaultColumns:["createdAt","order","provider","amount","status","transactionId"]},defaultSort:"-createdAt",access:{read:d.k3,create:d.eP,update:d.eP,delete:d.qc},fields:[{name:"order",type:"relationship",relationTo:"orders",required:!0,index:!0},{name:"reference",type:"text",required:!0,unique:!0,admin:{description:"Our reference sent to the gateway (tran_id / merchantInvoiceNumber / orderId)."}},{name:"provider",type:"select",required:!0,options:[{label:"Cash on delivery",value:"cod"},{label:"SSLCommerz",value:"sslcommerz"},{label:"bKash",value:"bkash"},{label:"Nagad",value:"nagad"}]},(0,e.$)({name:"amount",required:!0}),{name:"currency",type:"text",defaultValue:"BDT"},{name:"status",type:"select",required:!0,defaultValue:"initiated",options:[{label:"Initiated",value:"initiated"},{label:"Succeeded",value:"succeeded"},{label:"Failed",value:"failed"},{label:"Cancelled",value:"cancelled"}]},{name:"transactionId",type:"text",index:!0,admin:{description:"Gateway transaction ID (trxID, val_id/bank_tran_id, issuerPaymentRefNo)."}},{name:"gatewayPaymentId",type:"text",index:!0,admin:{description:"Gateway session/payment ID used for verification."}},{name:"verifiedAt",type:"date"},{name:"failureReason",type:"text"},{name:"gatewayResponse",type:"json",admin:{description:"Verification response from the gateway (no credentials are stored)."}}]}},17223:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{$4:()=>A,Fp:()=>y,hB:()=>x,qd:()=>z,u9:()=>B});var e=c(95349),f=c(20457),g=c(36042),h=c(33277),i=c(30755),j=c(46747),k=c(63678),l=c(98794),m=c(29734),n=c(52625),o=c(13007),p=c(89190),q=c(24942),r=c(6166),s=c(54176),t=c(59615),u=c(89337),v=a([o,s]);async function w(){return(0,l.x7)(await (0,g.b3)())}[o,s]=v.then?(await v)():v;let C=h.k5n(["bn","en"]),D=h.Ikc({items:h.YOg(m.Sn).max(40),couponCode:h.YjP().trim().max(40).optional(),locale:C,district:h.YjP().max(40).optional(),deliveryMethod:h.YjP().max(40).optional()});async function x(a){if(!(0,l.if)(`quote:${await w()}`,120,6e4).ok)return{error:"rate_limited"};let b=D.safeParse(a);if(!b.success)return{error:"invalid"};let{items:c,locale:d,district:e,deliveryMethod:f}=b.data,g=b.data.couponCode?(0,j.Z)(b.data.couponCode):void 0,h=await (0,s.m)(),[m,o,p]=await Promise.all([(0,n.LB)(h,c.map(a=>a.productId),d),(0,n.bI)(h,g),(0,n.B1)(h,d)]),q=p.methods.find(a=>a.code===f)??null,r=e?(0,k.V)(p.zones,e):null;return{totals:(0,i.E)({items:c,catalog:m,coupon:o,couponCode:g,zones:e?p.zones:[],district:e,method:q}),zoneEstimate:r&&"estimate"in r?r.estimate:void 0,deliveryAvailable:!e||!!r}}async function y(a){if(!(0,l.if)(`add:${await w()}`,60,6e4).ok)return{ok:!1,reason:"rate_limited",available:0};let b=m.Sn.extend({locale:C}).safeParse(a);if(!b.success)return{ok:!1,reason:"unavailable",available:0};let c=await (0,s.m)(),d=(await (0,n.LB)(c,[b.data.productId],b.data.locale)).get(String(b.data.productId)),e=d?.variants.find(a=>a.id===b.data.variantId);if(!d?.published||!e)return{ok:!1,reason:"unavailable",available:0};let f=Math.max(0,e.stock);return 0===f?{ok:!1,reason:"out_of_stock",available:f}:b.data.quantity>f?{ok:!1,reason:"insufficient_stock",available:f}:{ok:!0,available:f}}async function z(a){let b=await w();if(!(0,l.if)(`order:${b}`,8,6e5).ok)return{ok:!1,error:"rate_limited"};let c=await (0,s.m)(),d=await (0,o.f)(c,a);if(!d.ok)return d;let e=a.locale,g=(0,q.fG)(e,d.orderNumber);if(d.duplicate||(0,f.after)(async()=>{let a=await c.findByID({collection:"orders",id:d.orderId,depth:0,overrideAccess:!0});await (0,r.D)(c,a)}),"cod"===d.paymentMethod)return{ok:!0,redirectTo:g};let h=await c.findByID({collection:"orders",id:d.orderId,depth:0,overrideAccess:!0});if("paid"===h.paymentStatus)return{ok:!0,redirectTo:g};let i=await (0,t.cn)(c,h,d.paymentMethod,b);return{ok:!0,redirectTo:i.ok?i.redirectUrl:`${g}&payment=failed`}}async function A(a){let b=await w();if(!(0,l.if)(`retry:${b}`,6,6e5).ok)return{error:"rate_limited"};if(!(0,q.b8)(a.orderNumber,a.token))return{error:"forbidden"};let c=await (0,s.m)(),d=(await c.find({collection:"orders",where:{orderNumber:{equals:a.orderNumber}},limit:1,depth:0,overrideAccess:!0})).docs[0];if(!d||"cod"===d.paymentMethod)return{error:"not_payable"};let e=await (0,t.cn)(c,d,d.paymentMethod,b);return e.ok?{redirectTo:e.redirectUrl}:{error:e.reason}}async function B(a,b){if(!(0,l.if)(`track:${await w()}`,10,6e5).ok)return{status:"rate_limited"};let c=String(b.get("orderNumber")??"").trim().toUpperCase(),d=String(b.get("phone")??""),e="en"===b.get("locale")?"en":"bn",f=await (0,s.m)(),g=await (0,p.Nv)(f,c,d);return g?{status:"found",redirectTo:(0,q.fG)(e,g.orderNumber)}:{status:"not_found"}}(0,u.D)([x,y,z,A,B]),(0,e.A)(x,"40d179d3d5df4d97c4bfeb30c7dc7c83a22e2edbc2",null),(0,e.A)(y,"40410648c34a308f4247af656ac875bec82d6d7151",null),(0,e.A)(z,"40bcf4b42309d975efd75c3d5c50e45936eba01f15",null),(0,e.A)(A,"405f923ca377b7fec706e4d19e5b9c2dadb43db674",null),(0,e.A)(B,"609730f67d5f6c220e7ce3f00b7ac11339e4533ebd",null),d()}catch(a){d(a)}})},21184:(a,b,c)=>{"use strict";c.d(b,{LanguageSwitcher:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call LanguageSwitcher() from the server but LanguageSwitcher is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\layout\\LanguageSwitcher.tsx","LanguageSwitcher")},21222:(a,b,c)=>{"use strict";c.d(b,{_:()=>h});var d=c(67484),e=c(99829);e.callServer,e.findSourceMapURL;var f=c(87224),g=c(71788);function h(a={}){let{lines:b,ready:c,couponCode:e}=(0,f._)(),{locale:i}=(0,g.s)(),[j,k]=(0,d.useState)(null);(0,d.useRef)(0);let l=!1!==a.enabled,m=JSON.stringify([b.map(a=>[a.productId,a.variantId,a.quantity]),e,a.district,a.deliveryMethod,a.withCoupon,i]);return c&&l&&b.length>0?{data:j?.data??null,loading:j?.key!==m,error:j?.key===m&&j.error}:{data:null,loading:!1,error:!1}}},21954:(a,b,c)=>{"use strict";c.d(b,{CQ:()=>m,Gg:()=>n,Me:()=>i,Vx:()=>l,cu:()=>j,sW:()=>o});var d=c(78853),e=c(3380),f=c(54027),g=c(99795);let h=(a,b,c)=>({name:a,label:b,type:"text",defaultValue:c,admin:{width:"33%",components:{Field:"/components/admin/ColorField#ColorField"}},validate:a=>!!(!a||/^#[0-9a-fA-F]{6}$/.test(a))||"Use a 6-digit hex colour like #245B32."}),i={slug:"branding",label:"Branding",admin:{group:"Website Settings",description:"Name, logos, favicon, colours and default SEO. Changes appear on the site immediately."},access:{read:d.ZZ,update:d.Xl},fields:[{type:"tabs",tabs:[{label:"Identity",fields:[{name:"brandName",type:"text",required:!0,localized:!0,validate:g.E,defaultValue:"আম্রকুঞ্জ"},{name:"tagline",type:"text",localized:!0},{name:"siteTitle",label:"Website title",type:"text",required:!0,localized:!0,validate:g.E,admin:{description:"Shown in browser tabs and appended to page titles."}},{type:"row",fields:[{name:"logo",label:"Main logo",type:"upload",relationTo:"media",admin:{width:"33%",description:"SVG or PNG. Wide logos work best."}},{name:"logoMobile",label:"Mobile logo",type:"upload",relationTo:"media",admin:{width:"33%",description:"Optional compact version."}},{name:"logoFooter",label:"Footer logo",type:"upload",relationTo:"media",admin:{width:"33%",description:"Optional light version for dark backgrounds."}}]},{name:"favicon",type:"upload",relationTo:"media",admin:{description:"Square PNG (at least 192\xd7192), SVG or ICO."},filterOptions:{mimeType:{in:["image/png","image/svg+xml","image/x-icon","image/vnd.microsoft.icon"]}}}]},{label:"Colours",description:"Brand colours used across the storefront. Keep good contrast between text and background colours.",fields:[{name:"colors",type:"group",fields:[{type:"row",fields:[h("primary","Primary (deep green)","#245B32"),h("secondary","Secondary (leaf green)","#477B3B"),h("accent","Accent (mango yellow)","#FFC928")]},{type:"row",fields:[h("accentWarm","Warm accent (mango orange)","#F59A23"),h("background","Background (cream)","#FFF9ED"),h("text","Text","#243126")]}]}]},{label:"Default SEO",fields:[{name:"defaultSeoTitle",label:"Default SEO title",type:"text",localized:!0,maxLength:70},{name:"defaultSeoDescription",label:"Default meta description",type:"textarea",localized:!0,maxLength:200},{name:"defaultShareImage",label:"Default social sharing image",type:"upload",relationTo:"media",admin:{description:"1200\xd7630 works best."}}]},{label:"Business contact",fields:[{type:"row",fields:[{name:"phone",type:"text",admin:{width:"50%",description:"Shown to customers, e.g. +880 1712-345678"}},{name:"email",type:"email",admin:{width:"50%"}}]},{name:"address",type:"textarea",localized:!0},{name:"socials",type:"array",labels:{singular:"Social link",plural:"Social links"},fields:[{type:"row",fields:[{name:"platform",type:"select",required:!0,admin:{width:"30%"},options:["facebook","instagram","youtube","tiktok","linkedin","x"].map(a=>({label:a,value:a}))},{name:"url",type:"text",required:!0,admin:{width:"70%"},validate:a=>!!(a&&/^https:\/\//.test(a))||"Use a full https:// link."}]}]}]}]}]},j={slug:"contact-settings",label:"Contact & WhatsApp",admin:{group:"Website Settings"},access:{read:d.ZZ,update:d.Xl},fields:[{name:"whatsappEnabled",label:"Show the WhatsApp button",type:"checkbox",defaultValue:!0},{name:"whatsappNumber",type:"text",admin:{description:"With country code, digits only, e.g. 8801712345678. The button stays hidden until this is set."},validate:a=>!!(!a||/^\d{10,15}$/.test(a.replace(/\D/g,"")))||"Enter 10–15 digits including the country code."},{name:"messageBn",label:"Default message (বাংলা)",type:"textarea",defaultValue:"আসসালামু আলাইকুম! আমি আপনাদের পণ্য সম্পর্কে জানতে চাই।"},{name:"messageEn",label:"Default message (English)",type:"textarea",defaultValue:"Hello! I'd like to know more about your products."},{name:"tooltip",type:"text",localized:!0,admin:{description:"Optional short label shown next to the button on larger screens."}},{name:"position",type:"select",defaultValue:"right",options:[{label:"Bottom right",value:"right"},{label:"Bottom left",value:"left"}]},{name:"showOn",label:"Show on these pages",type:"select",hasMany:!0,defaultValue:["home","shop","category","product","cart","blog","pages","order"],options:[{label:"Homepage",value:"home"},{label:"Shop & search",value:"shop"},{label:"Category pages",value:"category"},{label:"Product pages",value:"product"},{label:"Cart",value:"cart"},{label:"Checkout",value:"checkout"},{label:"Blog",value:"blog"},{label:"Policy & info pages",value:"pages"},{label:"Order & tracking pages",value:"order"}]}]},k=[{type:"row",fields:[{name:"label",type:"text",required:!0,localized:!0,validate:g.E,admin:{width:"50%"}},{name:"href",type:"text",required:!0,admin:{width:"50%",description:"Site path without language, e.g. /shop or /category/mango — or a full https:// URL."},validate:a=>!!(a&&(/^\/[^\s]*$/.test(a)||/^https?:\/\//.test(a)))||"Start with / or https://"}]}],l={slug:"navigation",label:"Header & footer",admin:{group:"Website Settings"},access:{read:d.ZZ,update:d.Xl},fields:[{type:"tabs",tabs:[{label:"Header",fields:[{name:"headerLinks",type:"array",maxRows:8,labels:{singular:"Menu link",plural:"Menu links"},admin:{description:"Main menu. Cart, search and language switch are always shown."},fields:k}]},{label:"Footer",fields:[{name:"footerDescription",type:"textarea",localized:!0},{name:"footerColumns",type:"array",maxRows:4,fields:[{name:"title",type:"text",required:!0,localized:!0,validate:g.E},{name:"links",type:"array",fields:k}]},{name:"paymentNote",type:"text",localized:!0,admin:{description:'e.g. "Cash on delivery, bKash, Nagad and cards via SSLCommerz"'}},{name:"copyright",type:"text",localized:!0,admin:{description:"The year and brand name are added automatically when this is empty."}}]}]}]},m={slug:"delivery-settings",label:"Delivery",admin:{group:"Website Settings",description:"Delivery zones, charges and methods used at checkout."},access:{read:d.ZZ,update:d.k3},fields:[{name:"zones",type:"array",minRows:1,labels:{singular:"Delivery zone",plural:"Delivery zones"},admin:{description:"A district uses the zone that lists it; otherwise the default zone applies. Districts with no zone and no default cannot order."},fields:[{type:"row",fields:[{name:"code",type:"text",required:!0,admin:{width:"25%",description:"e.g. inside-dhaka"}},{name:"name",type:"text",required:!0,localized:!0,validate:g.E,admin:{width:"45%"}},{name:"enabled",type:"checkbox",defaultValue:!0,admin:{width:"15%"}},{name:"isDefault",type:"checkbox",defaultValue:!1,admin:{width:"15%"}}]},{type:"row",fields:[(0,e.$)({name:"fee",label:"Delivery fee (৳)",required:!0,admin:{width:"33%"}}),(0,e.$)({name:"freeOver",label:"Free over (৳)",admin:{width:"33%",description:"Optional"}}),{name:"estimate",type:"text",localized:!0,admin:{width:"34%",description:'e.g. "১–২ দিন" / "1–2 days"'}}]},{name:"districts",type:"select",hasMany:!0,options:f.dn}]},{name:"methods",type:"array",minRows:1,labels:{singular:"Delivery method",plural:"Delivery methods"},fields:[{type:"row",fields:[{name:"code",type:"text",required:!0,admin:{width:"25%",description:"e.g. standard"}},{name:"name",type:"text",required:!0,localized:!0,validate:g.E,admin:{width:"45%"}},(0,e.$)({name:"surcharge",label:"Extra charge (৳)",defaultValue:0,admin:{width:"15%"}}),{name:"enabled",type:"checkbox",defaultValue:!0,admin:{width:"15%"}}]},{name:"description",type:"text",localized:!0}]},{name:"productPageNote",type:"textarea",localized:!0,admin:{description:"Short delivery note shown on every product page."}}]},n={slug:"payment-settings",label:"Payments",admin:{group:"Website Settings",description:"Turn payment methods on or off. Gateway credentials are set as server environment variables, never here."},access:{read:d.Xl,update:d.qc},fields:[{name:"gatewayStatus",type:"ui",admin:{components:{Field:"/components/admin/GatewayStatus#GatewayStatus"}}},{name:"codEnabled",label:"Cash on delivery",type:"checkbox",defaultValue:!0},(0,e.$)({name:"codMaxTotal",label:"Cash on delivery limit (৳)",admin:{description:"Optional: hide COD for orders above this total."}}),{name:"sslcommerzEnabled",label:"SSLCommerz (cards, mobile banking)",type:"checkbox",defaultValue:!1},{name:"bkashEnabled",label:"bKash",type:"checkbox",defaultValue:!1},{name:"nagadEnabled",label:"Nagad",type:"checkbox",defaultValue:!1},{name:"checkoutNote",type:"textarea",localized:!0,admin:{description:"Optional payment instructions shown at checkout."}}]},o={slug:"analytics-settings",label:"Analytics & verification",admin:{group:"Website Settings"},access:{read:d.ZZ,update:d.qc},fields:[{name:"ga4Id",label:"Google Analytics 4 measurement ID",type:"text",admin:{description:"e.g. G-XXXXXXXXXX. Leave empty to load no analytics."},validate:a=>!!(!a||/^G-[A-Z0-9]{4,}$/.test(a))||"Format: G-XXXXXXXXXX"},{name:"gtmId",label:"Google Tag Manager container ID",type:"text",admin:{description:"e.g. GTM-XXXXXXX. Use either GA4 or GTM, usually not both."},validate:a=>!!(!a||/^GTM-[A-Z0-9]{4,}$/.test(a))||"Format: GTM-XXXXXXX"},{name:"searchConsoleVerification",label:"Google Search Console verification code",type:"text",admin:{description:"Only the content value of the google-site-verification meta tag."}},{name:"requireConsent",label:"Ask visitors for consent before loading analytics",type:"checkbox",defaultValue:!0}]}},23620:(a,b,c)=>{"use strict";c.d(b,{$U:()=>k});var d=c(55511),e=c.n(d),f=c(33873),g=c.n(f),h=c(78853),i=c(8313);let j=g().resolve(process.env.MEDIA_DIR||g().join(process.cwd(),"media")),k={slug:"media",labels:{singular:"Image",plural:"Media library"},admin:{group:"Content",defaultColumns:["filename","alt","mimeType","filesize","updatedAt"]},access:{read:h.ZZ,create:h.Xl,update:h.Xl,delete:h.Xl},hooks:{beforeOperation:[({req:a,operation:b})=>{let c=a.file;if(("create"===b||"update"===b)&&c?.name){let a=g().extname(c.name).toLowerCase(),b=(0,i.Y)(g().basename(c.name,a))||"image";c.name=`${b.slice(0,40)}-${e().randomBytes(5).toString("hex")}${a}`}}]},upload:{staticDir:j,mimeTypes:["image/jpeg","image/png","image/webp","image/avif","image/svg+xml","image/x-icon","image/vnd.microsoft.icon"],focalPoint:!0,crop:!0,imageSizes:[{name:"thumbnail",width:240,height:240,position:"centre",formatOptions:{format:"webp",options:{quality:78}}},{name:"card",width:640,height:640,position:"centre",formatOptions:{format:"webp",options:{quality:80}}},{name:"large",width:1400,withoutEnlargement:!0,formatOptions:{format:"webp",options:{quality:82}}},{name:"og",width:1200,height:630,position:"centre",formatOptions:{format:"jpeg",options:{quality:82}}}],adminThumbnail:"thumbnail"},fields:[{name:"alt",type:"text",localized:!0,required:!0,admin:{description:"Describe the image for screen readers and search engines, in each language."}},{name:"credit",type:"text",admin:{description:"Photographer / licence note (internal)."}}]}},24832:(a,b,c)=>{Promise.resolve().then(c.bind(c,29760))},24942:(a,b,c)=>{"use strict";c.d(b,{XE:()=>k,b8:()=>h,fG:()=>i,gq:()=>g});var d=c(55511),e=c.n(d),f=c(37355);function g(a){return e().createHmac("sha256",f._.PAYLOAD_SECRET).update(`order-access:${a}`).digest("base64url").slice(0,32)}function h(a,b){if(!b||"string"!=typeof b)return!1;let c=Buffer.from(g(a)),d=Buffer.from(b);return c.length===d.length&&e().timingSafeEqual(c,d)}function i(a,b){return`/${a}/order/${encodeURIComponent(b)}?t=${g(b)}`}let j="23456789ABCDEFGHJKLMNPQRSTUVWXYZ";function k(a=process.env.ORDER_PREFIX||"AK",b=new Date){let c=new Date(b.getTime()+216e5).toISOString().slice(2,10).replace(/-/g,""),d=Array.from(e().randomBytes(5),a=>j[a%j.length]).join("");return`${a}-${c}-${d}`}},25006:(a,b,c)=>{"use strict";c.d(b,{Kh:()=>h,Xm:()=>i,bg:()=>k,rv:()=>g});var d=c(91970),e=c(10550),f=c(2033);async function g(a){let{lang:b}=await a;return(0,e.Zd)(b)||(0,d.notFound)(),b}function h(a){return{title:a?.title,description:a?.description,ogTitle:a?.ogTitle,ogDescription:a?.ogDescription,ogImageUrl:"object"==typeof a?.ogImage?(0,f.SG)(a.ogImage,"og"):null,canonicalUrl:a?.canonicalUrl,noindex:a?.noindex}}function i(a,b=5e3){let c=[],d=a=>{!a||"object"!=typeof a||c.join(" ").length>b||("string"==typeof a.text&&c.push(a.text),a.root&&d(a.root),Array.isArray(a.children)&&a.children.forEach(d))};return d(a),c.join(" ").replace(/\s+/g," ").trim().slice(0,b)}let j=/^#[0-9a-fA-F]{6}$/;function k(a){let b={};for(let[c,d]of Object.entries({primary:"--brand-primary",secondary:"--brand-secondary",accent:"--brand-accent",accentWarm:"--brand-accent-warm",background:"--brand-bg",text:"--brand-text"})){let e=a?.[c];e&&j.test(e)&&(b[d]=e)}return b}},26848:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{l:()=>s});var e=c(78853),f=c(3380),g=c(14915),h=c(8313),i=c(89556),j=c(79252),k=c(13972),l=c(60601),m=c(297),n=c(71189),o=c(99795),p=a([l]);l=(p.then?(await p)():p)[0];let q=async({data:a,req:b,originalDoc:c})=>{let d=a.variants??[],e=d.map(a=>(a.sku??"").trim().toUpperCase()).filter(Boolean),f=e.find((a,b)=>e.indexOf(a)!==b);if(f)throw Error(`SKU "${f}" is used twice in this product.`);if(d.forEach(a=>{a.sku&&(a.sku=a.sku.trim().toUpperCase())}),e.length){let a={"variants.sku":{in:e}};if(c?.id&&(a.id={not_equals:c.id}),(await b.payload.find({collection:"products",where:a,limit:1,depth:0,req:b,overrideAccess:!0})).docs.length)throw Error(`One of these SKUs is already used by another product: ${e.join(", ")}`)}return a},r=async({data:a,req:b,originalDoc:c,operation:d})=>{let e=a.variants??[],f=e.filter(a=>"number"==typeof a.price).map(a=>(0,k.n)({price:a.price,salePrice:a.salePrice,saleStartsAt:a.saleStartsAt,saleEndsAt:a.saleEndsAt}).unitPrice);a.minPrice=f.length?Math.min(...f):0;let g=b.locale||"bn",h={};"update"===d&&c?.id&&(h=await (0,n.N)(b,()=>b.payload.findByID({collection:"products",id:c.id,locale:"all",depth:0,req:b,overrideAccess:!0})));let i=b=>["string"==typeof a[b]?a[b]:"",("bn"===g?h[b]?.en:h[b]?.bn)??""];return a.searchText=[...i("name"),...i("shortDescription"),...a.tags??[],...e.map(a=>a.sku??"")].filter(Boolean).join(" ").toLowerCase().slice(0,4e3),a},s={slug:"products",labels:{singular:"Product",plural:"Products"},admin:{useAsTitle:"name",group:"Catalog",defaultColumns:["name","categories","minPrice","totalStock","status","featured","translationStatus"],listSearchableFields:["name","slug","searchText"],preview:(a,{locale:b})=>`/${b||"bn"}/product/${a.slug}?preview=1`,components:{beforeListTable:["/components/admin/ProductImportExport#ProductImportExport"]}},defaultSort:"sortOrder",access:{read:e.qp,create:e.Xl,update:e.Xl,delete:e.Xl},endpoints:[m.Yu,m.dE],hooks:{beforeChange:[q,r,(0,i.n)(["name","shortDescription"])],afterChange:[(0,j.L)("product"),async({doc:a,req:b})=>(await (0,l.R7)(b.payload,a.id,b),a)],beforeDelete:[async({id:a,req:b})=>{if((await b.payload.find({collection:"orders",where:{"items.product":{equals:a}},limit:1,depth:0,req:b,overrideAccess:!0})).totalDocs>0)throw Error('This product appears in existing orders and cannot be deleted. Set its status to "Hidden" instead.')}]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"name",type:"text",required:!0,localized:!0,validate:o.E},{name:"shortDescription",type:"textarea",localized:!0,maxLength:300,admin:{description:"One or two sentences for product cards and search results."}},{name:"description",type:"richText",localized:!0},{name:"images",type:"upload",relationTo:"media",hasMany:!0,admin:{description:"Drag to reorder. The first image is the main image."}},{name:"attributes",type:"array",labels:{singular:"Attribute",plural:"Attributes"},admin:{description:"Facts shown on the product page, e.g. Origin: Rajshahi, Season: June–July.",initCollapsed:!0},fields:[{type:"row",fields:[{name:"label",type:"text",required:!0,localized:!0,validate:o.E,admin:{width:"40%"}},{name:"value",type:"text",required:!0,localized:!0,validate:o.E,admin:{width:"60%"}}]}]}]},{label:"Prices & stock",fields:[{name:"variants",type:"array",minRows:1,required:!0,labels:{singular:"Size / pack",plural:"Sizes / packs"},admin:{description:"Each size or pack has its own SKU, price and stock. The first one is selected by default. Stock can be set when a size is created; afterwards change it from Inventory → Stock adjustments so every change is recorded."},fields:[{type:"row",fields:[{name:"label",type:"text",required:!0,localized:!0,validate:o.E,admin:{width:"34%",description:'e.g. "৫ কেজি" / "5 kg"'}},{name:"sku",type:"text",required:!0,admin:{width:"22%"}},{name:"packSize",type:"number",min:0,admin:{width:"20%",step:.1}},{name:"unit",type:"select",defaultValue:"kg",admin:{width:"24%"},options:[{label:"gram (g)",value:"g"},{label:"kilogram (kg)",value:"kg"},{label:"millilitre (ml)",value:"ml"},{label:"litre (l)",value:"l"},{label:"piece",value:"pcs"},{label:"jar",value:"jar"},{label:"box",value:"box"},{label:"pack",value:"pack"}]}]},{type:"row",fields:[(0,f.$)({name:"price",label:"Regular price (৳)",required:!0,admin:{width:"25%"}}),(0,f.$)({name:"salePrice",label:"Sale price (৳)",admin:{width:"25%",description:"Leave empty for no sale."}}),{name:"saleStartsAt",type:"date",admin:{width:"25%",date:{pickerAppearance:"dayAndTime"},description:"Optional sale start"}},{name:"saleEndsAt",type:"date",admin:{width:"25%",date:{pickerAppearance:"dayAndTime"},description:"Optional sale end"}}]},{type:"row",fields:[{name:"stock",type:"number",min:0,defaultValue:0,access:{update:()=>!1},admin:{width:"25%",description:"Units in stock"}},{name:"lowStockThreshold",type:"number",min:0,defaultValue:5,admin:{width:"25%"}},{name:"weightGrams",type:"number",min:0,admin:{width:"25%",description:"Shipping weight (optional)"}}]}]}]},{label:"SEO",fields:[(0,g.Z)()]}]},(0,h.O)("name"),{name:"status",type:"select",required:!0,defaultValue:"draft",index:!0,options:[{label:"Published",value:"published"},{label:"Hidden (draft)",value:"draft"}],admin:{position:"sidebar"}},{name:"categories",type:"relationship",relationTo:"categories",hasMany:!0,required:!0,admin:{position:"sidebar"}},{name:"tags",type:"text",hasMany:!0,admin:{position:"sidebar"}},{name:"featured",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"Show in homepage featured sections."}},{name:"bestSeller",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:'Show in "Popular picks".'}},{name:"isBundle",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"Combo / gift box."}},{name:"sortOrder",type:"number",defaultValue:0,admin:{position:"sidebar"}},{name:"relatedProducts",type:"relationship",relationTo:"products",hasMany:!0,admin:{position:"sidebar",description:"Optional. Otherwise products from the same category are shown."},filterOptions:({id:a})=>!a||{id:{not_equals:a}}},(0,i.I)(),(0,f.$)({name:"minPrice",label:"From price",admin:{readOnly:!0,position:"sidebar",description:"Calculated"}}),{name:"totalStock",type:"number",defaultValue:0,index:!0,admin:{readOnly:!0,position:"sidebar",description:"Calculated from sizes"}},{name:"searchText",type:"text",index:!0,admin:{hidden:!0}}]};d()}catch(a){d(a)}})},27557:(a,b,c)=>{"use strict";c.d(b,{F:()=>d});class d extends Error{details;constructor(a,b){super(a),this.details=b}}},28217:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.r(b),c.d(b,{"40410648c34a308f4247af656ac875bec82d6d7151":()=>e.Fp,"405f923ca377b7fec706e4d19e5b9c2dadb43db674":()=>e.$4,"40bcf4b42309d975efd75c3d5c50e45936eba01f15":()=>e.qd,"40d179d3d5df4d97c4bfeb30c7dc7c83a22e2edbc2":()=>e.hB,"609730f67d5f6c220e7ce3f00b7ac11339e4533ebd":()=>e.u9});var e=c(17223),f=a([e]);e=(f.then?(await f)():f)[0],d()}catch(a){d(a)}})},28878:(a,b,c)=>{"use strict";c.d(b,{I18nProvider:()=>e});var d=c(77943);let e=(0,d.registerClientReference)(function(){throw Error("Attempted to call I18nProvider() from the server but I18nProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\providers\\I18nProvider.tsx","I18nProvider");(0,d.registerClientReference)(function(){throw Error("Attempted to call useI18n() from the server but useI18n is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\providers\\I18nProvider.tsx","useI18n")},29650:(a,b,c)=>{"use strict";c.d(b,{LanguageSwitcher:()=>j});var d=c(48249),e=c(2116),f=c.n(e),g=c(19099),h=c(92340),i=c(71788);function j({className:a=""}){let{locale:b,dict:c}=(0,i.s)(),e=(0,g.usePathname)()||`/${b}`,k=(0,g.useSearchParams)(),l=k?.toString();return(0,d.jsx)("nav",{"aria-label":c.common.language,className:`flex items-center rounded-[var(--radius-control)] border border-line p-0.5 text-sm ${a}`,children:h.IB.map(a=>{let c=a===b;return(0,d.jsx)(f(),{href:`${(0,h.Ef)(e,a)}${l?`?${l}`:""}`,hrefLang:a,lang:a,"aria-current":c?"true":void 0,prefetch:!1,onClick:()=>{document.cookie=`site_lang=${a}; path=/; max-age=31536000; samesite=lax`},className:`rounded-[6px] px-2.5 py-1 transition-colors ${c?"bg-primary text-white":"text-ink-soft hover:text-primary"}`,children:h.ib[a].label},a)})})}},29734:(a,b,c)=>{"use strict";c.d(b,{Sn:()=>g,hP:()=>i});var d=c(33277),e=c(54027),f=c(71718);let g=d.Ikc({productId:d.KCZ([d.YjP().min(1).max(64),d.aig().int().positive()]),variantId:d.YjP().min(1).max(64),quantity:d.aig().int().min(1).max(50)}),h=d.Ikc({name:d.YjP().trim().min(2,"name").max(100,"name"),phone:d.YjP().trim().refine(a=>null!==(0,f.o)(a),"phone"),email:d.YjP().trim().max(200,"email").refine(a=>""===a||d.YjP().email().safeParse(a).success,"email").optional().default(""),division:d.YjP().refine(a=>e.Up.includes(a),"division"),district:d.YjP().refine(a=>e.hD.includes(a),"district"),area:d.YjP().trim().min(2,"area").max(120,"area"),address:d.YjP().trim().min(8,"address").max(400,"address"),notes:d.YjP().trim().max(500).optional().default(""),deliveryMethod:d.YjP().min(1,"deliveryMethod").max(40),paymentMethod:d.k5n(["cod","sslcommerz","bkash","nagad"],{message:"paymentMethod"})}).refine(a=>(0,e.xX)(a.district,a.division),{path:["district"],message:"district"}),i=d.Ikc({form:h,items:d.YOg(g).min(1).max(40),couponCode:d.YjP().trim().max(40).optional(),idempotencyKey:d.YjP().uuid(),locale:d.k5n(["bn","en"])})},29760:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\towfi\\\\Documents\\\\mango-shop\\\\mango-shop\\\\src\\\\app\\\\(frontend)\\\\[lang]\\\\error.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\app\\(frontend)\\[lang]\\error.tsx","default")},30755:(a,b,c)=>{"use strict";c.d(b,{E:()=>h});var d=c(46747),e=c(63678),f=c(11506),g=c(13972);function h(a){let b,{items:c,catalog:h,coupon:i,couponCode:j,zones:k=[],district:l,method:m=null,now:n=new Date}=a,o=new Map;for(let a of c){let b=`${a.productId}:${a.variantId}`,c=o.get(b);o.set(b,{...a,quantity:(c?.quantity??0)+a.quantity})}let p=[];for(let a of o.values()){let b,c=h.get(String(a.productId)),d=c?.variants.find(b=>b.id===a.variantId),e={productId:a.productId,variantId:a.variantId,slug:c?.slug??"",name:c?.name??"",variantLabel:d?.label??"",sku:d?.sku??"",imageUrl:c?.imageUrl,quantity:a.quantity};if(!c||!c.published){p.push({...e,unitPrice:0,regularPrice:0,lineTotal:0,available:0,issue:"product_unavailable"});continue}if(!d){p.push({...e,unitPrice:0,regularPrice:0,lineTotal:0,available:0,issue:"variant_unavailable"});continue}let i=(0,g.n)(d,n),j=Math.max(0,d.stock);!Number.isInteger(a.quantity)||a.quantity<1||a.quantity>50?b="invalid_quantity":0===j?b="out_of_stock":a.quantity>j&&(b="insufficient_stock"),p.push({...e,unitPrice:i.unitPrice,regularPrice:i.regularPrice,lineTotal:b?0:(0,f.lw)(i.unitPrice,a.quantity),available:j,issue:b})}let q=p.filter(a=>!a.issue),r=(0,f.cz)(q.map(a=>a.lineTotal)),s=0;if(j){let a=(0,d.A)(i,r,n);a.ok?s=a.discount:b=a.error}let t=(0,e.V)(k,l),u=q.length>0?(0,e.R)(t,m,r-s):0,v=r-s+u;return{lines:p,subtotal:r,discount:s,couponCode:j&&!b?j:void 0,couponError:b,shipping:u,total:v,itemCount:q.reduce((a,b)=>a+b.quantity,0),purchasable:q.length>0&&q.length===p.length}}},30849:(a,b,c)=>{"use strict";c.d(b,{V:()=>i});var d=c(78853),e=c(14915),f=c(99795);let g=(a,b)=>({name:a,label:b,type:"group",fields:[{type:"row",fields:[{name:"label",type:"text",localized:!0,admin:{width:"50%"}},{name:"href",type:"text",admin:{width:"50%",description:"e.g. /category/mango"}}]}]}),h=(a=!0)=>({name:"enabled",type:"checkbox",defaultValue:a}),i={slug:"homepage",label:"Homepage",admin:{group:"Content",description:"Every homepage section, in page order. Hidden sections are skipped."},access:{read:d.ZZ,update:d.Xl},fields:[{type:"tabs",tabs:[{label:"Top",fields:[{name:"announcement",label:"Announcement bar",type:"group",fields:[h(),{name:"text",type:"text",localized:!0},{name:"href",type:"text",admin:{description:"Optional link, e.g. /category/mango"}},{name:"tone",type:"select",defaultValue:"green",options:[{label:"Deep green",value:"green"},{label:"Mango yellow",value:"mango"},{label:"Cream",value:"cream"}]}]},{name:"hero",type:"group",fields:[{name:"headline",type:"text",required:!0,localized:!0,validate:f.E},{name:"subheadline",type:"textarea",localized:!0},{name:"image",type:"upload",relationTo:"media",admin:{description:"Large mango photograph or artwork. Transparent PNG/WebP cut-outs look best."}},g("primaryCta","Primary button"),g("secondaryCta","Secondary button"),{name:"seasonalBadge",type:"group",fields:[h(),{name:"text",type:"text",localized:!0,admin:{description:'e.g. "মৌসুম চলছে"'}}]}]},{name:"benefits",label:"Trust benefits",type:"array",maxRows:4,admin:{description:"Up to four short promises you can keep."},fields:[{type:"row",fields:[{name:"icon",type:"select",defaultValue:"leaf",admin:{width:"25%"},options:["leaf","package","truck","wallet","shield","phone","clock","heart"].map(a=>({label:a,value:a}))},{name:"title",type:"text",required:!0,localized:!0,validate:f.E,admin:{width:"35%"}},{name:"text",type:"text",localized:!0,admin:{width:"40%"}}]}]}]},{label:"Products",fields:[{name:"categoriesSection",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"categories",type:"relationship",relationTo:"categories",hasMany:!0,admin:{description:"In display order. Empty = featured categories."}}]},{name:"featured",label:"Featured mangoes",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"intro",type:"text",localized:!0},{name:"category",type:"relationship",relationTo:"categories",admin:{description:"Products come from this category (featured first)."}},{name:"products",type:"relationship",relationTo:"products",hasMany:!0,admin:{description:"Optional hand-picked list, overrides the category."}},{name:"limit",type:"number",defaultValue:8,min:2,max:16},g("cta","Button")]},{name:"traditional",label:"Other traditional foods",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"intro",type:"text",localized:!0},{name:"categories",type:"relationship",relationTo:"categories",hasMany:!0,admin:{description:"Which categories appear, in order."}},{name:"perCategory",type:"number",defaultValue:4,min:1,max:8}]},{name:"popular",label:"Popular products & bundles",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"products",type:"relationship",relationTo:"products",hasMany:!0,admin:{description:'Empty = products marked "best seller" and bundles.'}}]}]},{label:"Story & promo",fields:[{name:"promo",label:"Promotional banner",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"text",type:"textarea",localized:!0},{name:"image",type:"upload",relationTo:"media"},g("cta","Button")]},{name:"story",label:"Brand story",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"body",type:"textarea",localized:!0,admin:{description:"Paragraphs separated by a blank line. Only include claims you can stand behind."}},{name:"image",type:"upload",relationTo:"media"},g("cta","Button")]}]},{label:"Reviews & FAQ",fields:[{name:"testimonials",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0}],admin:{description:"Shows approved reviews that customers agreed to publish. Hidden automatically when there are none."}},{name:"faq",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0}]}]},{label:"SEO",fields:[(0,e.Z)()]}]}]}},31015:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{m:()=>h});var e=c(79251),f=c(14408),g=a([e]);function h(){return(0,f.nm0)({config:e.A})}e=(g.then?(await g)():g)[0],d()}catch(a){d(a)}})},31245:(a,b,c)=>{"use strict";c.d(b,{Uz:()=>h,Vw:()=>i,cE:()=>f,nK:()=>j,sZ:()=>g,sw:()=>e});let d=a=>(a/100).toFixed(2);function e(a){return{"@context":"https://schema.org","@type":"Organization",name:a.name,url:a.url,...a.logoUrl?{logo:a.logoUrl}:{},...a.phone||a.email?{contactPoint:[{"@type":"ContactPoint",contactType:"customer service",telephone:a.phone||void 0,email:a.email||void 0,areaServed:"BD",availableLanguage:["bn","en"]}]}:{},...a.sameAs?.length?{sameAs:a.sameAs}:{}}}function f(a){return{"@context":"https://schema.org","@type":"WebSite",name:a.name,url:a.url,inLanguage:a.locale,potentialAction:{"@type":"SearchAction",target:{"@type":"EntryPoint",urlTemplate:`${a.searchUrl}?q={search_term_string}`},"query-input":"required name=search_term_string"}}}function g(a){return{"@context":"https://schema.org","@type":"BreadcrumbList",itemListElement:a.map((a,b)=>({"@type":"ListItem",position:b+1,name:a.name,item:a.url}))}}function h(a){let b=a.variants.map(b=>({"@type":"Offer",sku:b.sku,name:b.name,url:a.url,priceCurrency:"BDT",price:d(b.price),...b.saleEndsAt?{priceValidUntil:b.saleEndsAt.slice(0,10)}:{},availability:b.inStock?"https://schema.org/InStock":"https://schema.org/OutOfStock",itemCondition:"https://schema.org/NewCondition"})),c=a.variants.map(a=>a.price),e=(a.ratings??[]).filter(a=>Number.isFinite(a)&&a>=1&&a<=5);return{"@context":"https://schema.org","@type":"Product",name:a.name,description:a.description,url:a.url,sku:a.sku,inLanguage:a.locale,image:a.images,brand:{"@type":"Brand",name:a.brand},...a.category?{category:a.category}:{},offers:1===b.length?b[0]:{"@type":"AggregateOffer",priceCurrency:"BDT",lowPrice:d(Math.min(...c)),highPrice:d(Math.max(...c)),offerCount:b.length,offers:b},...e.length?{aggregateRating:{"@type":"AggregateRating",ratingValue:(e.reduce((a,b)=>a+b,0)/e.length).toFixed(1),reviewCount:e.length}}:{}}}function i(a){return{"@context":"https://schema.org","@type":"Article",headline:a.headline,description:a.description,url:a.url,inLanguage:a.locale,...a.image?{image:[a.image]}:{},datePublished:a.datePublished,dateModified:a.dateModified,author:a.author?{"@type":"Person",name:a.author}:{"@type":"Organization",name:a.publisher},publisher:{"@type":"Organization",name:a.publisher}}}function j(a){return JSON.stringify(a).replace(/</g,"\\u003c").replace(/>/g,"\\u003e").replace(/&/g,"\\u0026")}},32073:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81921,23)),Promise.resolve().then(c.t.bind(c,60440,23)),Promise.resolve().then(c.t.bind(c,84342,23)),Promise.resolve().then(c.t.bind(c,82265,23)),Promise.resolve().then(c.t.bind(c,35421,23)),Promise.resolve().then(c.t.bind(c,61335,23)),Promise.resolve().then(c.t.bind(c,70664,23)),Promise.resolve().then(c.bind(c,74661))},34184:(a,b,c)=>{"use strict";c.d(b,{CartDrawer:()=>r});var d=c(48249),e=c(28313),f=c(45535),g=c(35471),h=c(39041),i=c(81220),j=c(2116),k=c.n(j),l=c(19099),m=c(67484),n=c(87224),o=c(71788),p=c(46883),q=c(21222);function r(){let{lines:a,drawerOpen:b,setDrawerOpen:c,setQuantity:j,remove:r,lastAdded:s,dismissLastAdded:t}=(0,n._)(),{dict:u,locale:v,price:w,t:x}=(0,o.s)(),y=(0,l.usePathname)(),{data:z,loading:A}=(0,q._)({enabled:b,withCoupon:!1}),[B,C]=(0,m.useState)(y);return B!==y&&(C(y),b&&c(!1)),(0,d.jsx)(e.bL,{open:b,onOpenChange:c,children:(0,d.jsxs)(e.ZL,{children:[(0,d.jsx)(e.hJ,{className:"drawer-overlay fixed inset-0 z-50 bg-ink/40"}),(0,d.jsxs)(e.UC,{"data-testid":"cart-drawer",className:"drawer-panel fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col bg-cream shadow-2xl focus:outline-none","aria-describedby":void 0,children:[(0,d.jsxs)("div",{className:"flex items-center justify-between border-b border-line px-5 py-4",children:[(0,d.jsx)(e.hE,{className:"font-display text-2xl text-primary",children:s?u.cart.addedTitle:u.cart.title}),(0,d.jsx)(e.bm,{"aria-label":u.common.close,className:"inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-control)] hover:bg-leaf-tint",children:(0,d.jsx)(f.A,{className:"h-6 w-6","aria-hidden":!0})})]}),0===a.length?(0,d.jsxs)("div",{className:"flex flex-1 flex-col items-start justify-center gap-3 px-6",children:[(0,d.jsx)("p",{className:"font-display text-2xl text-primary",children:u.cart.empty}),(0,d.jsx)("p",{className:"text-ink-soft",children:u.cart.emptyHint}),(0,d.jsx)(k(),{href:`/${v}/shop`,className:"mt-2 inline-flex h-11 items-center rounded-[var(--radius-control)] bg-primary px-5 font-medium text-white hover:bg-primary-deep",children:u.cart.startShopping})]}):(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)("ul",{className:"flex-1 divide-y divide-line overflow-y-auto px-5","aria-busy":A,children:a.map(a=>{let b,c,e=(b=a.productId,c=a.variantId,z?.totals.lines.find(a=>Number(a.productId)===b&&a.variantId===c)),f=s&&s.line.productId===a.productId&&s.line.variantId===a.variantId;return(0,d.jsxs)("li",{className:`flex gap-3 py-4 ${f?"relative":""}`,children:[(0,d.jsx)("div",{className:"relative h-20 w-20 shrink-0 overflow-hidden rounded-[10px] bg-mango-tint",children:a.snapshot.imageUrl&&(0,d.jsx)(i.A,{src:a.snapshot.imageUrl,alt:"",fill:!0,sizes:"80px",className:"object-cover"})}),(0,d.jsxs)("div",{className:"min-w-0 flex-1",children:[f&&(0,d.jsxs)("p",{className:"mb-1 inline-flex items-center gap-1 text-xs font-medium text-secondary",children:[(0,d.jsx)(g.A,{className:"h-3.5 w-3.5","aria-hidden":!0})," ",u.product.added]}),(0,d.jsx)(k(),{href:`/${v}/product/${a.snapshot.slug}`,className:"line-clamp-2 font-medium hover:text-primary",children:e?.name||a.snapshot.name}),(0,d.jsx)("p",{className:"text-sm text-ink-soft",children:e?.variantLabel||a.snapshot.variantLabel}),e?.issue&&(0,d.jsx)("p",{className:"mt-1 text-sm text-danger",children:x(u.cart.issues[e.issue],{available:e.available})}),(0,d.jsxs)("div",{className:"mt-2 flex items-center justify-between gap-2",children:[(0,d.jsx)(p.V,{size:"sm",value:a.quantity,onChange:b=>j(a.productId,a.variantId,b),max:Math.min(50,e?.available||50)}),(0,d.jsx)("span",{className:"font-semibold tabular-nums",children:w(e?e.unitPrice*a.quantity:a.snapshot.unitPrice*a.quantity)})]})]}),(0,d.jsx)("button",{type:"button",onClick:()=>r(a.productId,a.variantId),"aria-label":x(u.cart.removeItem,{name:a.snapshot.name}),className:"self-start p-1 text-ink-soft hover:text-danger",children:(0,d.jsx)(h.A,{className:"h-4 w-4","aria-hidden":!0})})]},`${a.productId}:${a.variantId}`)})}),(0,d.jsxs)("div",{className:"border-t border-line bg-paper px-5 py-4 pb-[calc(16px+env(safe-area-inset-bottom))]",children:[(0,d.jsxs)("div",{className:"flex items-center justify-between text-lg",children:[(0,d.jsx)("span",{children:u.cart.subtotal}),(0,d.jsx)("span",{className:"font-semibold tabular-nums","aria-live":"polite",children:z?w(z.totals.subtotal):A?u.common.loading:"—"})]}),(0,d.jsxs)("p",{className:"mt-1 text-sm text-ink-soft",children:[u.cart.shipping,": ",u.cart.shippingAtCheckout]}),(0,d.jsxs)("div",{className:"mt-4 grid grid-cols-2 gap-2",children:[(0,d.jsx)(k(),{href:`/${v}/cart`,className:"inline-flex h-12 items-center justify-center rounded-[var(--radius-control)] border border-primary font-medium text-primary hover:bg-leaf-tint",children:u.cart.viewCart}),(0,d.jsx)(k(),{href:`/${v}/checkout`,className:"inline-flex h-12 items-center justify-center rounded-[var(--radius-control)] bg-primary font-medium text-white hover:bg-primary-deep",children:u.cart.checkout})]}),(0,d.jsx)(e.bm,{className:"mt-2 w-full py-2 text-sm text-ink-soft underline-offset-4 hover:underline",children:u.cart.continueShopping})]})]})]})]})})}},35209:(a,b,c)=>{"use strict";c.d(b,{$g:()=>f,GW:()=>g});var d=c(92340);let e=new Map;function f(a,b){var c;let f,g,h=(c=2*(a%100!=0),f=`${b}:${c}`,!(g=e.get(f))&&(g=new Intl.NumberFormat(d.ib[b].intl,{minimumFractionDigits:c,maximumFractionDigits:c}),e.set(f,g)),g).format(a/100);return"bn"===b?`৳ ${h}`:`৳${h}`}function g(a,b){return a.replace(/\{(\w+)\}/g,(a,c)=>c in b?String(b[c]):`{${c}}`)}},35642:(a,b,c)=>{"use strict";c.d(b,{WhatsAppButton:()=>k});var d=c(48249),e=c(19099),f=c(67484),g=c(71788),h=c(92685);let i=()=>()=>{};function j(){return(0,d.jsxs)("svg",{viewBox:"0 0 32 32",className:"h-7 w-7","aria-hidden":!0,focusable:"false",children:[(0,d.jsx)("path",{fill:"#fff",d:"M16 3.2C9 3.2 3.3 8.8 3.3 15.7c0 2.4.7 4.7 2 6.7L3.2 28.8l6.6-2c1.9 1 4 1.6 6.2 1.6 7 0 12.7-5.6 12.7-12.6S23 3.2 16 3.2zm0 22.9c-2 0-3.9-.5-5.5-1.5l-.4-.2-3.9 1.2 1.3-3.8-.3-.4a10.2 10.2 0 0 1-1.6-5.6C5.6 10 10.3 5.5 16 5.5s10.4 4.6 10.4 10.3S21.7 26.1 16 26.1z"}),(0,d.jsx)("path",{fill:"#fff",d:"M21.7 18.5c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.6c.2-.2.2-.3.3-.6.1-.2 0-.4 0-.6l-1-2.3c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.7s1.2 3.2 1.4 3.4c.2.2 2.4 3.6 5.7 5 .8.3 1.4.5 1.9.7.8.2 1.5.2 2.1.1.6-.1 1.8-.7 2.1-1.5.3-.7.3-1.4.2-1.5-.1-.1-.3-.2-.6-.3z"})]})}function k({number:a,messageBn:b,messageEn:c,tooltip:l,position:m,showOn:n}){let o,{locale:p,dict:q,t:r}=(0,g.s)(),s=(0,e.usePathname)()||"",t=(0,h.X)(),u=(o=s.split("/")[2]??"")?({shop:"shop",category:"category",product:"product",cart:"cart",checkout:"checkout",blog:"blog",pages:"pages",order:"order","track-order":"order"})[o]??"other":"home",v=(0,f.useSyncExternalStore)(i,()=>window.location.origin,()=>null);if(!v||!n.includes("other"===u?"pages":u))return null;let w="bn"===p?b:c;"product"===u&&t.productName?w=r(q.whatsapp.productMessage,{name:t.productName,url:`${v}${s}`}):("cart"===u||"checkout"===u)&&(w=q.whatsapp.cartMessage);let x=function(a,b){let c=a.replace(/\D/g,"");if(c.length<8||c.length>15)return null;let d=b.trim();return`https://wa.me/${c}${d?`?text=${encodeURIComponent(d)}`:""}`}(a,w);if(!x)return null;let y="product"===u||"cart"===u||"checkout"===u;return(0,d.jsxs)("a",{href:x,target:"_blank",rel:"noopener noreferrer","aria-label":q.whatsapp.label,"data-testid":"whatsapp-button",className:`wa-in group fixed ${"left"===m?"left-4":"right-4"} z-30 flex items-center gap-2 rounded-full bg-[#1FAF54] p-3 text-white shadow-[0_6px_20px_-6px_rgba(20,80,40,0.6)] transition-transform hover:scale-105 hover:bg-[#1a9a49] focus-visible:outline-offset-4 ${y?"bottom-[calc(88px+env(safe-area-inset-bottom))] md:bottom-6":"bottom-[calc(20px+env(safe-area-inset-bottom))] md:bottom-6"}`,children:[(0,d.jsx)(j,{}),l&&(0,d.jsx)("span",{className:"hidden max-w-0 overflow-hidden whitespace-nowrap pr-0 text-sm font-medium transition-all duration-300 group-hover:max-w-56 group-hover:pr-2 md:inline",children:l})]})}},37025:(a,b,c)=>{"use strict";c.d(b,{CartButton:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call CartButton() from the server but CartButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\layout\\CartButton.tsx","CartButton")},37355:(a,b,c)=>{"use strict";c.d(b,{_:()=>j});let d="phase-production-build"===process.env.NEXT_PHASE;function e(a,b){let c=process.env[a];if(c&&c.trim())return c.trim();if(d)return b??"";throw Error(`Missing required environment variable ${a}. See .env.example.`)}let f=a=>{let b=process.env[a];return b&&b.trim()?b.trim():void 0},g=(a,b)=>{let c=Number(process.env[a]);return Number.isFinite(c)&&c>0?c:b},h=(a,b=!1)=>{let c=process.env[a];return null==c||""===c?b:["1","true","yes"].includes(c.toLowerCase())},i=e("PAYLOAD_SECRET","dev-only-insecure-secret-change-me");if(!d&&i.length<32)throw Error("PAYLOAD_SECRET must be at least 32 characters in production.");let j={isProd:!0,DATABASE_URL:e("DATABASE_URL","postgres://mango:mango_dev_pw@127.0.0.1:5432/mango_shop"),DATABASE_POOL_MAX:g("DATABASE_POOL_MAX",10),DATABASE_PUSH:!1,PAYLOAD_SECRET:i,NEXT_PUBLIC_SERVER_URL:(f("NEXT_PUBLIC_SERVER_URL")||"http://localhost:3000").replace(/\/$/,""),MAX_UPLOAD_BYTES:g("MAX_UPLOAD_BYTES",8388608),S3_BUCKET:f("S3_BUCKET"),S3_REGION:f("S3_REGION"),S3_ENDPOINT:f("S3_ENDPOINT"),S3_PREFIX:f("S3_PREFIX"),S3_ACCESS_KEY_ID:f("S3_ACCESS_KEY_ID"),S3_SECRET_ACCESS_KEY:f("S3_SECRET_ACCESS_KEY"),S3_FORCE_PATH_STYLE:h("S3_FORCE_PATH_STYLE",!1),SMTP_HOST:f("SMTP_HOST"),SMTP_PORT:g("SMTP_PORT",587),SMTP_USER:f("SMTP_USER"),SMTP_PASS:f("SMTP_PASS"),EMAIL_FROM_ADDRESS:f("EMAIL_FROM_ADDRESS"),EMAIL_FROM_NAME:f("EMAIL_FROM_NAME"),ORDER_NOTIFICATION_EMAIL:f("ORDER_NOTIFICATION_EMAIL"),PAYMENTS_SANDBOX:h("PAYMENTS_SANDBOX",!0),SSLCOMMERZ_STORE_ID:f("SSLCOMMERZ_STORE_ID"),SSLCOMMERZ_STORE_PASSWORD:f("SSLCOMMERZ_STORE_PASSWORD"),BKASH_APP_KEY:f("BKASH_APP_KEY"),BKASH_APP_SECRET:f("BKASH_APP_SECRET"),BKASH_USERNAME:f("BKASH_USERNAME"),BKASH_PASSWORD:f("BKASH_PASSWORD"),BKASH_BASE_URL:f("BKASH_BASE_URL"),NAGAD_MERCHANT_ID:f("NAGAD_MERCHANT_ID"),NAGAD_MERCHANT_NUMBER:f("NAGAD_MERCHANT_NUMBER"),NAGAD_MERCHANT_PRIVATE_KEY:f("NAGAD_MERCHANT_PRIVATE_KEY"),NAGAD_PG_PUBLIC_KEY:f("NAGAD_PG_PUBLIC_KEY"),NAGAD_BASE_URL:f("NAGAD_BASE_URL")}},43196:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{A:()=>F});var e=c(71452),f=c(77502),g=c(65707),h=c(51236),i=c(33873),j=c.n(i),k=c(26915),l=c(42482),m=c(69752),n=c(1932),o=c(6180),p=c(1935),q=c(58001),r=c(86239),s=c(23620),t=c(9743),u=c(16589),v=c(26848),w=c(95014),x=c(55276),y=c(30849),z=c(21954),A=c(37355),B=a([l,m,t,v,w,e]);[l,m,t,v,w,e]=B.then?(await B)():B;let C=(0,n.fileURLToPath)("file:///C:/Users/towfi/Documents/mango-shop/mango-shop/src/payload.config.ts"),D=j().dirname(C),E=[];A._.S3_BUCKET&&E.push((0,h.u)({collections:{media:{prefix:A._.S3_PREFIX||"media"}},bucket:A._.S3_BUCKET,config:{region:A._.S3_REGION||"auto",endpoint:A._.S3_ENDPOINT||void 0,forcePathStyle:A._.S3_FORCE_PATH_STYLE,credentials:{accessKeyId:A._.S3_ACCESS_KEY_ID||"",secretAccessKey:A._.S3_SECRET_ACCESS_KEY||""}}}));let F=(0,k.f)({serverURL:A._.NEXT_PUBLIC_SERVER_URL,secret:A._.PAYLOAD_SECRET,admin:{user:x.z.slug,avatar:"default",meta:{titleSuffix:" — Admin",robots:"noindex, nofollow"},importMap:{baseDir:j().resolve(D)},components:{beforeDashboard:["/components/admin/Dashboard#Dashboard"],graphics:{Logo:"/components/admin/AdminLogo#AdminLogo",Icon:"/components/admin/AdminLogo#AdminIcon"}},dateFormat:"d MMM yyyy, h:mm a"},collections:[v.l,o.L,w.X,t.ao,u.y,r.C,q.S,s.$U,p.au,p.bZ,p.AF,p.bQ,p.AC,x.z],globals:[y.V,z.Me,z.cu,z.Vx,z.CQ,z.Gg,z.sW],localization:{locales:[{code:"bn",label:"বাংলা"},{code:"en",label:"English"}],defaultLocale:"bn",fallback:!0},i18n:{fallbackLanguage:"en"},editor:(0,g.qf)(),typescript:{outputFile:j().resolve(D,"payload-types.ts")},db:(0,e.V8)({pool:{connectionString:A._.DATABASE_URL,max:A._.DATABASE_POOL_MAX},migrationDir:j().resolve(D,"migrations"),push:A._.DATABASE_PUSH,..."true"===process.env.RUN_MIGRATIONS_ON_START?{prodMigrations:m.w}:{}}),email:A._.SMTP_HOST?(0,f.y)({defaultFromAddress:A._.EMAIL_FROM_ADDRESS||"no-reply@example.com",defaultFromName:A._.EMAIL_FROM_NAME||"Shop",transportOptions:{host:A._.SMTP_HOST,port:A._.SMTP_PORT,secure:465===A._.SMTP_PORT,auth:A._.SMTP_USER?{user:A._.SMTP_USER,pass:A._.SMTP_PASS}:void 0}}):void 0,upload:{limits:{fileSize:A._.MAX_UPLOAD_BYTES}},cors:[A._.NEXT_PUBLIC_SERVER_URL],csrf:[A._.NEXT_PUBLIC_SERVER_URL],graphQL:{disable:!0},sharp:l.default,plugins:E,telemetry:!1});d()}catch(a){d(a)}})},45417:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>i});var d=c(48249),e=c(2116),f=c.n(e);function g({className:a="h-9 w-9",tone:b="color"}){return(0,d.jsxs)("svg",{viewBox:"0 0 48 48",className:a,"aria-hidden":!0,focusable:"false",children:[(0,d.jsx)("path",{d:"M25.5 9.5c-1.6-4.6 1.4-7.6 6.4-8.3-.5 4.6-2.4 7-6.4 8.3z",fill:"light"===b?"#CFE3B8":"var(--color-secondary)"}),(0,d.jsx)("path",{d:"M24.4 10.2C34.6 10 41.8 17.6 41.4 28.3 41 38.4 33 45 23.7 44.4 13.9 43.8 7.3 36.7 8.6 27.4 9.9 17.8 15.9 10.4 24.4 10.2z",fill:"var(--color-accent-warm)"}),(0,d.jsx)("path",{d:"M24.4 10.2c7.8-.2 13.8 4.3 16 11.2-5.6-4.6-13.7-5.3-20.6-1.5-3.6 2-6.4 5-8.4 8.6 1.2-9.8 6.4-18.1 13-18.3z",fill:"var(--color-accent)",opacity:".9"}),(0,d.jsx)("path",{d:"M17.5 20.5c-3.3 2.3-5 5.7-5.2 9.6",stroke:"#FFF4C7",strokeWidth:"2.4",strokeLinecap:"round",fill:"none",opacity:".85"})]})}c(81220);var h=c(71788);function i(){let{dict:a,locale:b}=(0,h.s)();return(0,d.jsxs)("div",{className:"container-page flex min-h-[55vh] flex-col items-start justify-center py-16",children:[(0,d.jsx)(g,{className:"h-14 w-14"}),(0,d.jsx)("h1",{className:"mt-6 text-[clamp(2rem,5vw,3.4rem)] text-primary",children:a.notFound.title}),(0,d.jsx)("p",{className:"mt-3 max-w-[48ch] text-lg text-ink-soft",children:a.notFound.body}),(0,d.jsxs)("div",{className:"mt-8 flex flex-wrap gap-3",children:[(0,d.jsx)(f(),{href:`/${b}`,className:"inline-flex h-12 items-center rounded-[var(--radius-control)] bg-primary px-6 font-medium text-white hover:bg-primary-deep",children:a.common.home}),(0,d.jsx)(f(),{href:`/${b}/shop`,className:"inline-flex h-12 items-center rounded-[var(--radius-control)] border border-primary px-6 font-medium text-primary hover:bg-leaf-tint",children:a.nav.shop})]})]})}},46747:(a,b,c)=>{"use strict";c.d(b,{A:()=>f,Z:()=>e});var d=c(11506);function e(a){return a.trim().toUpperCase().replace(/\s+/g,"")}function f(a,b,c=new Date){if(!a)return{ok:!1,error:"coupon_not_found"};if(!a.active)return{ok:!1,error:"coupon_inactive"};let e=c.getTime();if(a.startsAt&&e<new Date(a.startsAt).getTime())return{ok:!1,error:"coupon_not_started"};if(a.endsAt&&e>new Date(a.endsAt).getTime())return{ok:!1,error:"coupon_expired"};if(null!=a.usageLimit&&a.usageLimit>0&&(a.usedCount??0)>=a.usageLimit)return{ok:!1,error:"coupon_usage_limit"};if(null!=a.minSubtotal&&b<a.minSubtotal)return{ok:!1,error:"coupon_min_subtotal"};let g="percent"===a.type?(0,d.pR)(b,a.value):Math.round(a.value);return null!=a.maxDiscount&&a.maxDiscount>0&&(g=Math.min(g,a.maxDiscount)),{ok:!0,discount:(0,d.qE)(g,0,b)}}},46883:(a,b,c)=>{"use strict";c.d(b,{V:()=>h});var d=c(48249),e=c(32823),f=c(69473),g=c(71788);function h({value:a,onChange:b,max:c=50,min:i=1,size:j="md",label:k}){let{dict:l,locale:m}=(0,g.s)(),n="sm"===j?"h-9":"h-11",o="sm"===j?"w-9":"w-11";return(0,d.jsxs)("div",{role:"group","aria-label":k??l.product.quantity,className:`inline-flex items-center rounded-[var(--radius-control)] border border-line bg-paper ${n}`,children:[(0,d.jsx)("button",{type:"button",onClick:()=>b(Math.max(i,a-1)),disabled:a<=i,"aria-label":l.product.decrease,className:`inline-flex ${n} ${o} items-center justify-center text-primary disabled:opacity-35`,children:(0,d.jsx)(e.A,{className:"h-4 w-4","aria-hidden":!0})}),(0,d.jsx)("output",{"aria-live":"polite",className:"min-w-8 text-center font-medium tabular-nums",children:a.toLocaleString("bn"===m?"bn-BD":"en")}),(0,d.jsx)("button",{type:"button",onClick:()=>b(Math.min(c,a+1)),disabled:a>=c,"aria-label":l.product.increase,className:`inline-flex ${n} ${o} items-center justify-center text-primary disabled:opacity-35`,children:(0,d.jsx)(f.A,{className:"h-4 w-4","aria-hidden":!0})})]})}},47138:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{v:()=>g});var e=c(60601),f=a([e]);async function g(a,b){let c=new Set;for(let d of b.items??[]){let f="object"==typeof d.product&&d.product?d.product.id:d.product;if(!f||!d.variantId)continue;let g=await (0,e.hP)(a.payload,{productId:f,variantId:d.variantId,delta:d.quantity},a);g&&(c.add(Number(f)),await a.payload.create({collection:"stock-adjustments",req:a,overrideAccess:!0,data:{sku:d.sku??"",delta:d.quantity,reason:"order_cancel",product:Number(f),variantId:d.variantId,order:b.id,stockBefore:g.before,stockAfter:g.after,createdBy:a.user?.email??"system",systemGenerated:!0,note:`Cancelled ${b.orderNumber}`}}))}for(let b of c)await (0,e.R7)(a.payload,b,a)}e=(f.then?(await f)():f)[0],d()}catch(a){d(a)}})},48773:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{Bm:()=>s,M$:()=>y,N7:()=>B,OD:()=>m,Pt:()=>o,Qi:()=>p,RS:()=>l,VX:()=>t,bW:()=>v,eh:()=>C,k6:()=>z,pH:()=>u,pI:()=>w,t1:()=>A,y0:()=>q});var e=c(65573),f=c(91986),g=c(61236),h=c(31211),i=c(2033),j=c(31015),k=a([j]);function l(a,b="card"){if(!a||"object"!=typeof a)return null;let c=(0,i.SG)(a,b),d=(0,i.YX)(a,b);return c&&d?{url:c,...d,alt:a.alt??""}:null}function m(a){return(a.variants??[]).map(a=>{let b=(0,h.n)({price:a.price,salePrice:a.salePrice,saleStartsAt:a.saleStartsAt,saleEndsAt:a.saleEndsAt});return{id:a.id,label:a.label,sku:a.sku,price:b.unitPrice,regularPrice:b.regularPrice,onSale:b.onSale,discountPercent:b.discountPercent,stock:Math.max(0,a.stock??0),lowStockThreshold:a.lowStockThreshold??5}})}function n(a){let b=Array.isArray(a.images)?a.images[0]:void 0;return{id:a.id,slug:a.slug,name:a.name,shortDescription:a.shortDescription??"",image:l(b,"card"),variants:m(a),isBundle:!!a.isBundle,featured:!!a.featured}}j=(k.then?(await k)():k)[0];let r=(0,f.cache)(async()=>{try{let a=await (0,j.m)(),{user:b}=await a.auth({headers:await (0,e.b3)()});return(0,g.hf)(b,"admin","manager","editor")}catch{return!1}}),s=(0,f.cache)(async a=>{let b=await (0,j.m)(),[c,d,e,f]=await Promise.all([b.findGlobal({slug:"branding",locale:a,depth:1}),b.findGlobal({slug:"contact-settings",locale:a,depth:0}),b.findGlobal({slug:"navigation",locale:a,depth:0}),b.findGlobal({slug:"analytics-settings",depth:0})]);return{branding:c,contact:d,navigation:e,analytics:f}}),t=(0,f.cache)(async a=>(await (0,j.m)()).findGlobal({slug:"homepage",locale:a,depth:1})),u=(0,f.cache)(async a=>{let b=await (0,j.m)();return(await b.findGlobal({slug:"delivery-settings",locale:a,depth:0})).productPageNote??""}),v=(0,f.cache)(async a=>{let b=await (0,j.m)();return(await b.find({collection:"categories",locale:a,depth:1,limit:200,sort:"sortOrder",overrideAccess:!1,pagination:!1})).docs}),w=(0,f.cache)(async(a,b)=>{let c=await (0,j.m)();return(await c.find({collection:"categories",locale:a,depth:1,limit:1,where:{slug:{equals:b}},overrideAccess:!1})).docs[0]??null}),x={featured:["-featured","sortOrder","-createdAt"],newest:["-createdAt"],price_asc:["minPrice","sortOrder"],price_desc:["-minPrice","sortOrder"]};async function o(a,b={}){let c=await (0,j.m)(),d=[{status:{equals:"published"}}];if(b.category){let c=await w(a,b.category);if(!c)return{docs:[],totalDocs:0,totalPages:0,page:1};let e=(await v(a)).filter(a=>("object"==typeof a.parent?a.parent?.id:a.parent)===c.id);d.push({categories:{in:[c.id,...e.map(a=>a.id)]}})}b.q?.trim()&&d.push({searchText:{like:b.q.trim().toLowerCase().slice(0,80)}}),b.inStock&&d.push({totalStock:{greater_than:0}}),null!=b.minPrice&&d.push({minPrice:{greater_than_equal:b.minPrice}}),null!=b.maxPrice&&d.push({minPrice:{less_than_equal:b.maxPrice}}),b.ids?.length&&d.push({id:{in:b.ids}}),b.excludeId&&d.push({id:{not_equals:b.excludeId}}),b.featured&&d.push({featured:{equals:!0}}),b.bestSeller&&d.push({or:[{bestSeller:{equals:!0}},{isBundle:{equals:!0}}]});let e=await c.find({collection:"products",locale:a,depth:1,where:{and:d},sort:x[b.sort??"featured"],page:b.page??1,limit:b.limit??12,overrideAccess:!1}),f=e.docs.map(n);return b.ids?.length&&(f=b.ids.map(a=>f.find(b=>b.id===a)).filter(a=>!!a)),{docs:f,totalDocs:e.totalDocs,totalPages:e.totalPages,page:e.page??1}}let y=(0,f.cache)(async(a,b,c=!1)=>{let d=await (0,j.m)(),e=c&&await r();return(await d.find({collection:"products",locale:a,depth:2,limit:1,where:e?{slug:{equals:b}}:{and:[{slug:{equals:b}},{status:{equals:"published"}}]},overrideAccess:e})).docs[0]??null});async function p(a,b){let c=await (0,j.m)(),d=await c.find({collection:"redirects",where:{and:[{type:{equals:a}},{fromSlug:{equals:b}}]},limit:1,depth:0});return d.docs[0]?.toSlug??null}let z=(0,f.cache)(async(a,b=!1)=>{let c=await (0,j.m)();return(await c.find({collection:"faqs",locale:a,depth:0,limit:50,sort:"sortOrder",where:b?{showOnHome:{equals:!0}}:void 0,overrideAccess:!1})).docs}),A=(0,f.cache)(async a=>{let b=await (0,j.m)();return(await b.find({collection:"testimonials",locale:a,depth:0,limit:6,sort:"-createdAt",overrideAccess:!1})).docs});async function q(a,b=1,c=9){return(await (0,j.m)()).find({collection:"posts",locale:a,depth:1,page:b,limit:c,sort:"-publishedAt",overrideAccess:!1})}let B=(0,f.cache)(async(a,b,c=!1)=>{let d=await (0,j.m)(),e=c&&await r();return(await d.find({collection:"posts",locale:a,depth:1,limit:1,where:e?{slug:{equals:b}}:{and:[{slug:{equals:b}},{status:{equals:"published"}}]},overrideAccess:e})).docs[0]??null}),C=(0,f.cache)(async(a,b,c=!1)=>{let d=await (0,j.m)(),e=c&&await r();return(await d.find({collection:"pages",locale:a,depth:1,limit:1,where:e?{slug:{equals:b}}:{and:[{slug:{equals:b}},{status:{equals:"published"}}]},overrideAccess:e})).docs[0]??null});(0,f.cache)(async a=>{let b=await (0,j.m)();return(await b.find({collection:"pages",locale:a,depth:0,limit:20,overrideAccess:!1,sort:"title"})).docs}),d()}catch(a){d(a)}})},51105:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81921,23))},52625:(a,b,c)=>{"use strict";function d(a,b){if("string"==typeof a)return a;if(a&&"object"==typeof a){let c=a[b];if("string"==typeof c&&c.trim())return c;let d=a["bn"===b?"en":"bn"];if("string"==typeof d)return d}return""}c.d(b,{LB:()=>f,bI:()=>g,B1:()=>h}),c(99139);var e=c(71189);async function f(a,b,c,f){let g=[...new Set(b.map(a=>Number(a)).filter(a=>Number.isInteger(a)&&a>0))],h=new Map;if(!g.length)return h;for(let b of(await (0,e.N)(f,()=>a.find({collection:"products",where:{id:{in:g}},locale:"all",depth:1,limit:g.length,overrideAccess:!0,pagination:!1,req:f}))).docs){let a=Array.isArray(b.images)?b.images[0]:void 0,e={},f=(b.variants??[]).map(a=>(e[a.id]={bn:d(a.label,"bn"),en:d(a.label,"en")},{id:a.id,sku:a.sku,label:d(a.label,c),price:a.price,salePrice:a.salePrice??null,saleStartsAt:a.saleStartsAt??null,saleEndsAt:a.saleEndsAt??null,stock:a.stock??0}));h.set(String(b.id),{id:b.id,slug:b.slug,name:d(b.name,c),nameBn:d(b.name,"bn"),nameEn:d(b.name,"en"),published:"published"===b.status,imageUrl:"object"==typeof a&&a?function(a,b){if(!a||"object"!=typeof a)return null;let c=(b?a.sizes?.[b]?.url:null)||a.url||null;return c?function(a){let b=/^https?:\/\/[^/]+(\/api\/media\/file\/.*)$/.exec(a);return b?b[1]:a}(c):null}(a,"thumbnail"):null,variants:f,variantNames:e})}return h}async function g(a,b,c){if(!b)return null;let d=(await a.find({collection:"coupons",where:{code:{equals:b}},limit:1,depth:0,overrideAccess:!0,req:c})).docs[0];return d?{id:d.id,code:d.code,active:!!d.active,type:d.type,value:"percent"===d.type?d.percent??0:d.amount??0,minSubtotal:d.minSubtotal??null,maxDiscount:d.maxDiscount??null,startsAt:d.startsAt??null,endsAt:d.endsAt??null,usageLimit:d.usageLimit??null,usedCount:d.usedCount??0}:null}async function h(a,b,c){let d=await a.findGlobal({slug:"delivery-settings",locale:b,depth:0,overrideAccess:!0,req:c});return{zones:(d.zones??[]).map(a=>({code:a.code,name:a.name??a.code,estimate:a.estimate??"",fee:a.fee??0,freeOver:a.freeOver??null,districts:a.districts??[],isDefault:a.isDefault??!1,enabled:a.enabled??!0})),methods:(d.methods??[]).filter(a=>!1!==a.enabled).map(a=>({code:a.code,name:a.name??a.code,description:a.description??"",surcharge:a.surcharge??0,enabled:!0})),productPageNote:d.productPageNote??""}}},53438:(a,b,c)=>{"use strict";c.d(b,{f:()=>f});var d=c(78853),e=c(64442);let f={path:"/export.csv",method:"get",handler:async a=>{if(!(0,d.hf)(a.user,"admin","manager"))return Response.json({error:"Forbidden"},{status:403});let b=a.searchParams,c=[],f=b.get("from"),g=b.get("to"),h=b.get("status");f&&/^\d{4}-\d{2}-\d{2}$/.test(f)&&c.push({createdAt:{greater_than_equal:`${f}T00:00:00+06:00`}}),g&&/^\d{4}-\d{2}-\d{2}$/.test(g)&&c.push({createdAt:{less_than_equal:`${g}T23:59:59+06:00`}}),h&&c.push({status:{equals:h}});let i=(await a.payload.find({collection:"orders",where:c.length?{and:c}:void 0,sort:"-createdAt",limit:5e3,depth:0,pagination:!1,req:a,overrideAccess:!1})).docs.map(a=>[a.orderNumber,new Date(a.createdAt).toLocaleString("en-GB",{timeZone:"Asia/Dhaka"}),a.status,a.paymentStatus,a.paymentMethod,a.customerName,a.customerPhone,a.customerEmail??"",a.district??"",a.area??"",a.address,(a.items??[]).map(a=>`${a.sku??""} ${a.productNameEn||a.productName} (${a.variantLabel??""}) x${a.quantity}`).join("; "),(0,e.r$)(a.subtotal),(0,e.r$)(a.discount),(0,e.r$)(a.shippingFee),(0,e.r$)(a.total),a.couponCode??""]);return new Response((0,e.gD)(["Order number","Created (Dhaka)","Status","Payment status","Payment method","Customer","Phone","Email","District","Area","Address","Items","Subtotal (BDT)","Discount (BDT)","Delivery (BDT)","Total (BDT)","Coupon"],i),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":`attachment; filename="orders-${new Date().toISOString().slice(0,10)}.csv"`,"Cache-Control":"no-store"}})}}},53776:(a,b,c)=>{"use strict";c.d(b,{MobileMenu:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call MobileMenu() from the server but MobileMenu is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\layout\\MobileMenu.tsx","MobileMenu")},54027:(a,b,c)=>{"use strict";c.d(b,{Ce:()=>j,Up:()=>h,dn:()=>l,hD:()=>g,j5:()=>k,xX:()=>i});let d=[{code:"barishal",en:"Barishal",bn:"বরিশাল"},{code:"chattogram",en:"Chattogram",bn:"চট্টগ্রাম"},{code:"dhaka",en:"Dhaka",bn:"ঢাকা"},{code:"khulna",en:"Khulna",bn:"খুলনা"},{code:"mymensingh",en:"Mymensingh",bn:"ময়মনসিংহ"},{code:"rajshahi",en:"Rajshahi",bn:"রাজশাহী"},{code:"rangpur",en:"Rangpur",bn:"রংপুর"},{code:"sylhet",en:"Sylhet",bn:"সিলেট"}],e=(a,b,c,d)=>({code:b,division:a,en:c,bn:d}),f=[e("barishal","barguna","Barguna","বরগুনা"),e("barishal","barishal","Barishal","বরিশাল"),e("barishal","bhola","Bhola","ভোলা"),e("barishal","jhalokati","Jhalokati","ঝালকাঠি"),e("barishal","patuakhali","Patuakhali","পটুয়াখালী"),e("barishal","pirojpur","Pirojpur","পিরোজপুর"),e("chattogram","bandarban","Bandarban","বান্দরবান"),e("chattogram","brahmanbaria","Brahmanbaria","ব্রাহ্মণবাড়িয়া"),e("chattogram","chandpur","Chandpur","চাঁদপুর"),e("chattogram","chattogram","Chattogram","চট্টগ্রাম"),e("chattogram","cumilla","Cumilla","কুমিল্লা"),e("chattogram","coxsbazar","Cox's Bazar","কক্সবাজার"),e("chattogram","feni","Feni","ফেনী"),e("chattogram","khagrachhari","Khagrachhari","খাগড়াছড়ি"),e("chattogram","lakshmipur","Lakshmipur","লক্ষ্মীপুর"),e("chattogram","noakhali","Noakhali","নোয়াখালী"),e("chattogram","rangamati","Rangamati","রাঙ্গামাটি"),e("dhaka","dhaka","Dhaka","ঢাকা"),e("dhaka","faridpur","Faridpur","ফরিদপুর"),e("dhaka","gazipur","Gazipur","গাজীপুর"),e("dhaka","gopalganj","Gopalganj","গোপালগঞ্জ"),e("dhaka","kishoreganj","Kishoreganj","কিশোরগঞ্জ"),e("dhaka","madaripur","Madaripur","মাদারীপুর"),e("dhaka","manikganj","Manikganj","মানিকগঞ্জ"),e("dhaka","munshiganj","Munshiganj","মুন্সীগঞ্জ"),e("dhaka","narayanganj","Narayanganj","নারায়ণগঞ্জ"),e("dhaka","narsingdi","Narsingdi","নরসিংদী"),e("dhaka","rajbari","Rajbari","রাজবাড়ী"),e("dhaka","shariatpur","Shariatpur","শরীয়তপুর"),e("dhaka","tangail","Tangail","টাঙ্গাইল"),e("khulna","bagerhat","Bagerhat","বাগেরহাট"),e("khulna","chuadanga","Chuadanga","চুয়াডাঙ্গা"),e("khulna","jashore","Jashore","যশোর"),e("khulna","jhenaidah","Jhenaidah","ঝিনাইদহ"),e("khulna","khulna","Khulna","খুলনা"),e("khulna","kushtia","Kushtia","কুষ্টিয়া"),e("khulna","magura","Magura","মাগুরা"),e("khulna","meherpur","Meherpur","মেহেরপুর"),e("khulna","narail","Narail","নড়াইল"),e("khulna","satkhira","Satkhira","সাতক্ষীরা"),e("mymensingh","jamalpur","Jamalpur","জামালপুর"),e("mymensingh","mymensingh","Mymensingh","ময়মনসিংহ"),e("mymensingh","netrokona","Netrokona","নেত্রকোণা"),e("mymensingh","sherpur","Sherpur","শেরপুর"),e("rajshahi","bogura","Bogura","বগুড়া"),e("rajshahi","chapainawabganj","Chapai Nawabganj","চাঁপাইনবাবগঞ্জ"),e("rajshahi","joypurhat","Joypurhat","জয়পুরহাট"),e("rajshahi","naogaon","Naogaon","নওগাঁ"),e("rajshahi","natore","Natore","নাটোর"),e("rajshahi","pabna","Pabna","পাবনা"),e("rajshahi","rajshahi","Rajshahi","রাজশাহী"),e("rajshahi","sirajganj","Sirajganj","সিরাজগঞ্জ"),e("rangpur","dinajpur","Dinajpur","দিনাজপুর"),e("rangpur","gaibandha","Gaibandha","গাইবান্ধা"),e("rangpur","kurigram","Kurigram","কুড়িগ্রাম"),e("rangpur","lalmonirhat","Lalmonirhat","লালমনিরহাট"),e("rangpur","nilphamari","Nilphamari","নীলফামারী"),e("rangpur","panchagarh","Panchagarh","পঞ্চগড়"),e("rangpur","rangpur","Rangpur","রংপুর"),e("rangpur","thakurgaon","Thakurgaon","ঠাকুরগাঁও"),e("sylhet","habiganj","Habiganj","হবিগঞ্জ"),e("sylhet","moulvibazar","Moulvibazar","মৌলভীবাজার"),e("sylhet","sunamganj","Sunamganj","সুনামগঞ্জ"),e("sylhet","sylhet","Sylhet","সিলেট")],g=f.map(a=>a.code),h=d.map(a=>a.code);function i(a,b){return f.some(c=>c.code===a&&c.division===b)}function j(a,b){return f.find(b=>b.code===a)?.[b]??a}function k(a,b){return d.find(b=>b.code===a)?.[b]??a}let l=f.map(a=>({label:`${a.en} — ${a.bn}`,value:a.code}))},54176:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{m:()=>h});var e=c(43196),f=c(4765),g=a([e]);function h(){return(0,f.nm0)({config:e.A})}e=(g.then?(await g)():g)[0],d()}catch(a){d(a)}})},55276:(a,b,c)=>{"use strict";c.d(b,{z:()=>f});var d=c(95071),e=c(78853);let f={slug:"users",labels:{singular:"Staff user",plural:"Staff users"},admin:{useAsTitle:"email",defaultColumns:["email","name","roles","updatedAt"],group:"Settings"},auth:{tokenExpiration:28800,maxLoginAttempts:5,lockTime:9e5,useSessions:!0,cookies:{sameSite:"Lax",secure:"true"!==process.env.INSECURE_COOKIES}},access:{read:({req:a})=>!!(0,e.hf)(a.user,"admin")||!!a.user&&{id:{equals:a.user.id}},create:e.qc,delete:e.qc,update:({req:a})=>!!(0,e.hf)(a.user,"admin")||!!a.user&&{id:{equals:a.user.id}},admin:({req:a})=>(0,e.hf)(a.user,"admin","manager","editor")},hooks:{beforeOperation:[({operation:a,req:b,args:c})=>{if("create"!==a||b.user||b.context?.allowStaffBootstrap===!0||"true"===process.env.ALLOW_WEB_FIRST_USER)return c;throw new d.c(b.t)}]},fields:[{name:"name",type:"text"},{name:"roles",type:"select",hasMany:!0,required:!0,defaultValue:["editor"],saveToJWT:!0,options:[{label:"Admin — full access",value:"admin"},{label:"Manager — catalog, content, orders",value:"manager"},{label:"Editor — catalog and content",value:"editor"}],access:{create:e.g8,update:e.g8}}]}},57479:()=>{},58001:(a,b,c)=>{"use strict";c.d(b,{S:()=>g});var d=c(78853),e=c(3380),f=c(46747);let g={slug:"coupons",labels:{singular:"Coupon",plural:"Coupons"},admin:{group:"Sales",useAsTitle:"code",defaultColumns:["code","active","type","percent","amount","usedCount","usageLimit","endsAt"]},access:{read:d.k3,create:d.k3,update:d.k3,delete:d.k3},fields:[{name:"code",type:"text",required:!0,unique:!0,index:!0,hooks:{beforeValidate:[({value:a})=>"string"==typeof a?(0,f.Z)(a):a]},admin:{description:"Letters and numbers, e.g. MANGO10. Case-insensitive for customers."}},{name:"description",type:"text",admin:{description:"Internal note."}},{name:"active",type:"checkbox",defaultValue:!0},{name:"type",type:"select",required:!0,defaultValue:"percent",options:[{label:"Percentage off",value:"percent"},{label:"Fixed amount off",value:"fixed"}]},{name:"percent",type:"number",min:1,max:100,admin:{condition:(a,b)=>b?.type==="percent",description:"e.g. 10 for 10% off"},validate:(a,{siblingData:b})=>b?.type!=="percent"||null!=a&&!(a<=0)&&!(a>100)||"Enter a percentage between 1 and 100."},(0,e.$)({name:"amount",label:"Amount off (৳)",admin:{condition:(a,b)=>b?.type==="fixed"}}),(0,e.$)({name:"minSubtotal",label:"Minimum order subtotal (৳)"}),(0,e.$)({name:"maxDiscount",label:"Maximum discount (৳)",admin:{description:"Cap for percentage coupons (optional)."}}),{type:"row",fields:[{name:"startsAt",type:"date",admin:{width:"50%",date:{pickerAppearance:"dayAndTime"}}},{name:"endsAt",type:"date",admin:{width:"50%",date:{pickerAppearance:"dayAndTime"}}}]},{type:"row",fields:[{name:"usageLimit",type:"number",min:0,admin:{width:"50%",description:"Total uses allowed. Empty or 0 = unlimited."}},{name:"usedCount",type:"number",defaultValue:0,admin:{width:"50%",readOnly:!0}}]}]}},59615:(a,b,c)=>{"use strict";c.d(b,{cn:()=>g});var d=c(37355);c(24942);var e=c(61378),f=c(27557);async function g(a,b,c,g){var h,i;let j=e.o[c];if(!j?.isConfigured())return{ok:!1,reason:"gateway_not_configured"};if("paid"===b.paymentStatus||"cancelled"===b.status)return{ok:!1,reason:"order_not_payable"};let k=await a.count({collection:"payments",where:{order:{equals:b.id}},overrideAccess:!0});if(k.totalDocs>=8)return{ok:!1,reason:"too_many_attempts"};let l=(h=b.orderNumber,i=k.totalDocs+1,`${h.replace(/[^A-Z0-9]/gi,"")}P${i}`.slice(0,20)),m=await a.create({collection:"payments",overrideAccess:!0,data:{order:b.id,reference:l,provider:c,amount:b.total,currency:"BDT",status:"initiated"}});try{let e=await j.initiate({reference:l,orderNumber:b.orderNumber,amount:b.total,customer:{name:b.customerName,phone:b.customerPhone,email:b.customerEmail,address:b.address,district:b.district},productSummary:(b.items??[]).map(a=>`${a.productNameEn||a.productName} x${a.quantity}`).join(", "),callbackUrl:`${d._.NEXT_PUBLIC_SERVER_URL}/payments/${c}/callback`,ipnUrl:"sslcommerz"===c?`${d._.NEXT_PUBLIC_SERVER_URL}/payments/sslcommerz/ipn`:void 0,clientIp:g});return await a.update({collection:"payments",id:m.id,overrideAccess:!0,data:{gatewayPaymentId:e.gatewayPaymentId}}),"pending"!==b.paymentStatus&&await a.update({collection:"orders",id:b.id,overrideAccess:!0,data:{paymentStatus:"pending"}}),{ok:!0,redirectUrl:e.redirectUrl}}catch(d){let c=d instanceof f.F?d.message:"Gateway error";return a.logger.error({err:d,msg:`Payment initiation failed for ${b.orderNumber}`}),await a.update({collection:"payments",id:m.id,overrideAccess:!0,data:{status:"failed",failureReason:c}}),{ok:!1,reason:"gateway_error"}}}},60601:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{R7:()=>g,_Z:()=>j,hP:()=>i,tz:()=>h});var e=c(77761);async function f(a,b){let c=a.db;if(b?.transactionID){let a=await b.transactionID,d=c.sessions?.[String(a)];if(d?.db)return d.db}return c.drizzle}async function g(a,b,c){let d=await f(a,c);await d.execute((0,e.ll)`
    UPDATE products
       SET total_stock = COALESCE((SELECT SUM(GREATEST(stock, 0)) FROM products_variants WHERE _parent_id = ${Number(b)}), 0)
     WHERE id = ${Number(b)}
  `)}async function h(a,b,c){let d=await f(a,c),g=await d.execute((0,e.ll)`
    UPDATE products_variants
       SET stock = stock - ${b.quantity}
     WHERE id = ${b.variantId}
       AND _parent_id = ${Number(b.productId)}
       AND stock >= ${b.quantity}
    RETURNING stock
  `);return g.rows.length?Number(g.rows[0].stock):null}async function i(a,b,c){let d=await f(a,c),g=await d.execute((0,e.ll)`
    WITH prev AS (
      SELECT stock FROM products_variants
       WHERE id = ${b.variantId} AND _parent_id = ${Number(b.productId)}
       FOR UPDATE
    )
    UPDATE products_variants v
       SET stock = GREATEST(0, v.stock + ${b.delta})
      FROM prev
     WHERE v.id = ${b.variantId} AND v._parent_id = ${Number(b.productId)}
    RETURNING prev.stock AS before, v.stock AS after
  `);return g.rows.length?{before:Number(g.rows[0].before),after:Number(g.rows[0].after)}:null}async function j(a,b,c){let d=await f(a,c);return(await d.execute((0,e.ll)`
    UPDATE coupons
       SET used_count = COALESCE(used_count, 0) + 1
     WHERE id = ${Number(b)}
       AND (usage_limit IS NULL OR usage_limit = 0 OR COALESCE(used_count, 0) < usage_limit)
    RETURNING used_count
  `)).rows.length>0}d()}catch(a){d(a)}})},61378:(a,b,c)=>{"use strict";c.d(b,{o:()=>s,u:()=>t});var d=c(37355),e=c(27557);async function f(a,b={}){let c=new AbortController,d=setTimeout(()=>c.abort(),b.timeoutMs??2e4);try{let d,f=await fetch(a,{...b,signal:c.signal,cache:"no-store"}),g=await f.text();try{d=g?JSON.parse(g):{}}catch{throw new e.F(`Gateway returned non-JSON response (HTTP ${f.status})`)}if(!f.ok)throw new e.F(`Gateway HTTP ${f.status}`,d);return d}catch(a){if(a instanceof e.F)throw a;throw new e.F(a instanceof Error&&"AbortError"===a.name?"Gateway request timed out":"Gateway request failed")}finally{clearTimeout(d)}}function g(a){return`${Math.floor(a/100)}.${String(a%100).padStart(2,"0")}`}let h=()=>d._.BKASH_BASE_URL||(d._.PAYMENTS_SANDBOX?"https://tokenized.sandbox.bka.sh/v1.2.0-beta":"https://tokenized.pay.bka.sh/v1.2.0-beta"),i=null;async function j(){if(i&&i.expiresAt>Date.now()+6e4)return i.token;let a=await f(`${h()}/tokenized/checkout/token/grant`,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json",username:d._.BKASH_USERNAME,password:d._.BKASH_PASSWORD},body:JSON.stringify({app_key:d._.BKASH_APP_KEY,app_secret:d._.BKASH_APP_SECRET})});if(!a.id_token)throw new e.F(`bKash token grant failed: ${a.statusMessage??"unknown"}`);return i={token:a.id_token,expiresAt:Date.now()+(a.expires_in??3600)*1e3},a.id_token}async function k(a,b){let c=await j();return f(`${h()}${a}`,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json",Authorization:c,"X-APP-Key":d._.BKASH_APP_KEY},body:JSON.stringify(b),timeoutMs:3e4})}var l=c(55511),m=c.n(l);let n=()=>d._.NAGAD_BASE_URL||(d._.PAYMENTS_SANDBOX?"http://sandbox.mynagad.com:10080/remote-payment-gateway-1.0/api/dfs":"https://api.mynagad.com/api/dfs");function o(a,b){let c=a.replace(/\\n/g,"\n").trim();if(c.includes("BEGIN"))return c;let d=c.replace(/\s+/g,"").match(/.{1,64}/g)?.join("\n")??c;return`-----BEGIN ${b} KEY-----
${d}
-----END ${b} KEY-----`}let p=a=>m().publicEncrypt({key:o(d._.NAGAD_PG_PUBLIC_KEY,"PUBLIC"),padding:m().constants.RSA_PKCS1_PADDING},Buffer.from(JSON.stringify(a))).toString("base64"),q=a=>m().sign("sha256",Buffer.from(JSON.stringify(a)),o(d._.NAGAD_MERCHANT_PRIVATE_KEY,"PRIVATE")).toString("base64"),r=a=>({"Content-Type":"application/json","X-KM-Api-Version":"v-0.2.0","X-KM-IP-V4":a&&/^\d+\.\d+\.\d+\.\d+$/.test(a)?a:"127.0.0.1","X-KM-Client-Type":"PC_WEB"}),s={sslcommerz:{id:"sslcommerz",label:{bn:"কার্ড / মোবাইল ব্যাংকিং (SSLCommerz)",en:"Card / mobile banking (SSLCommerz)"},isConfigured:()=>!!(d._.SSLCOMMERZ_STORE_ID&&d._.SSLCOMMERZ_STORE_PASSWORD),async initiate(a){let b=b=>`${a.callbackUrl}?result=${b}&ref=${encodeURIComponent(a.reference)}`,c=new URLSearchParams({store_id:d._.SSLCOMMERZ_STORE_ID,store_passwd:d._.SSLCOMMERZ_STORE_PASSWORD,total_amount:g(a.amount),currency:"BDT",tran_id:a.reference,success_url:b("success"),fail_url:b("fail"),cancel_url:b("cancel"),ipn_url:a.ipnUrl??b("ipn"),shipping_method:"Courier",product_name:a.productSummary.slice(0,250),product_category:"Food",product_profile:"physical-goods",num_of_item:"1",cus_name:a.customer.name.slice(0,50),cus_email:a.customer.email||"noreply@example.com",cus_add1:a.customer.address.slice(0,50),cus_city:a.customer.district||"Dhaka",cus_country:"Bangladesh",cus_phone:a.customer.phone,ship_name:a.customer.name.slice(0,50),ship_add1:a.customer.address.slice(0,50),ship_city:a.customer.district||"Dhaka",ship_postcode:"1000",ship_country:"Bangladesh",value_a:a.orderNumber}),h=await f(`${d._.PAYMENTS_SANDBOX?"https://sandbox.sslcommerz.com":"https://securepay.sslcommerz.com"}/gwprocess/v4/api.php`,{method:"POST",body:c,headers:{"Content-Type":"application/x-www-form-urlencoded"}});if("SUCCESS"!==h.status||!h.GatewayPageURL)throw new e.F(`SSLCommerz session failed: ${h.failedreason??"unknown reason"}`);return{redirectUrl:h.GatewayPageURL,gatewayPaymentId:h.sessionkey}}},bkash:{id:"bkash",label:{bn:"বিকাশ",en:"bKash"},isConfigured:()=>!!(d._.BKASH_APP_KEY&&d._.BKASH_APP_SECRET&&d._.BKASH_USERNAME&&d._.BKASH_PASSWORD),async initiate(a){let b=await k("/tokenized/checkout/create",{mode:"0011",payerReference:a.customer.phone,callbackURL:a.callbackUrl,amount:g(a.amount),currency:"BDT",intent:"sale",merchantInvoiceNumber:a.reference});if("0000"!==b.statusCode||!b.bkashURL||!b.paymentID)throw new e.F(`bKash create failed: ${b.statusMessage??b.statusCode??"unknown"}`);return{redirectUrl:b.bkashURL,gatewayPaymentId:b.paymentID}}},nagad:{id:"nagad",label:{bn:"নগদ",en:"Nagad"},isConfigured:()=>!!(d._.NAGAD_MERCHANT_ID&&d._.NAGAD_MERCHANT_NUMBER&&d._.NAGAD_MERCHANT_PRIVATE_KEY&&d._.NAGAD_PG_PUBLIC_KEY),async initiate(a){let b,c=d._.NAGAD_MERCHANT_ID,h=a.reference,i=function(a=new Date){return new Date(a.getTime()+216e5).toISOString().replace(/[-:T]/g,"").slice(0,14)}(),j={merchantId:c,datetime:i,orderId:h,challenge:m().randomBytes(20).toString("hex")},k=await f(`${n()}/check-out/initialize/${c}/${h}`,{method:"POST",headers:r(a.clientIp),body:JSON.stringify({accountNumber:d._.NAGAD_MERCHANT_NUMBER,dateTime:i,sensitiveData:p(j),signature:q(j)})});if(!k.sensitiveData)throw new e.F(`Nagad initialize failed: ${k.message??k.reason??"unknown"}`);let l=(b=k.sensitiveData,JSON.parse(m().privateDecrypt({key:o(d._.NAGAD_MERCHANT_PRIVATE_KEY,"PRIVATE"),padding:m().constants.RSA_PKCS1_PADDING},Buffer.from(b,"base64")).toString("utf8")));if(!l.paymentReferenceId||!l.challenge)throw new e.F("Nagad initialize returned no payment reference");let s={merchantId:c,orderId:h,currencyCode:"050",amount:g(a.amount),challenge:l.challenge},t=await f(`${n()}/check-out/complete/${l.paymentReferenceId}`,{method:"POST",headers:r(a.clientIp),body:JSON.stringify({sensitiveData:p(s),signature:q(s),merchantCallbackURL:a.callbackUrl,additionalMerchantInfo:{orderNumber:a.orderNumber}})});if("Success"!==t.status||!t.callBackUrl)throw new e.F(`Nagad complete failed: ${t.message??t.status??"unknown"}`);return{redirectUrl:t.callBackUrl,gatewayPaymentId:l.paymentReferenceId}}}};async function t(a){let b=await a.findGlobal({slug:"payment-settings",depth:0,overrideAccess:!0}),c=[];!1!==b.codEnabled&&c.push({id:"cod",label:{bn:"ক্যাশ অন ডেলিভারি",en:"Cash on delivery"},maxTotal:b.codMaxTotal||null});let d={sslcommerz:!!b.sslcommerzEnabled,bkash:!!b.bkashEnabled,nagad:!!b.nagadEnabled};for(let a of Object.values(s))d[a.id]&&a.isConfigured()&&c.push({id:a.id,label:a.label,maxTotal:null});return c}},63678:(a,b,c)=>{"use strict";function d(a,b){let c=a.filter(a=>!1!==a.enabled);if(b){let a=c.find(a=>a.districts?.includes(b));if(a)return a}return c.find(a=>a.isDefault)??null}function e(a,b,c){return a?(null!=a.freeOver&&a.freeOver>0&&c>=a.freeOver?0:a.fee)+(b?.surcharge??0):0}c.d(b,{R:()=>e,V:()=>d})},64442:(a,b,c)=>{"use strict";function d(a){if(null==a)return"";let b=String(a);return/^[=+\-@\t\r]/.test(b)&&(b=`'${b}`),/[",\n\r]/.test(b)?`"${b.replace(/"/g,'""')}"`:b}function e(a,b){return"\uFEFF"+[a,...b].map(a=>a.map(d).join(",")).join("\r\n")+"\r\n"}function f(a){let b=[],c=[],d="",e=!1,f=a.replace(/^﻿/,"");for(let a=0;a<f.length;a++){let g=f[a];e?'"'===g&&'"'===f[a+1]?(d+='"',a++):'"'===g?e=!1:d+=g:'"'===g?e=!0:","===g?(c.push(d),d=""):"\n"===g||"\r"===g?("\r"===g&&"\n"===f[a+1]&&a++,c.push(d),c.some(a=>""!==a)&&b.push(c),c=[],d=""):d+=g}return c.push(d),c.some(a=>""!==a)&&b.push(c),b}c.d(b,{Wk:()=>f,gD:()=>e,r$:()=>g});let g=a=>null==a?"":(a/100).toFixed(2)},67569:(a,b,c)=>{Promise.resolve().then(c.bind(c,95710))},68282:(a,b,c)=>{"use strict";c.d(b,{CartDrawer:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call CartDrawer() from the server but CartDrawer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\cart\\CartDrawer.tsx","CartDrawer")},69752:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{w:()=>h});var e=c(92393),f=c(98112),g=a([e,f]);[e,f]=g.then?(await g)():g;let h=[{up:e.up,down:e.T,name:"20261026_084826_initial"},{up:f.up,down:f.T,name:"20261026_090000_integrity_constraints"}];d()}catch(a){d(a)}})},70762:(a,b,c)=>{"use strict";c.d(b,{g:()=>g});var d=c(5735),e=c(29978);function f({className:a="h-9 w-9",tone:b="color"}){return(0,d.jsxs)("svg",{viewBox:"0 0 48 48",className:a,"aria-hidden":!0,focusable:"false",children:[(0,d.jsx)("path",{d:"M25.5 9.5c-1.6-4.6 1.4-7.6 6.4-8.3-.5 4.6-2.4 7-6.4 8.3z",fill:"light"===b?"#CFE3B8":"var(--color-secondary)"}),(0,d.jsx)("path",{d:"M24.4 10.2C34.6 10 41.8 17.6 41.4 28.3 41 38.4 33 45 23.7 44.4 13.9 43.8 7.3 36.7 8.6 27.4 9.9 17.8 15.9 10.4 24.4 10.2z",fill:"var(--color-accent-warm)"}),(0,d.jsx)("path",{d:"M24.4 10.2c7.8-.2 13.8 4.3 16 11.2-5.6-4.6-13.7-5.3-20.6-1.5-3.6 2-6.4 5-8.4 8.6 1.2-9.8 6.4-18.1 13-18.3z",fill:"var(--color-accent)",opacity:".9"}),(0,d.jsx)("path",{d:"M17.5 20.5c-3.3 2.3-5 5.7-5.2 9.6",stroke:"#FFF4C7",strokeWidth:"2.4",strokeLinecap:"round",fill:"none",opacity:".85"})]})}function g({brandName:a,logo:b,mobileLogo:c,variant:h="header"}){return b?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.A,{src:(c??b).url,alt:a,width:(c??b).width,height:(c??b).height,className:`h-10 w-auto ${c?"md:hidden":""}`,priority:"header"===h}),c&&(0,d.jsx)(e.A,{src:b.url,alt:a,width:b.width,height:b.height,className:"hidden h-11 w-auto md:block",priority:"header"===h})]}):(0,d.jsxs)("span",{className:"flex items-center gap-2.5",children:[(0,d.jsx)(f,{className:"footer"===h?"h-10 w-10":"h-9 w-9",tone:"footer"===h?"light":"color"}),(0,d.jsx)("span",{className:`font-display text-[1.45rem] leading-none ${"footer"===h?"text-cream":"text-primary"}`,children:a})]})}},71189:(a,b,c)=>{"use strict";async function d(a,b){if(!a)return b();let c={locale:a.locale,fallbackLocale:a.fallbackLocale};try{return await b()}finally{a.locale=c.locale,a.fallbackLocale=c.fallbackLocale}}c.d(b,{N:()=>d})},71718:(a,b,c)=>{"use strict";function d(a){let b=a.replace(/[০-৯]/g,a=>String("০১২৩৪৫৬৭৮৯".indexOf(a))).replace(/[\s\-().]/g,"");return(b.startsWith("+")&&(b=b.slice(1)),b.startsWith("880")&&(b=b.slice(2)),/^01[3-9]\d{8}$/.test(b))?b:null}c.d(b,{o:()=>d})},71788:(a,b,c)=>{"use strict";c.d(b,{I18nProvider:()=>h,s:()=>i});var d=c(48249),e=c(67484),f=c(35209);let g=(0,e.createContext)(null);function h({locale:a,dict:b,children:c}){return(0,d.jsx)(g.Provider,{value:{locale:a,dict:b,price:b=>(0,f.$g)(b,a),t:(b,c)=>c?(0,f.GW)(b,function(a,b){if("bn"!==b)return a;let c={};for(let[b,d]of Object.entries(a))c[b]="number"==typeof d?d.toLocaleString("bn-BD"):d;return c}(c,a)):b},children:c})}function i(){let a=(0,e.useContext)(g);if(!a)throw Error("useI18n must be used inside I18nProvider");return a}},71985:(a,b,c)=>{"use strict";c.d(b,{Analytics:()=>n});var d=c(48249),e=c(54718),f=c(67484),g=c(71788);let h="analytics_consent_v1",i=new Set,j=null;function k(){try{let a=localStorage.getItem(h);return"granted"===a||"denied"===a?a:j}catch{return j}}function l(a){j=a;try{localStorage.setItem(h,a)}catch{}i.forEach(a=>a())}function m(a){return i.add(a),()=>i.delete(a)}function n({ga4Id:a,gtmId:b,requireConsent:c}){let{dict:h}=(0,g.s)(),i=(0,f.useSyncExternalStore)(m,k,()=>"ssr");if(!(a||b)||"ssr"===i)return null;let j=i??(c?"unknown":"granted");return(0,d.jsxs)(d.Fragment,{children:["granted"===j&&a&&(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.default,{src:`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(a)}`,strategy:"afterInteractive"}),(0,d.jsx)(e.default,{id:"ga4-init",strategy:"afterInteractive",children:`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config',${JSON.stringify(a)},{anonymize_ip:true});`})]}),"granted"===j&&b&&!a&&(0,d.jsx)(e.default,{id:"gtm-init",strategy:"afterInteractive",children:`(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer',${JSON.stringify(b)});`}),"unknown"===j&&(0,d.jsxs)("div",{role:"region","aria-label":h.consent.message,className:"fixed inset-x-3 bottom-3 z-50 mx-auto max-w-xl rounded-[var(--radius-card)] border border-line bg-paper p-4 shadow-lg md:bottom-6",children:[(0,d.jsx)("p",{className:"text-sm",children:h.consent.message}),(0,d.jsxs)("div",{className:"mt-3 flex gap-2",children:[(0,d.jsx)("button",{type:"button",onClick:()=>l("granted"),className:"h-10 rounded-[var(--radius-control)] bg-primary px-4 text-sm font-medium text-white hover:bg-primary-deep",children:h.consent.accept}),(0,d.jsx)("button",{type:"button",onClick:()=>l("denied"),className:"h-10 rounded-[var(--radius-control)] border border-line px-4 text-sm hover:bg-leaf-tint",children:h.consent.decline})]})]})]})}},72646:(a,b,c)=>{Promise.resolve().then(c.bind(c,45417))},75300:(a,b,c)=>{"use strict";c.d(b,{CartProvider:()=>e});var d=c(77943);let e=(0,d.registerClientReference)(function(){throw Error("Attempted to call CartProvider() from the server but CartProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\providers\\CartProvider.tsx","CartProvider");(0,d.registerClientReference)(function(){throw Error("Attempted to call useCart() from the server but useCart is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\components\\providers\\CartProvider.tsx","useCart")},78335:()=>{},78853:(a,b,c)=>{"use strict";function d(a,...b){return!!a&&"users"===a.collection&&(a.roles??[]).some(a=>b.includes(a))}c.d(b,{Xl:()=>f,ZZ:()=>h,eP:()=>i,g8:()=>k,hf:()=>d,k3:()=>g,qc:()=>e,qp:()=>j});let e=({req:a})=>d(a.user,"admin"),f=({req:a})=>d(a.user,"admin","manager","editor"),g=({req:a})=>d(a.user,"admin","manager"),h=()=>!0,i=()=>!1,j=({req:a})=>!!d(a.user,"admin","manager","editor")||{status:{equals:"published"}},k=({req:a})=>d(a.user,"admin")},79252:(a,b,c)=>{"use strict";function d(a){return async({doc:b,previousDoc:c,operation:d,req:e})=>{if("update"!==d)return b;let f=c?.slug,g=b?.slug;if(!f||!g||f===g)return b;try{for(let b of(await e.payload.find({collection:"redirects",where:{and:[{type:{equals:a}},{toSlug:{equals:f}}]},limit:100,depth:0,req:e,overrideAccess:!0})).docs)await e.payload.update({collection:"redirects",id:b.id,data:{toSlug:g},req:e,overrideAccess:!0});await e.payload.delete({collection:"redirects",where:{and:[{type:{equals:a}},{fromSlug:{equals:g}}]},req:e,overrideAccess:!0}),await e.payload.create({collection:"redirects",data:{type:a,fromSlug:f,toSlug:g,automatic:!0},req:e,overrideAccess:!0})}catch(a){e.payload.logger.error({err:a,msg:"Failed to create slug redirect"})}return b}}c.d(b,{L:()=>d})},80814:(a,b,c)=>{"use strict";c.d(b,{w:()=>k});var d=c(5735),e=c(63059),f=c.n(e),g=c(37507),h=c(89592),i=c(70762);let j={facebook:"Facebook",instagram:"Instagram",youtube:"YouTube",tiktok:"TikTok",linkedin:"LinkedIn",x:"X"};function k({locale:a,dict:b,brandName:c,logo:e,description:l,columns:m,phone:n,email:o,address:p,socials:q,paymentNote:r,copyright:s}){let t=(0,g.ZV)(new Date().getFullYear(),a).replace(/,/g,"");return(0,d.jsxs)("footer",{className:"mt-24 bg-primary-deep text-cream",children:[(0,d.jsxs)("div",{className:"container-page grid gap-12 py-14 md:grid-cols-12",children:[(0,d.jsxs)("div",{className:"md:col-span-4",children:[(0,d.jsx)(f(),{href:`/${a}`,"aria-label":c,className:"inline-block",children:(0,d.jsx)(i.g,{brandName:c,logo:e,variant:"footer"})}),l&&(0,d.jsx)("p",{className:"mt-4 max-w-sm text-[0.95rem] text-cream/80",children:l}),q.length>0&&(0,d.jsxs)("div",{className:"mt-6",children:[(0,d.jsx)("h2",{className:"sr-only",children:b.footer.follow}),(0,d.jsx)("ul",{className:"flex flex-wrap gap-x-5 gap-y-2 text-sm",children:q.map(a=>(0,d.jsx)("li",{children:(0,d.jsx)("a",{href:a.url,target:"_blank",rel:"noopener noreferrer",className:"text-cream/90 underline-offset-4 hover:text-accent hover:underline",children:j[a.platform]??a.platform})},a.url))})]})]}),m.map(b=>(0,d.jsxs)("nav",{"aria-label":b.title,className:"md:col-span-2",children:[(0,d.jsx)("h2",{className:"font-sans text-sm font-semibold text-accent",children:b.title}),(0,d.jsx)("ul",{className:"mt-4 space-y-2.5 text-[0.95rem]",children:b.links.map(b=>(0,d.jsx)("li",{children:(0,h.g)(b.href)?(0,d.jsx)("a",{href:b.href,target:"_blank",rel:"noopener noreferrer",className:"text-cream/85 hover:text-cream hover:underline",children:b.label}):(0,d.jsx)(f(),{href:(0,h.l)(b.href,a),className:"text-cream/85 hover:text-cream hover:underline",children:b.label})},b.href+b.label))})]},b.title)),(0,d.jsxs)("div",{className:"md:col-span-2",children:[(0,d.jsx)("h2",{className:"font-sans text-sm font-semibold text-accent",children:b.footer.contact}),(0,d.jsxs)("address",{className:"mt-4 space-y-2.5 text-[0.95rem] not-italic text-cream/85",children:[n&&(0,d.jsx)("p",{children:(0,d.jsx)("a",{href:`tel:${n.replace(/[^\d+]/g,"")}`,className:"hover:text-cream hover:underline",children:n})}),o&&(0,d.jsx)("p",{children:(0,d.jsx)("a",{href:`mailto:${o}`,className:"break-all hover:text-cream hover:underline",children:o})}),p&&(0,d.jsx)("p",{className:"whitespace-pre-line",children:p})]})]})]}),(0,d.jsx)("div",{className:"border-t border-cream/15",children:(0,d.jsxs)("div",{className:"container-page flex flex-col gap-2 py-5 text-sm text-cream/70 md:flex-row md:items-center md:justify-between",children:[(0,d.jsx)("p",{children:s||`\xa9 ${t} ${c}. ${b.footer.rights}`}),r&&(0,d.jsxs)("p",{children:[(0,d.jsxs)("span",{className:"text-cream/90",children:[b.footer.payments,":"]})," ",r]})]})})]})}},84034:(a,b,c)=>{Promise.resolve().then(c.bind(c,47613)),Promise.resolve().then(c.t.bind(c,23318,23)),Promise.resolve().then(c.t.bind(c,58637,23)),Promise.resolve().then(c.bind(c,15759)),Promise.resolve().then(c.bind(c,68282)),Promise.resolve().then(c.bind(c,37025)),Promise.resolve().then(c.bind(c,21184)),Promise.resolve().then(c.bind(c,53776)),Promise.resolve().then(c.bind(c,75300)),Promise.resolve().then(c.bind(c,28878)),Promise.resolve().then(c.bind(c,3449))},86239:(a,b,c)=>{"use strict";c.d(b,{C:()=>g});var d=c(78853),e=c(3380),f=c(54027);let g={slug:"customers",labels:{singular:"Customer",plural:"Customers"},admin:{group:"Sales",useAsTitle:"name",defaultColumns:["name","phone","email","orderCount","totalSpent","lastOrderAt"],listSearchableFields:["name","phone","email"]},defaultSort:"-lastOrderAt",access:{read:d.k3,create:d.k3,update:d.k3,delete:d.qc},fields:[{name:"name",type:"text",required:!0},{name:"phone",type:"text",required:!0,unique:!0,index:!0},{name:"email",type:"email"},{name:"lastAddress",type:"group",fields:[{name:"division",type:"text"},{name:"district",type:"select",options:f.dn},{name:"area",type:"text"},{name:"address",type:"textarea"}]},{name:"orderCount",type:"number",defaultValue:0,admin:{readOnly:!0}},(0,e.$)({name:"totalSpent",defaultValue:0,admin:{readOnly:!0,description:"Sum of order totals (excluding cancelled orders at the time of ordering)."}}),{name:"lastOrderAt",type:"date",admin:{readOnly:!0}},{name:"notes",type:"textarea",admin:{description:"Internal notes."}},{name:"orders",type:"join",collection:"orders",on:"customer"}]}},87224:(a,b,c)=>{"use strict";let d;c.d(b,{CartProvider:()=>r,_:()=>s});var e=c(48249),f=c(67484);let g="cart_v1",h=Object.freeze({lines:[],couponCode:""}),i=h,j=null,k=new Set;function l(){let a;if(j)return j;try{a=window.localStorage.getItem(g)}catch{return h}return a!==d&&(d=a,i=function(a){if(!a)return h;try{let b=JSON.parse(a);return{lines:(Array.isArray(b.lines)?b.lines.filter(a=>a&&Number.isInteger(a.productId)&&"string"==typeof a.variantId&&Number.isInteger(a.quantity)&&a.quantity>0&&"object"==typeof a.snapshot&&null!==a.snapshot):[]).slice(0,40).map(a=>({...a,quantity:Math.min(50,a.quantity)})),couponCode:"string"==typeof b.couponCode?b.couponCode.slice(0,40):""}}catch{return h}}(a)),i}function m(){return h}function n(a){k.add(a);let b=b=>{(b.key===g||null===b.key)&&a()};return window.addEventListener("storage",b),()=>{k.delete(a),window.removeEventListener("storage",b)}}function o(a){let b=a(l());try{let a=JSON.stringify(b);window.localStorage.setItem(g,a),d=a,i=b,j=null}catch{j=b}k.forEach(a=>a())}let p=(0,f.createContext)(null),q=()=>()=>{};function r({children:a}){let b=(0,f.useSyncExternalStore)(n,l,m),c=(0,f.useSyncExternalStore)(q,()=>!0,()=>!1),[d,g]=(0,f.useState)(null),[h,i]=(0,f.useState)(!1),j=(0,f.useCallback)(a=>{o(b=>{let c=b.lines.findIndex(b=>b.productId===a.productId&&b.variantId===a.variantId),d=[...b.lines];return -1===c?d.push({...a,quantity:Math.min(50,a.quantity)}):d[c]={...a,quantity:Math.min(50,b.lines[c].quantity+a.quantity)},{...b,lines:d}}),g({line:a,addedQuantity:a.quantity,at:Date.now()})},[]),k=(0,f.useCallback)((a,b,c)=>{o(d=>({...d,lines:c<=0?d.lines.filter(c=>c.productId!==a||c.variantId!==b):d.lines.map(d=>d.productId===a&&d.variantId===b?{...d,quantity:Math.min(50,c)}:d)}))},[]),s=(0,f.useCallback)((a,b)=>{o(c=>({...c,lines:c.lines.filter(c=>c.productId!==a||c.variantId!==b)}))},[]),t=(0,f.useCallback)(()=>o(()=>({lines:[],couponCode:""})),[]),u=(0,f.useCallback)(a=>o(b=>({...b,couponCode:a})),[]),v=(0,f.useCallback)(()=>g(null),[]),w=(0,f.useMemo)(()=>({lines:b.lines,count:b.lines.reduce((a,b)=>a+b.quantity,0),ready:c,couponCode:b.couponCode,setCouponCode:u,add:j,setQuantity:k,remove:s,clear:t,lastAdded:d,dismissLastAdded:v,drawerOpen:h,setDrawerOpen:i}),[b,c,u,j,k,s,t,d,v,h]);return(0,e.jsx)(p.Provider,{value:w,children:a})}function s(){let a=(0,f.useContext)(p);if(!a)throw Error("useCart must be used inside CartProvider");return a}},89190:(a,b,c)=>{"use strict";c.d(b,{Nv:()=>f});var d=c(71718);async function e(a,b){return(await a.find({collection:"orders",where:{orderNumber:{equals:b.trim().toUpperCase()}},limit:1,depth:0,overrideAccess:!0})).docs[0]??null}async function f(a,b,c){var f;let g=(0,d.o)(c);if(!g||!/^[A-Z0-9-]{6,30}$/i.test(b.trim()))return null;let h=await e(a,b);return h&&h.customerPhone===g?{id:h.id,orderNumber:h.orderNumber,createdAt:h.createdAt,status:h.status,paymentStatus:h.paymentStatus,paymentMethod:h.paymentMethod,customerName:h.customerName,customerPhoneMasked:(f=h.customerPhone).length>=11?`${f.slice(0,3)}••••${f.slice(-4)}`:"••••",district:h.district,area:h.area,address:h.address,items:(h.items??[]).map(a=>({productName:a.productName,variantLabel:a.variantLabel,quantity:a.quantity,unitPrice:a.unitPrice,lineTotal:a.lineTotal})),subtotal:h.subtotal,discount:h.discount??0,shippingFee:h.shippingFee??0,total:h.total,history:(h.statusHistory??[]).map(a=>({status:a.status??"",at:a.at??h.createdAt})),locale:h.locale??"bn"}:null}c(24942)},89556:(a,b,c)=>{"use strict";c.d(b,{I:()=>e,n:()=>g});var d=c(71189);function e(){return{name:"translationStatus",type:"select",defaultValue:"missing_en",options:[{label:"Complete (বাংলা + English)",value:"complete"},{label:"Missing English",value:"missing_en"},{label:"Missing বাংলা",value:"missing_bn"},{label:"Missing both",value:"missing_both"}],admin:{position:"sidebar",readOnly:!0,description:"Updated automatically on save. Switch the language at the top of the form to edit each translation."}}}function f(a){return null!=a&&("string"==typeof a?a.trim().length>0:"object"!=typeof a||JSON.stringify(a).replace(/[{}[\]",:\s]|"text"|"root"/g,"").length>20)}function g(a){return async({data:b,req:c,originalDoc:e,collection:g,operation:h})=>{let i=c.locale||"bn",j={};"update"===h&&e?.id&&(j=await (0,d.N)(c,()=>c.payload.findByID({collection:g.slug,id:e.id,locale:"all",depth:0,req:c,overrideAccess:!0})));let k=c=>a.every(a=>{if(c===i&&a in b)return f(b[a]);let d=j[a];return f(d?.[c])}),l=k("bn"),m=k("en");return b.translationStatus=l&&m?"complete":l?"missing_en":m?"missing_bn":"missing_both",b}}},89592:(a,b,c)=>{"use strict";function d(a,b){return a?/^https?:\/\//.test(a)||a.startsWith("mailto:")||a.startsWith("tel:")?a:"/"===a?`/${b}`:/^\/(bn|en)(\/|$)/.test(a)?a:`/${b}${a.startsWith("/")?a:`/${a}`}`:`/${b}`}c.d(b,{g:()=>e,l:()=>d});let e=a=>/^https?:\/\//.test(a)},90217:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,95547,23)),Promise.resolve().then(c.t.bind(c,15098,23)),Promise.resolve().then(c.t.bind(c,47644,23)),Promise.resolve().then(c.t.bind(c,33859,23)),Promise.resolve().then(c.t.bind(c,98099,23)),Promise.resolve().then(c.t.bind(c,16237,23)),Promise.resolve().then(c.t.bind(c,98562,23)),Promise.resolve().then(c.t.bind(c,36675,23))},92340:(a,b,c)=>{"use strict";c.d(b,{Ef:()=>f,IB:()=>d,ib:()=>e});let d=["bn","en"],e={bn:{label:"বাংলা",htmlLang:"bn",intl:"bn-BD",ogLocale:"bn_BD"},en:{label:"English",htmlLang:"en",intl:"en-BD",ogLocale:"en_US"}};function f(a,b){var c;let e=a.split("/");"string"==typeof(c=e[1])&&d.includes(c)?e[1]=b:e.splice(1,0,b);let f=e.join("/");return f.endsWith("/")&&f.length>1?f.slice(0,-1):f}},92393:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{T:()=>g,up:()=>f});var e=c(77761);async function f({db:a,payload:b,req:c}){await a.execute((0,e.ll)`
   CREATE TYPE "public"."_locales" AS ENUM('bn', 'en');
  CREATE TYPE "public"."enum_products_variants_unit" AS ENUM('g', 'kg', 'ml', 'l', 'pcs', 'jar', 'box', 'pack');
  CREATE TYPE "public"."enum_products_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_products_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_categories_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_categories_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_stock_adjustments_reason" AS ENUM('restock', 'correction', 'damage', 'return', 'order', 'order_cancel');
  CREATE TYPE "public"."enum_orders_district" AS ENUM('barguna', 'barishal', 'bhola', 'jhalokati', 'patuakhali', 'pirojpur', 'bandarban', 'brahmanbaria', 'chandpur', 'chattogram', 'cumilla', 'coxsbazar', 'feni', 'khagrachhari', 'lakshmipur', 'noakhali', 'rangamati', 'dhaka', 'faridpur', 'gazipur', 'gopalganj', 'kishoreganj', 'madaripur', 'manikganj', 'munshiganj', 'narayanganj', 'narsingdi', 'rajbari', 'shariatpur', 'tangail', 'bagerhat', 'chuadanga', 'jashore', 'jhenaidah', 'khulna', 'kushtia', 'magura', 'meherpur', 'narail', 'satkhira', 'jamalpur', 'mymensingh', 'netrokona', 'sherpur', 'bogura', 'chapainawabganj', 'joypurhat', 'naogaon', 'natore', 'pabna', 'rajshahi', 'sirajganj', 'dinajpur', 'gaibandha', 'kurigram', 'lalmonirhat', 'nilphamari', 'panchagarh', 'rangpur', 'thakurgaon', 'habiganj', 'moulvibazar', 'sunamganj', 'sylhet');
  CREATE TYPE "public"."enum_orders_status" AS ENUM('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled');
  CREATE TYPE "public"."enum_orders_payment_status" AS ENUM('unpaid', 'pending', 'paid', 'failed', 'refunded', 'cancelled');
  CREATE TYPE "public"."enum_orders_payment_method" AS ENUM('cod', 'sslcommerz', 'bkash', 'nagad');
  CREATE TYPE "public"."enum_orders_locale" AS ENUM('bn', 'en');
  CREATE TYPE "public"."enum_payments_provider" AS ENUM('cod', 'sslcommerz', 'bkash', 'nagad');
  CREATE TYPE "public"."enum_payments_status" AS ENUM('initiated', 'succeeded', 'failed', 'cancelled');
  CREATE TYPE "public"."enum_customers_last_address_district" AS ENUM('barguna', 'barishal', 'bhola', 'jhalokati', 'patuakhali', 'pirojpur', 'bandarban', 'brahmanbaria', 'chandpur', 'chattogram', 'cumilla', 'coxsbazar', 'feni', 'khagrachhari', 'lakshmipur', 'noakhali', 'rangamati', 'dhaka', 'faridpur', 'gazipur', 'gopalganj', 'kishoreganj', 'madaripur', 'manikganj', 'munshiganj', 'narayanganj', 'narsingdi', 'rajbari', 'shariatpur', 'tangail', 'bagerhat', 'chuadanga', 'jashore', 'jhenaidah', 'khulna', 'kushtia', 'magura', 'meherpur', 'narail', 'satkhira', 'jamalpur', 'mymensingh', 'netrokona', 'sherpur', 'bogura', 'chapainawabganj', 'joypurhat', 'naogaon', 'natore', 'pabna', 'rajshahi', 'sirajganj', 'dinajpur', 'gaibandha', 'kurigram', 'lalmonirhat', 'nilphamari', 'panchagarh', 'rangpur', 'thakurgaon', 'habiganj', 'moulvibazar', 'sunamganj', 'sylhet');
  CREATE TYPE "public"."enum_coupons_type" AS ENUM('percent', 'fixed');
  CREATE TYPE "public"."enum_faqs_topic" AS ENUM('orders', 'delivery', 'packaging', 'payment', 'availability', 'returns');
  CREATE TYPE "public"."enum_faqs_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_faqs_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_testimonials_moderation" AS ENUM('pending', 'approved', 'rejected');
  CREATE TYPE "public"."enum_posts_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_posts_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_pages_kind" AS ENUM('info', 'policy');
  CREATE TYPE "public"."enum_pages_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_pages_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_redirects_type" AS ENUM('product', 'category', 'post', 'page');
  CREATE TYPE "public"."enum_users_roles" AS ENUM('admin', 'manager', 'editor');
  CREATE TYPE "public"."enum_homepage_benefits_icon" AS ENUM('leaf', 'package', 'truck', 'wallet', 'shield', 'phone', 'clock', 'heart');
  CREATE TYPE "public"."enum_homepage_announcement_tone" AS ENUM('green', 'mango', 'cream');
  CREATE TYPE "public"."enum_branding_socials_platform" AS ENUM('facebook', 'instagram', 'youtube', 'tiktok', 'linkedin', 'x');
  CREATE TYPE "public"."enum_contact_settings_show_on" AS ENUM('home', 'shop', 'category', 'product', 'cart', 'checkout', 'blog', 'pages', 'order');
  CREATE TYPE "public"."enum_contact_settings_position" AS ENUM('right', 'left');
  CREATE TYPE "public"."enum_delivery_settings_zones_districts" AS ENUM('barguna', 'barishal', 'bhola', 'jhalokati', 'patuakhali', 'pirojpur', 'bandarban', 'brahmanbaria', 'chandpur', 'chattogram', 'cumilla', 'coxsbazar', 'feni', 'khagrachhari', 'lakshmipur', 'noakhali', 'rangamati', 'dhaka', 'faridpur', 'gazipur', 'gopalganj', 'kishoreganj', 'madaripur', 'manikganj', 'munshiganj', 'narayanganj', 'narsingdi', 'rajbari', 'shariatpur', 'tangail', 'bagerhat', 'chuadanga', 'jashore', 'jhenaidah', 'khulna', 'kushtia', 'magura', 'meherpur', 'narail', 'satkhira', 'jamalpur', 'mymensingh', 'netrokona', 'sherpur', 'bogura', 'chapainawabganj', 'joypurhat', 'naogaon', 'natore', 'pabna', 'rajshahi', 'sirajganj', 'dinajpur', 'gaibandha', 'kurigram', 'lalmonirhat', 'nilphamari', 'panchagarh', 'rangpur', 'thakurgaon', 'habiganj', 'moulvibazar', 'sunamganj', 'sylhet');
  CREATE TABLE "products_attributes" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "products_attributes_locales" (
  	"label" varchar NOT NULL,
  	"value" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "products_variants" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"sku" varchar NOT NULL,
  	"pack_size" numeric,
  	"unit" "enum_products_variants_unit" DEFAULT 'kg',
  	"price" numeric NOT NULL,
  	"sale_price" numeric,
  	"sale_starts_at" timestamp(3) with time zone,
  	"sale_ends_at" timestamp(3) with time zone,
  	"stock" numeric DEFAULT 0,
  	"low_stock_threshold" numeric DEFAULT 5,
  	"weight_grams" numeric
  );
  
  CREATE TABLE "products_variants_locales" (
  	"label" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "products" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"status" "enum_products_status" DEFAULT 'draft' NOT NULL,
  	"featured" boolean DEFAULT false,
  	"best_seller" boolean DEFAULT false,
  	"is_bundle" boolean DEFAULT false,
  	"sort_order" numeric DEFAULT 0,
  	"translation_status" "enum_products_translation_status" DEFAULT 'missing_en',
  	"min_price" numeric,
  	"total_stock" numeric DEFAULT 0,
  	"search_text" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "products_locales" (
  	"name" varchar NOT NULL,
  	"short_description" varchar,
  	"description" jsonb,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "products_texts" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer NOT NULL,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"text" varchar
  );
  
  CREATE TABLE "products_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"media_id" integer,
  	"categories_id" integer,
  	"products_id" integer
  );
  
  CREATE TABLE "categories" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"image_id" integer,
  	"banner_id" integer,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"status" "enum_categories_status" DEFAULT 'published' NOT NULL,
  	"parent_id" integer,
  	"featured" boolean DEFAULT false,
  	"sort_order" numeric DEFAULT 0,
  	"translation_status" "enum_categories_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "categories_locales" (
  	"name" varchar NOT NULL,
  	"description" varchar,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "stock_adjustments" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"sku" varchar NOT NULL,
  	"delta" numeric NOT NULL,
  	"reason" "enum_stock_adjustments_reason" DEFAULT 'restock' NOT NULL,
  	"note" varchar,
  	"product_id" integer,
  	"variant_id" varchar,
  	"order_id" integer,
  	"stock_before" numeric,
  	"stock_after" numeric,
  	"created_by" varchar,
  	"system_generated" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "orders_items" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"product_id" integer,
  	"product_name" varchar NOT NULL,
  	"product_name_en" varchar,
  	"variant_id" varchar,
  	"variant_label" varchar,
  	"sku" varchar,
  	"unit_price" numeric NOT NULL,
  	"regular_price" numeric,
  	"quantity" numeric NOT NULL,
  	"line_total" numeric NOT NULL
  );
  
  CREATE TABLE "orders_status_history" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"status" varchar,
  	"payment_status" varchar,
  	"at" timestamp(3) with time zone,
  	"by" varchar,
  	"note" varchar
  );
  
  CREATE TABLE "orders" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"subtotal" numeric NOT NULL,
  	"discount" numeric DEFAULT 0,
  	"shipping_fee" numeric DEFAULT 0,
  	"total" numeric NOT NULL,
  	"coupon_code" varchar,
  	"delivery_method" varchar,
  	"delivery_zone" varchar,
  	"customer_name" varchar NOT NULL,
  	"customer_phone" varchar NOT NULL,
  	"customer_email" varchar,
  	"division" varchar,
  	"district" "enum_orders_district",
  	"area" varchar,
  	"address" varchar NOT NULL,
  	"customer_notes" varchar,
  	"customer_id" integer,
  	"order_number" varchar NOT NULL,
  	"status" "enum_orders_status" DEFAULT 'pending' NOT NULL,
  	"payment_status" "enum_orders_payment_status" DEFAULT 'unpaid' NOT NULL,
  	"payment_method" "enum_orders_payment_method" NOT NULL,
  	"status_note" varchar,
  	"admin_notes" varchar,
  	"locale" "enum_orders_locale" DEFAULT 'bn',
  	"idempotency_key" varchar,
  	"stock_restored" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "payments" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order_id" integer NOT NULL,
  	"reference" varchar NOT NULL,
  	"provider" "enum_payments_provider" NOT NULL,
  	"amount" numeric NOT NULL,
  	"currency" varchar DEFAULT 'BDT',
  	"status" "enum_payments_status" DEFAULT 'initiated' NOT NULL,
  	"transaction_id" varchar,
  	"gateway_payment_id" varchar,
  	"verified_at" timestamp(3) with time zone,
  	"failure_reason" varchar,
  	"gateway_response" jsonb,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "customers" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"name" varchar NOT NULL,
  	"phone" varchar NOT NULL,
  	"email" varchar,
  	"last_address_division" varchar,
  	"last_address_district" "enum_customers_last_address_district",
  	"last_address_area" varchar,
  	"last_address_address" varchar,
  	"order_count" numeric DEFAULT 0,
  	"total_spent" numeric DEFAULT 0,
  	"last_order_at" timestamp(3) with time zone,
  	"notes" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "coupons" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"code" varchar NOT NULL,
  	"description" varchar,
  	"active" boolean DEFAULT true,
  	"type" "enum_coupons_type" DEFAULT 'percent' NOT NULL,
  	"percent" numeric,
  	"amount" numeric,
  	"min_subtotal" numeric,
  	"max_discount" numeric,
  	"starts_at" timestamp(3) with time zone,
  	"ends_at" timestamp(3) with time zone,
  	"usage_limit" numeric,
  	"used_count" numeric DEFAULT 0,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "media" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"credit" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"url" varchar,
  	"thumbnail_u_r_l" varchar,
  	"filename" varchar,
  	"mime_type" varchar,
  	"filesize" numeric,
  	"width" numeric,
  	"height" numeric,
  	"focal_x" numeric,
  	"focal_y" numeric,
  	"sizes_thumbnail_url" varchar,
  	"sizes_thumbnail_width" numeric,
  	"sizes_thumbnail_height" numeric,
  	"sizes_thumbnail_mime_type" varchar,
  	"sizes_thumbnail_filesize" numeric,
  	"sizes_thumbnail_filename" varchar,
  	"sizes_card_url" varchar,
  	"sizes_card_width" numeric,
  	"sizes_card_height" numeric,
  	"sizes_card_mime_type" varchar,
  	"sizes_card_filesize" numeric,
  	"sizes_card_filename" varchar,
  	"sizes_large_url" varchar,
  	"sizes_large_width" numeric,
  	"sizes_large_height" numeric,
  	"sizes_large_mime_type" varchar,
  	"sizes_large_filesize" numeric,
  	"sizes_large_filename" varchar,
  	"sizes_og_url" varchar,
  	"sizes_og_width" numeric,
  	"sizes_og_height" numeric,
  	"sizes_og_mime_type" varchar,
  	"sizes_og_filesize" numeric,
  	"sizes_og_filename" varchar
  );
  
  CREATE TABLE "media_locales" (
  	"alt" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "faqs" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"topic" "enum_faqs_topic" DEFAULT 'orders',
  	"show_on_home" boolean DEFAULT true,
  	"sort_order" numeric DEFAULT 0,
  	"status" "enum_faqs_status" DEFAULT 'published' NOT NULL,
  	"translation_status" "enum_faqs_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "faqs_locales" (
  	"question" varchar NOT NULL,
  	"answer" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "testimonials" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"customer_name" varchar NOT NULL,
  	"rating" numeric,
  	"product_id" integer,
  	"order_id" integer,
  	"moderation" "enum_testimonials_moderation" DEFAULT 'pending' NOT NULL,
  	"consent_to_publish" boolean DEFAULT false,
  	"source" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "testimonials_locales" (
  	"location" varchar,
  	"quote" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "posts" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"cover_image_id" integer,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"status" "enum_posts_status" DEFAULT 'draft' NOT NULL,
  	"published_at" timestamp(3) with time zone,
  	"author" varchar,
  	"translation_status" "enum_posts_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "posts_locales" (
  	"title" varchar NOT NULL,
  	"excerpt" varchar,
  	"content" jsonb,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "posts_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"products_id" integer
  );
  
  CREATE TABLE "pages" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"kind" "enum_pages_kind" DEFAULT 'info',
  	"status" "enum_pages_status" DEFAULT 'published' NOT NULL,
  	"translation_status" "enum_pages_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "pages_locales" (
  	"title" varchar NOT NULL,
  	"intro" varchar,
  	"content" jsonb,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "redirects" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"type" "enum_redirects_type" NOT NULL,
  	"from_slug" varchar NOT NULL,
  	"to_slug" varchar NOT NULL,
  	"automatic" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "users_roles" (
  	"order" integer NOT NULL,
  	"parent_id" integer NOT NULL,
  	"value" "enum_users_roles",
  	"id" serial PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "users_sessions" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"created_at" timestamp(3) with time zone,
  	"expires_at" timestamp(3) with time zone NOT NULL
  );
  
  CREATE TABLE "users" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"name" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"email" varchar NOT NULL,
  	"reset_password_token" varchar,
  	"reset_password_expiration" timestamp(3) with time zone,
  	"salt" varchar,
  	"hash" varchar,
  	"reset_password_requested_at" timestamp(3) with time zone,
  	"login_attempts" numeric DEFAULT 0,
  	"lock_until" timestamp(3) with time zone
  );
  
  CREATE TABLE "payload_kv" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"key" varchar NOT NULL,
  	"data" jsonb NOT NULL
  );
  
  CREATE TABLE "payload_locked_documents" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"global_slug" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "payload_locked_documents_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"products_id" integer,
  	"categories_id" integer,
  	"stock_adjustments_id" integer,
  	"orders_id" integer,
  	"payments_id" integer,
  	"customers_id" integer,
  	"coupons_id" integer,
  	"media_id" integer,
  	"faqs_id" integer,
  	"testimonials_id" integer,
  	"posts_id" integer,
  	"pages_id" integer,
  	"redirects_id" integer,
  	"users_id" integer
  );
  
  CREATE TABLE "payload_preferences" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"key" varchar,
  	"value" jsonb,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "payload_preferences_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"users_id" integer
  );
  
  CREATE TABLE "payload_migrations" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"name" varchar,
  	"batch" numeric,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "homepage_benefits" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"icon" "enum_homepage_benefits_icon" DEFAULT 'leaf'
  );
  
  CREATE TABLE "homepage_benefits_locales" (
  	"title" varchar NOT NULL,
  	"text" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "homepage" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"announcement_enabled" boolean DEFAULT true,
  	"announcement_href" varchar,
  	"announcement_tone" "enum_homepage_announcement_tone" DEFAULT 'green',
  	"hero_image_id" integer,
  	"hero_primary_cta_href" varchar,
  	"hero_secondary_cta_href" varchar,
  	"hero_seasonal_badge_enabled" boolean DEFAULT true,
  	"categories_section_enabled" boolean DEFAULT true,
  	"featured_enabled" boolean DEFAULT true,
  	"featured_category_id" integer,
  	"featured_limit" numeric DEFAULT 8,
  	"featured_cta_href" varchar,
  	"traditional_enabled" boolean DEFAULT true,
  	"traditional_per_category" numeric DEFAULT 4,
  	"popular_enabled" boolean DEFAULT true,
  	"promo_enabled" boolean DEFAULT true,
  	"promo_image_id" integer,
  	"promo_cta_href" varchar,
  	"story_enabled" boolean DEFAULT true,
  	"story_image_id" integer,
  	"story_cta_href" varchar,
  	"testimonials_enabled" boolean DEFAULT true,
  	"faq_enabled" boolean DEFAULT true,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "homepage_locales" (
  	"announcement_text" varchar,
  	"hero_headline" varchar NOT NULL,
  	"hero_subheadline" varchar,
  	"hero_primary_cta_label" varchar,
  	"hero_secondary_cta_label" varchar,
  	"hero_seasonal_badge_text" varchar,
  	"categories_section_heading" varchar,
  	"featured_heading" varchar,
  	"featured_intro" varchar,
  	"featured_cta_label" varchar,
  	"traditional_heading" varchar,
  	"traditional_intro" varchar,
  	"popular_heading" varchar,
  	"promo_heading" varchar,
  	"promo_text" varchar,
  	"promo_cta_label" varchar,
  	"story_heading" varchar,
  	"story_body" varchar,
  	"story_cta_label" varchar,
  	"testimonials_heading" varchar,
  	"faq_heading" varchar,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "homepage_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"categories_id" integer,
  	"products_id" integer
  );
  
  CREATE TABLE "branding_socials" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"platform" "enum_branding_socials_platform" NOT NULL,
  	"url" varchar NOT NULL
  );
  
  CREATE TABLE "branding" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"logo_id" integer,
  	"logo_mobile_id" integer,
  	"logo_footer_id" integer,
  	"favicon_id" integer,
  	"colors_primary" varchar DEFAULT '#245B32',
  	"colors_secondary" varchar DEFAULT '#477B3B',
  	"colors_accent" varchar DEFAULT '#FFC928',
  	"colors_accent_warm" varchar DEFAULT '#F59A23',
  	"colors_background" varchar DEFAULT '#FFF9ED',
  	"colors_text" varchar DEFAULT '#243126',
  	"default_share_image_id" integer,
  	"phone" varchar,
  	"email" varchar,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "branding_locales" (
  	"brand_name" varchar DEFAULT 'আম্রকুঞ্জ' NOT NULL,
  	"tagline" varchar,
  	"site_title" varchar NOT NULL,
  	"default_seo_title" varchar,
  	"default_seo_description" varchar,
  	"address" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "contact_settings_show_on" (
  	"order" integer NOT NULL,
  	"parent_id" integer NOT NULL,
  	"value" "enum_contact_settings_show_on",
  	"id" serial PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "contact_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"whatsapp_enabled" boolean DEFAULT true,
  	"whatsapp_number" varchar,
  	"message_bn" varchar DEFAULT 'আসসালামু আলাইকুম! আমি আপনাদের পণ্য সম্পর্কে জানতে চাই।',
  	"message_en" varchar DEFAULT 'Hello! I''d like to know more about your products.',
  	"position" "enum_contact_settings_position" DEFAULT 'right',
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "contact_settings_locales" (
  	"tooltip" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "navigation_header_links" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"href" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_header_links_locales" (
  	"label" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns_links" (
  	"_order" integer NOT NULL,
  	"_parent_id" varchar NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"href" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns_links_locales" (
  	"label" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns_locales" (
  	"title" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "navigation" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "navigation_locales" (
  	"footer_description" varchar,
  	"payment_note" varchar,
  	"copyright" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "delivery_settings_zones_districts" (
  	"order" integer NOT NULL,
  	"parent_id" varchar NOT NULL,
  	"value" "enum_delivery_settings_zones_districts",
  	"id" serial PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "delivery_settings_zones" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"code" varchar NOT NULL,
  	"enabled" boolean DEFAULT true,
  	"is_default" boolean DEFAULT false,
  	"fee" numeric NOT NULL,
  	"free_over" numeric
  );
  
  CREATE TABLE "delivery_settings_zones_locales" (
  	"name" varchar NOT NULL,
  	"estimate" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "delivery_settings_methods" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"code" varchar NOT NULL,
  	"surcharge" numeric DEFAULT 0,
  	"enabled" boolean DEFAULT true
  );
  
  CREATE TABLE "delivery_settings_methods_locales" (
  	"name" varchar NOT NULL,
  	"description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "delivery_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "delivery_settings_locales" (
  	"product_page_note" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "payment_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"cod_enabled" boolean DEFAULT true,
  	"cod_max_total" numeric,
  	"sslcommerz_enabled" boolean DEFAULT false,
  	"bkash_enabled" boolean DEFAULT false,
  	"nagad_enabled" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "payment_settings_locales" (
  	"checkout_note" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "analytics_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"ga4_id" varchar,
  	"gtm_id" varchar,
  	"search_console_verification" varchar,
  	"require_consent" boolean DEFAULT true,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  ALTER TABLE "products_attributes" ADD CONSTRAINT "products_attributes_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_attributes_locales" ADD CONSTRAINT "products_attributes_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products_attributes"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_variants" ADD CONSTRAINT "products_variants_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_variants_locales" ADD CONSTRAINT "products_variants_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products_variants"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products" ADD CONSTRAINT "products_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "products_locales" ADD CONSTRAINT "products_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_texts" ADD CONSTRAINT "products_texts_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_media_fk" FOREIGN KEY ("media_id") REFERENCES "public"."media"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_categories_fk" FOREIGN KEY ("categories_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_image_id_media_id_fk" FOREIGN KEY ("image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_banner_id_media_id_fk" FOREIGN KEY ("banner_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_parent_id_categories_id_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."categories"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories_locales" ADD CONSTRAINT "categories_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "orders_items" ADD CONSTRAINT "orders_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "orders_items" ADD CONSTRAINT "orders_items_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "orders_status_history" ADD CONSTRAINT "orders_status_history_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "orders" ADD CONSTRAINT "orders_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "payments" ADD CONSTRAINT "payments_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "media_locales" ADD CONSTRAINT "media_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."media"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "faqs_locales" ADD CONSTRAINT "faqs_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."faqs"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "testimonials" ADD CONSTRAINT "testimonials_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "testimonials" ADD CONSTRAINT "testimonials_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "testimonials_locales" ADD CONSTRAINT "testimonials_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."testimonials"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "posts" ADD CONSTRAINT "posts_cover_image_id_media_id_fk" FOREIGN KEY ("cover_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "posts" ADD CONSTRAINT "posts_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "posts_locales" ADD CONSTRAINT "posts_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "posts_rels" ADD CONSTRAINT "posts_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "posts_rels" ADD CONSTRAINT "posts_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "pages" ADD CONSTRAINT "pages_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "pages_locales" ADD CONSTRAINT "pages_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."pages"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "users_roles" ADD CONSTRAINT "users_roles_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "users_sessions" ADD CONSTRAINT "users_sessions_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."payload_locked_documents"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_categories_fk" FOREIGN KEY ("categories_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_stock_adjustments_fk" FOREIGN KEY ("stock_adjustments_id") REFERENCES "public"."stock_adjustments"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_orders_fk" FOREIGN KEY ("orders_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_payments_fk" FOREIGN KEY ("payments_id") REFERENCES "public"."payments"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_customers_fk" FOREIGN KEY ("customers_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_coupons_fk" FOREIGN KEY ("coupons_id") REFERENCES "public"."coupons"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_media_fk" FOREIGN KEY ("media_id") REFERENCES "public"."media"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_faqs_fk" FOREIGN KEY ("faqs_id") REFERENCES "public"."faqs"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_testimonials_fk" FOREIGN KEY ("testimonials_id") REFERENCES "public"."testimonials"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_posts_fk" FOREIGN KEY ("posts_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_pages_fk" FOREIGN KEY ("pages_id") REFERENCES "public"."pages"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_redirects_fk" FOREIGN KEY ("redirects_id") REFERENCES "public"."redirects"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_preferences_rels" ADD CONSTRAINT "payload_preferences_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."payload_preferences"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_preferences_rels" ADD CONSTRAINT "payload_preferences_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_benefits" ADD CONSTRAINT "homepage_benefits_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."homepage"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_benefits_locales" ADD CONSTRAINT "homepage_benefits_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."homepage_benefits"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_hero_image_id_media_id_fk" FOREIGN KEY ("hero_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_featured_category_id_categories_id_fk" FOREIGN KEY ("featured_category_id") REFERENCES "public"."categories"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_promo_image_id_media_id_fk" FOREIGN KEY ("promo_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_story_image_id_media_id_fk" FOREIGN KEY ("story_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage_locales" ADD CONSTRAINT "homepage_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."homepage"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_rels" ADD CONSTRAINT "homepage_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."homepage"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_rels" ADD CONSTRAINT "homepage_rels_categories_fk" FOREIGN KEY ("categories_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_rels" ADD CONSTRAINT "homepage_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "branding_socials" ADD CONSTRAINT "branding_socials_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."branding"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_logo_id_media_id_fk" FOREIGN KEY ("logo_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_logo_mobile_id_media_id_fk" FOREIGN KEY ("logo_mobile_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_logo_footer_id_media_id_fk" FOREIGN KEY ("logo_footer_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_favicon_id_media_id_fk" FOREIGN KEY ("favicon_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_default_share_image_id_media_id_fk" FOREIGN KEY ("default_share_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding_locales" ADD CONSTRAINT "branding_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."branding"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "contact_settings_show_on" ADD CONSTRAINT "contact_settings_show_on_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."contact_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "contact_settings_locales" ADD CONSTRAINT "contact_settings_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."contact_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_header_links" ADD CONSTRAINT "navigation_header_links_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_header_links_locales" ADD CONSTRAINT "navigation_header_links_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_header_links"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns_links" ADD CONSTRAINT "navigation_footer_columns_links_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_footer_columns"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns_links_locales" ADD CONSTRAINT "navigation_footer_columns_links_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_footer_columns_links"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns" ADD CONSTRAINT "navigation_footer_columns_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns_locales" ADD CONSTRAINT "navigation_footer_columns_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_footer_columns"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_locales" ADD CONSTRAINT "navigation_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_zones_districts" ADD CONSTRAINT "delivery_settings_zones_districts_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."delivery_settings_zones"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_zones" ADD CONSTRAINT "delivery_settings_zones_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_zones_locales" ADD CONSTRAINT "delivery_settings_zones_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings_zones"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_methods" ADD CONSTRAINT "delivery_settings_methods_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_methods_locales" ADD CONSTRAINT "delivery_settings_methods_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings_methods"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_locales" ADD CONSTRAINT "delivery_settings_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payment_settings_locales" ADD CONSTRAINT "payment_settings_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."payment_settings"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "products_attributes_order_idx" ON "products_attributes" USING btree ("_order");
  CREATE INDEX "products_attributes_parent_id_idx" ON "products_attributes" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "products_attributes_locales_locale_parent_id_unique" ON "products_attributes_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "products_attributes_locales_parent_id_idx" ON "products_attributes_locales" USING btree ("_parent_id");
  CREATE INDEX "products_variants_order_idx" ON "products_variants" USING btree ("_order");
  CREATE INDEX "products_variants_parent_id_idx" ON "products_variants" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "products_variants_locales_locale_parent_id_unique" ON "products_variants_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "products_variants_locales_parent_id_idx" ON "products_variants_locales" USING btree ("_parent_id");
  CREATE INDEX "products_seo_seo_og_image_idx" ON "products" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "products_slug_idx" ON "products" USING btree ("slug");
  CREATE INDEX "products_status_idx" ON "products" USING btree ("status");
  CREATE INDEX "products_total_stock_idx" ON "products" USING btree ("total_stock");
  CREATE INDEX "products_search_text_idx" ON "products" USING btree ("search_text");
  CREATE INDEX "products_updated_at_idx" ON "products" USING btree ("updated_at");
  CREATE INDEX "products_created_at_idx" ON "products" USING btree ("created_at");
  CREATE UNIQUE INDEX "products_locales_locale_parent_id_unique" ON "products_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "products_locales_parent_id_idx" ON "products_locales" USING btree ("_parent_id");
  CREATE INDEX "products_texts_order_parent" ON "products_texts" USING btree ("order","parent_id");
  CREATE INDEX "products_rels_order_idx" ON "products_rels" USING btree ("order");
  CREATE INDEX "products_rels_parent_idx" ON "products_rels" USING btree ("parent_id");
  CREATE INDEX "products_rels_path_idx" ON "products_rels" USING btree ("path");
  CREATE INDEX "products_rels_media_id_idx" ON "products_rels" USING btree ("media_id");
  CREATE INDEX "products_rels_categories_id_idx" ON "products_rels" USING btree ("categories_id");
  CREATE INDEX "products_rels_products_id_idx" ON "products_rels" USING btree ("products_id");
  CREATE INDEX "categories_image_idx" ON "categories" USING btree ("image_id");
  CREATE INDEX "categories_banner_idx" ON "categories" USING btree ("banner_id");
  CREATE INDEX "categories_seo_seo_og_image_idx" ON "categories" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "categories_slug_idx" ON "categories" USING btree ("slug");
  CREATE INDEX "categories_parent_idx" ON "categories" USING btree ("parent_id");
  CREATE INDEX "categories_updated_at_idx" ON "categories" USING btree ("updated_at");
  CREATE INDEX "categories_created_at_idx" ON "categories" USING btree ("created_at");
  CREATE UNIQUE INDEX "categories_locales_locale_parent_id_unique" ON "categories_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "categories_locales_parent_id_idx" ON "categories_locales" USING btree ("_parent_id");
  CREATE INDEX "stock_adjustments_sku_idx" ON "stock_adjustments" USING btree ("sku");
  CREATE INDEX "stock_adjustments_product_idx" ON "stock_adjustments" USING btree ("product_id");
  CREATE INDEX "stock_adjustments_order_idx" ON "stock_adjustments" USING btree ("order_id");
  CREATE INDEX "stock_adjustments_updated_at_idx" ON "stock_adjustments" USING btree ("updated_at");
  CREATE INDEX "stock_adjustments_created_at_idx" ON "stock_adjustments" USING btree ("created_at");
  CREATE INDEX "orders_items_order_idx" ON "orders_items" USING btree ("_order");
  CREATE INDEX "orders_items_parent_id_idx" ON "orders_items" USING btree ("_parent_id");
  CREATE INDEX "orders_items_product_idx" ON "orders_items" USING btree ("product_id");
  CREATE INDEX "orders_status_history_order_idx" ON "orders_status_history" USING btree ("_order");
  CREATE INDEX "orders_status_history_parent_id_idx" ON "orders_status_history" USING btree ("_parent_id");
  CREATE INDEX "orders_customer_phone_idx" ON "orders" USING btree ("customer_phone");
  CREATE INDEX "orders_customer_idx" ON "orders" USING btree ("customer_id");
  CREATE UNIQUE INDEX "orders_order_number_idx" ON "orders" USING btree ("order_number");
  CREATE INDEX "orders_status_idx" ON "orders" USING btree ("status");
  CREATE INDEX "orders_payment_status_idx" ON "orders" USING btree ("payment_status");
  CREATE UNIQUE INDEX "orders_idempotency_key_idx" ON "orders" USING btree ("idempotency_key");
  CREATE INDEX "orders_updated_at_idx" ON "orders" USING btree ("updated_at");
  CREATE INDEX "orders_created_at_idx" ON "orders" USING btree ("created_at");
  CREATE INDEX "payments_order_idx" ON "payments" USING btree ("order_id");
  CREATE UNIQUE INDEX "payments_reference_idx" ON "payments" USING btree ("reference");
  CREATE INDEX "payments_transaction_id_idx" ON "payments" USING btree ("transaction_id");
  CREATE INDEX "payments_gateway_payment_id_idx" ON "payments" USING btree ("gateway_payment_id");
  CREATE INDEX "payments_updated_at_idx" ON "payments" USING btree ("updated_at");
  CREATE INDEX "payments_created_at_idx" ON "payments" USING btree ("created_at");
  CREATE UNIQUE INDEX "customers_phone_idx" ON "customers" USING btree ("phone");
  CREATE INDEX "customers_updated_at_idx" ON "customers" USING btree ("updated_at");
  CREATE INDEX "customers_created_at_idx" ON "customers" USING btree ("created_at");
  CREATE UNIQUE INDEX "coupons_code_idx" ON "coupons" USING btree ("code");
  CREATE INDEX "coupons_updated_at_idx" ON "coupons" USING btree ("updated_at");
  CREATE INDEX "coupons_created_at_idx" ON "coupons" USING btree ("created_at");
  CREATE INDEX "media_updated_at_idx" ON "media" USING btree ("updated_at");
  CREATE INDEX "media_created_at_idx" ON "media" USING btree ("created_at");
  CREATE UNIQUE INDEX "media_filename_idx" ON "media" USING btree ("filename");
  CREATE INDEX "media_sizes_thumbnail_sizes_thumbnail_filename_idx" ON "media" USING btree ("sizes_thumbnail_filename");
  CREATE INDEX "media_sizes_card_sizes_card_filename_idx" ON "media" USING btree ("sizes_card_filename");
  CREATE INDEX "media_sizes_large_sizes_large_filename_idx" ON "media" USING btree ("sizes_large_filename");
  CREATE INDEX "media_sizes_og_sizes_og_filename_idx" ON "media" USING btree ("sizes_og_filename");
  CREATE UNIQUE INDEX "media_locales_locale_parent_id_unique" ON "media_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "media_locales_parent_id_idx" ON "media_locales" USING btree ("_parent_id");
  CREATE INDEX "faqs_status_idx" ON "faqs" USING btree ("status");
  CREATE INDEX "faqs_updated_at_idx" ON "faqs" USING btree ("updated_at");
  CREATE INDEX "faqs_created_at_idx" ON "faqs" USING btree ("created_at");
  CREATE UNIQUE INDEX "faqs_locales_locale_parent_id_unique" ON "faqs_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "faqs_locales_parent_id_idx" ON "faqs_locales" USING btree ("_parent_id");
  CREATE INDEX "testimonials_product_idx" ON "testimonials" USING btree ("product_id");
  CREATE INDEX "testimonials_order_idx" ON "testimonials" USING btree ("order_id");
  CREATE INDEX "testimonials_updated_at_idx" ON "testimonials" USING btree ("updated_at");
  CREATE INDEX "testimonials_created_at_idx" ON "testimonials" USING btree ("created_at");
  CREATE UNIQUE INDEX "testimonials_locales_locale_parent_id_unique" ON "testimonials_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "testimonials_locales_parent_id_idx" ON "testimonials_locales" USING btree ("_parent_id");
  CREATE INDEX "posts_cover_image_idx" ON "posts" USING btree ("cover_image_id");
  CREATE INDEX "posts_seo_seo_og_image_idx" ON "posts" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "posts_slug_idx" ON "posts" USING btree ("slug");
  CREATE INDEX "posts_status_idx" ON "posts" USING btree ("status");
  CREATE INDEX "posts_updated_at_idx" ON "posts" USING btree ("updated_at");
  CREATE INDEX "posts_created_at_idx" ON "posts" USING btree ("created_at");
  CREATE UNIQUE INDEX "posts_locales_locale_parent_id_unique" ON "posts_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "posts_locales_parent_id_idx" ON "posts_locales" USING btree ("_parent_id");
  CREATE INDEX "posts_rels_order_idx" ON "posts_rels" USING btree ("order");
  CREATE INDEX "posts_rels_parent_idx" ON "posts_rels" USING btree ("parent_id");
  CREATE INDEX "posts_rels_path_idx" ON "posts_rels" USING btree ("path");
  CREATE INDEX "posts_rels_products_id_idx" ON "posts_rels" USING btree ("products_id");
  CREATE INDEX "pages_seo_seo_og_image_idx" ON "pages" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "pages_slug_idx" ON "pages" USING btree ("slug");
  CREATE INDEX "pages_status_idx" ON "pages" USING btree ("status");
  CREATE INDEX "pages_updated_at_idx" ON "pages" USING btree ("updated_at");
  CREATE INDEX "pages_created_at_idx" ON "pages" USING btree ("created_at");
  CREATE UNIQUE INDEX "pages_locales_locale_parent_id_unique" ON "pages_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "pages_locales_parent_id_idx" ON "pages_locales" USING btree ("_parent_id");
  CREATE INDEX "redirects_from_slug_idx" ON "redirects" USING btree ("from_slug");
  CREATE INDEX "redirects_updated_at_idx" ON "redirects" USING btree ("updated_at");
  CREATE INDEX "redirects_created_at_idx" ON "redirects" USING btree ("created_at");
  CREATE INDEX "users_roles_order_idx" ON "users_roles" USING btree ("order");
  CREATE INDEX "users_roles_parent_idx" ON "users_roles" USING btree ("parent_id");
  CREATE INDEX "users_sessions_order_idx" ON "users_sessions" USING btree ("_order");
  CREATE INDEX "users_sessions_parent_id_idx" ON "users_sessions" USING btree ("_parent_id");
  CREATE INDEX "users_updated_at_idx" ON "users" USING btree ("updated_at");
  CREATE INDEX "users_created_at_idx" ON "users" USING btree ("created_at");
  CREATE UNIQUE INDEX "users_email_idx" ON "users" USING btree ("email");
  CREATE UNIQUE INDEX "payload_kv_key_idx" ON "payload_kv" USING btree ("key");
  CREATE INDEX "payload_locked_documents_global_slug_idx" ON "payload_locked_documents" USING btree ("global_slug");
  CREATE INDEX "payload_locked_documents_updated_at_idx" ON "payload_locked_documents" USING btree ("updated_at");
  CREATE INDEX "payload_locked_documents_created_at_idx" ON "payload_locked_documents" USING btree ("created_at");
  CREATE INDEX "payload_locked_documents_rels_order_idx" ON "payload_locked_documents_rels" USING btree ("order");
  CREATE INDEX "payload_locked_documents_rels_parent_idx" ON "payload_locked_documents_rels" USING btree ("parent_id");
  CREATE INDEX "payload_locked_documents_rels_path_idx" ON "payload_locked_documents_rels" USING btree ("path");
  CREATE INDEX "payload_locked_documents_rels_products_id_idx" ON "payload_locked_documents_rels" USING btree ("products_id");
  CREATE INDEX "payload_locked_documents_rels_categories_id_idx" ON "payload_locked_documents_rels" USING btree ("categories_id");
  CREATE INDEX "payload_locked_documents_rels_stock_adjustments_id_idx" ON "payload_locked_documents_rels" USING btree ("stock_adjustments_id");
  CREATE INDEX "payload_locked_documents_rels_orders_id_idx" ON "payload_locked_documents_rels" USING btree ("orders_id");
  CREATE INDEX "payload_locked_documents_rels_payments_id_idx" ON "payload_locked_documents_rels" USING btree ("payments_id");
  CREATE INDEX "payload_locked_documents_rels_customers_id_idx" ON "payload_locked_documents_rels" USING btree ("customers_id");
  CREATE INDEX "payload_locked_documents_rels_coupons_id_idx" ON "payload_locked_documents_rels" USING btree ("coupons_id");
  CREATE INDEX "payload_locked_documents_rels_media_id_idx" ON "payload_locked_documents_rels" USING btree ("media_id");
  CREATE INDEX "payload_locked_documents_rels_faqs_id_idx" ON "payload_locked_documents_rels" USING btree ("faqs_id");
  CREATE INDEX "payload_locked_documents_rels_testimonials_id_idx" ON "payload_locked_documents_rels" USING btree ("testimonials_id");
  CREATE INDEX "payload_locked_documents_rels_posts_id_idx" ON "payload_locked_documents_rels" USING btree ("posts_id");
  CREATE INDEX "payload_locked_documents_rels_pages_id_idx" ON "payload_locked_documents_rels" USING btree ("pages_id");
  CREATE INDEX "payload_locked_documents_rels_redirects_id_idx" ON "payload_locked_documents_rels" USING btree ("redirects_id");
  CREATE INDEX "payload_locked_documents_rels_users_id_idx" ON "payload_locked_documents_rels" USING btree ("users_id");
  CREATE INDEX "payload_preferences_key_idx" ON "payload_preferences" USING btree ("key");
  CREATE INDEX "payload_preferences_updated_at_idx" ON "payload_preferences" USING btree ("updated_at");
  CREATE INDEX "payload_preferences_created_at_idx" ON "payload_preferences" USING btree ("created_at");
  CREATE INDEX "payload_preferences_rels_order_idx" ON "payload_preferences_rels" USING btree ("order");
  CREATE INDEX "payload_preferences_rels_parent_idx" ON "payload_preferences_rels" USING btree ("parent_id");
  CREATE INDEX "payload_preferences_rels_path_idx" ON "payload_preferences_rels" USING btree ("path");
  CREATE INDEX "payload_preferences_rels_users_id_idx" ON "payload_preferences_rels" USING btree ("users_id");
  CREATE INDEX "payload_migrations_updated_at_idx" ON "payload_migrations" USING btree ("updated_at");
  CREATE INDEX "payload_migrations_created_at_idx" ON "payload_migrations" USING btree ("created_at");
  CREATE INDEX "homepage_benefits_order_idx" ON "homepage_benefits" USING btree ("_order");
  CREATE INDEX "homepage_benefits_parent_id_idx" ON "homepage_benefits" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "homepage_benefits_locales_locale_parent_id_unique" ON "homepage_benefits_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "homepage_benefits_locales_parent_id_idx" ON "homepage_benefits_locales" USING btree ("_parent_id");
  CREATE INDEX "homepage_hero_hero_image_idx" ON "homepage" USING btree ("hero_image_id");
  CREATE INDEX "homepage_featured_featured_category_idx" ON "homepage" USING btree ("featured_category_id");
  CREATE INDEX "homepage_promo_promo_image_idx" ON "homepage" USING btree ("promo_image_id");
  CREATE INDEX "homepage_story_story_image_idx" ON "homepage" USING btree ("story_image_id");
  CREATE INDEX "homepage_seo_seo_og_image_idx" ON "homepage" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "homepage_locales_locale_parent_id_unique" ON "homepage_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "homepage_locales_parent_id_idx" ON "homepage_locales" USING btree ("_parent_id");
  CREATE INDEX "homepage_rels_order_idx" ON "homepage_rels" USING btree ("order");
  CREATE INDEX "homepage_rels_parent_idx" ON "homepage_rels" USING btree ("parent_id");
  CREATE INDEX "homepage_rels_path_idx" ON "homepage_rels" USING btree ("path");
  CREATE INDEX "homepage_rels_categories_id_idx" ON "homepage_rels" USING btree ("categories_id");
  CREATE INDEX "homepage_rels_products_id_idx" ON "homepage_rels" USING btree ("products_id");
  CREATE INDEX "branding_socials_order_idx" ON "branding_socials" USING btree ("_order");
  CREATE INDEX "branding_socials_parent_id_idx" ON "branding_socials" USING btree ("_parent_id");
  CREATE INDEX "branding_logo_idx" ON "branding" USING btree ("logo_id");
  CREATE INDEX "branding_logo_mobile_idx" ON "branding" USING btree ("logo_mobile_id");
  CREATE INDEX "branding_logo_footer_idx" ON "branding" USING btree ("logo_footer_id");
  CREATE INDEX "branding_favicon_idx" ON "branding" USING btree ("favicon_id");
  CREATE INDEX "branding_default_share_image_idx" ON "branding" USING btree ("default_share_image_id");
  CREATE UNIQUE INDEX "branding_locales_locale_parent_id_unique" ON "branding_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "branding_locales_parent_id_idx" ON "branding_locales" USING btree ("_parent_id");
  CREATE INDEX "contact_settings_show_on_order_idx" ON "contact_settings_show_on" USING btree ("order");
  CREATE INDEX "contact_settings_show_on_parent_idx" ON "contact_settings_show_on" USING btree ("parent_id");
  CREATE UNIQUE INDEX "contact_settings_locales_locale_parent_id_unique" ON "contact_settings_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "contact_settings_locales_parent_id_idx" ON "contact_settings_locales" USING btree ("_parent_id");
  CREATE INDEX "navigation_header_links_order_idx" ON "navigation_header_links" USING btree ("_order");
  CREATE INDEX "navigation_header_links_parent_id_idx" ON "navigation_header_links" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_header_links_locales_locale_parent_id_unique" ON "navigation_header_links_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_header_links_locales_parent_id_idx" ON "navigation_header_links_locales" USING btree ("_parent_id");
  CREATE INDEX "navigation_footer_columns_links_order_idx" ON "navigation_footer_columns_links" USING btree ("_order");
  CREATE INDEX "navigation_footer_columns_links_parent_id_idx" ON "navigation_footer_columns_links" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_footer_columns_links_locales_locale_parent_id_uni" ON "navigation_footer_columns_links_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_footer_columns_links_locales_parent_id_idx" ON "navigation_footer_columns_links_locales" USING btree ("_parent_id");
  CREATE INDEX "navigation_footer_columns_order_idx" ON "navigation_footer_columns" USING btree ("_order");
  CREATE INDEX "navigation_footer_columns_parent_id_idx" ON "navigation_footer_columns" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_footer_columns_locales_locale_parent_id_unique" ON "navigation_footer_columns_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_footer_columns_locales_parent_id_idx" ON "navigation_footer_columns_locales" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_locales_locale_parent_id_unique" ON "navigation_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_locales_parent_id_idx" ON "navigation_locales" USING btree ("_parent_id");
  CREATE INDEX "delivery_settings_zones_districts_order_idx" ON "delivery_settings_zones_districts" USING btree ("order");
  CREATE INDEX "delivery_settings_zones_districts_parent_idx" ON "delivery_settings_zones_districts" USING btree ("parent_id");
  CREATE INDEX "delivery_settings_zones_order_idx" ON "delivery_settings_zones" USING btree ("_order");
  CREATE INDEX "delivery_settings_zones_parent_id_idx" ON "delivery_settings_zones" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "delivery_settings_zones_locales_locale_parent_id_unique" ON "delivery_settings_zones_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "delivery_settings_zones_locales_parent_id_idx" ON "delivery_settings_zones_locales" USING btree ("_parent_id");
  CREATE INDEX "delivery_settings_methods_order_idx" ON "delivery_settings_methods" USING btree ("_order");
  CREATE INDEX "delivery_settings_methods_parent_id_idx" ON "delivery_settings_methods" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "delivery_settings_methods_locales_locale_parent_id_unique" ON "delivery_settings_methods_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "delivery_settings_methods_locales_parent_id_idx" ON "delivery_settings_methods_locales" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "delivery_settings_locales_locale_parent_id_unique" ON "delivery_settings_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "delivery_settings_locales_parent_id_idx" ON "delivery_settings_locales" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "payment_settings_locales_locale_parent_id_unique" ON "payment_settings_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "payment_settings_locales_parent_id_idx" ON "payment_settings_locales" USING btree ("_parent_id");`)}async function g({db:a,payload:b,req:c}){await a.execute((0,e.ll)`
   DROP TABLE "products_attributes" CASCADE;
  DROP TABLE "products_attributes_locales" CASCADE;
  DROP TABLE "products_variants" CASCADE;
  DROP TABLE "products_variants_locales" CASCADE;
  DROP TABLE "products" CASCADE;
  DROP TABLE "products_locales" CASCADE;
  DROP TABLE "products_texts" CASCADE;
  DROP TABLE "products_rels" CASCADE;
  DROP TABLE "categories" CASCADE;
  DROP TABLE "categories_locales" CASCADE;
  DROP TABLE "stock_adjustments" CASCADE;
  DROP TABLE "orders_items" CASCADE;
  DROP TABLE "orders_status_history" CASCADE;
  DROP TABLE "orders" CASCADE;
  DROP TABLE "payments" CASCADE;
  DROP TABLE "customers" CASCADE;
  DROP TABLE "coupons" CASCADE;
  DROP TABLE "media" CASCADE;
  DROP TABLE "media_locales" CASCADE;
  DROP TABLE "faqs" CASCADE;
  DROP TABLE "faqs_locales" CASCADE;
  DROP TABLE "testimonials" CASCADE;
  DROP TABLE "testimonials_locales" CASCADE;
  DROP TABLE "posts" CASCADE;
  DROP TABLE "posts_locales" CASCADE;
  DROP TABLE "posts_rels" CASCADE;
  DROP TABLE "pages" CASCADE;
  DROP TABLE "pages_locales" CASCADE;
  DROP TABLE "redirects" CASCADE;
  DROP TABLE "users_roles" CASCADE;
  DROP TABLE "users_sessions" CASCADE;
  DROP TABLE "users" CASCADE;
  DROP TABLE "payload_kv" CASCADE;
  DROP TABLE "payload_locked_documents" CASCADE;
  DROP TABLE "payload_locked_documents_rels" CASCADE;
  DROP TABLE "payload_preferences" CASCADE;
  DROP TABLE "payload_preferences_rels" CASCADE;
  DROP TABLE "payload_migrations" CASCADE;
  DROP TABLE "homepage_benefits" CASCADE;
  DROP TABLE "homepage_benefits_locales" CASCADE;
  DROP TABLE "homepage" CASCADE;
  DROP TABLE "homepage_locales" CASCADE;
  DROP TABLE "homepage_rels" CASCADE;
  DROP TABLE "branding_socials" CASCADE;
  DROP TABLE "branding" CASCADE;
  DROP TABLE "branding_locales" CASCADE;
  DROP TABLE "contact_settings_show_on" CASCADE;
  DROP TABLE "contact_settings" CASCADE;
  DROP TABLE "contact_settings_locales" CASCADE;
  DROP TABLE "navigation_header_links" CASCADE;
  DROP TABLE "navigation_header_links_locales" CASCADE;
  DROP TABLE "navigation_footer_columns_links" CASCADE;
  DROP TABLE "navigation_footer_columns_links_locales" CASCADE;
  DROP TABLE "navigation_footer_columns" CASCADE;
  DROP TABLE "navigation_footer_columns_locales" CASCADE;
  DROP TABLE "navigation" CASCADE;
  DROP TABLE "navigation_locales" CASCADE;
  DROP TABLE "delivery_settings_zones_districts" CASCADE;
  DROP TABLE "delivery_settings_zones" CASCADE;
  DROP TABLE "delivery_settings_zones_locales" CASCADE;
  DROP TABLE "delivery_settings_methods" CASCADE;
  DROP TABLE "delivery_settings_methods_locales" CASCADE;
  DROP TABLE "delivery_settings" CASCADE;
  DROP TABLE "delivery_settings_locales" CASCADE;
  DROP TABLE "payment_settings" CASCADE;
  DROP TABLE "payment_settings_locales" CASCADE;
  DROP TABLE "analytics_settings" CASCADE;
  DROP TYPE "public"."_locales";
  DROP TYPE "public"."enum_products_variants_unit";
  DROP TYPE "public"."enum_products_status";
  DROP TYPE "public"."enum_products_translation_status";
  DROP TYPE "public"."enum_categories_status";
  DROP TYPE "public"."enum_categories_translation_status";
  DROP TYPE "public"."enum_stock_adjustments_reason";
  DROP TYPE "public"."enum_orders_district";
  DROP TYPE "public"."enum_orders_status";
  DROP TYPE "public"."enum_orders_payment_status";
  DROP TYPE "public"."enum_orders_payment_method";
  DROP TYPE "public"."enum_orders_locale";
  DROP TYPE "public"."enum_payments_provider";
  DROP TYPE "public"."enum_payments_status";
  DROP TYPE "public"."enum_customers_last_address_district";
  DROP TYPE "public"."enum_coupons_type";
  DROP TYPE "public"."enum_faqs_topic";
  DROP TYPE "public"."enum_faqs_status";
  DROP TYPE "public"."enum_faqs_translation_status";
  DROP TYPE "public"."enum_testimonials_moderation";
  DROP TYPE "public"."enum_posts_status";
  DROP TYPE "public"."enum_posts_translation_status";
  DROP TYPE "public"."enum_pages_kind";
  DROP TYPE "public"."enum_pages_status";
  DROP TYPE "public"."enum_pages_translation_status";
  DROP TYPE "public"."enum_redirects_type";
  DROP TYPE "public"."enum_users_roles";
  DROP TYPE "public"."enum_homepage_benefits_icon";
  DROP TYPE "public"."enum_homepage_announcement_tone";
  DROP TYPE "public"."enum_branding_socials_platform";
  DROP TYPE "public"."enum_contact_settings_show_on";
  DROP TYPE "public"."enum_contact_settings_position";
  DROP TYPE "public"."enum_delivery_settings_zones_districts";`)}d()}catch(a){d(a)}})},92685:(a,b,c)=>{"use strict";c.d(b,{WhatsAppProduct:()=>h,X:()=>g});var d=c(67484);let e={},f=new Set;function g(){return(0,d.useSyncExternalStore)(a=>(f.add(a),()=>f.delete(a)),()=>e,()=>e)}function h({name:a}){return null}},93787:(a,b,c)=>{"use strict";c.d(b,{Z:()=>i});var d=c(5735),e=c(63059),f=c.n(e),g=c(89592);let h={green:"bg-primary text-cream",mango:"bg-accent text-ink",cream:"bg-mango-tint text-ink"};function i({text:a,href:b,tone:c,locale:e}){if(!a)return null;let j=`block px-4 py-2 text-center text-[0.9rem] ${h[c??"green"]}`;return b?(0,d.jsx)(f(),{href:(0,g.l)(b,e),className:`${j} underline-offset-4 hover:underline`,children:a}):(0,d.jsx)("p",{className:j,children:a})}},95014:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{X:()=>h});var e=c(78853),f=c(60601),g=a([f]);f=(g.then?(await g)():g)[0];let h={slug:"stock-adjustments",labels:{singular:"Stock adjustment",plural:"Stock adjustments"},admin:{group:"Inventory",useAsTitle:"sku",defaultColumns:["createdAt","sku","delta","stockBefore","stockAfter","reason","createdBy"],description:"Add a row to receive new stock or correct a count. Use negative numbers to remove stock."},defaultSort:"-createdAt",access:{read:e.k3,create:e.k3,update:e.eP,delete:e.eP},hooks:{beforeChange:[async({data:a,req:b,operation:c})=>{if("create"!==c||a.systemGenerated)return a;let d=String(a.sku??"").trim().toUpperCase(),e=Number(a.delta);if(!d)throw Error("Enter the SKU of the size/pack to adjust.");if(!Number.isInteger(e)||0===e)throw Error("Change must be a whole number other than 0.");let g=(await b.payload.find({collection:"products",where:{"variants.sku":{equals:d}},limit:1,depth:0,req:b,overrideAccess:!0,locale:"en"})).docs[0],h=g?.variants?.find(a=>a.sku===d);if(!g||!h?.id)throw Error(`No product size with SKU "${d}".`);let i=await (0,f.hP)(b.payload,{productId:g.id,variantId:h.id,delta:e},b);if(!i)throw Error("Could not update stock for this SKU.");return a.sku=d,a.product=g.id,a.variantId=h.id,a.stockBefore=i.before,a.stockAfter=i.after,a.createdBy=b.user?.email??"system",a}],afterChange:[async({doc:a,req:b,operation:c})=>{if("create"===c&&a.product){let c="object"==typeof a.product?a.product.id:a.product;await (0,f.R7)(b.payload,c,b)}return a}]},fields:[{name:"sku",type:"text",required:!0,index:!0,admin:{description:"SKU of the size/pack, e.g. MNG-HIM-5KG"}},{name:"delta",label:"Change (+/−)",type:"number",required:!0},{name:"reason",type:"select",required:!0,defaultValue:"restock",options:[{label:"New stock received",value:"restock"},{label:"Count correction",value:"correction"},{label:"Damaged / spoiled",value:"damage"},{label:"Customer return",value:"return"},{label:"Order placed (automatic)",value:"order"},{label:"Order cancelled (automatic)",value:"order_cancel"}]},{name:"note",type:"textarea"},{name:"product",type:"relationship",relationTo:"products",admin:{readOnly:!0}},{name:"variantId",type:"text",admin:{readOnly:!0,hidden:!0}},{name:"order",type:"relationship",relationTo:"orders",admin:{readOnly:!0}},{name:"stockBefore",type:"number",admin:{readOnly:!0}},{name:"stockAfter",type:"number",admin:{readOnly:!0}},{name:"createdBy",type:"text",admin:{readOnly:!0}},{name:"systemGenerated",type:"checkbox",defaultValue:!1,admin:{hidden:!0},access:{create:()=>!1,update:()=>!1}}]};d()}catch(a){d(a)}})},95710:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\towfi\\\\Documents\\\\mango-shop\\\\mango-shop\\\\src\\\\app\\\\(frontend)\\\\[lang]\\\\not-found.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\towfi\\Documents\\mango-shop\\mango-shop\\src\\app\\(frontend)\\[lang]\\not-found.tsx","default")},96315:(a,b,c)=>{"use strict";c.d(b,{CartButton:()=>i});var d=c(48249),e=c(72860),f=c(67484),g=c(87224),h=c(71788);function i(){let{count:a,ready:b,setDrawerOpen:c,lastAdded:i}=(0,g._)(),{dict:j,t:k,locale:l}=(0,h.s)(),[m,n]=(0,f.useState)(!1);(0,f.useRef)(i?.at);let o=`${j.nav.cart}${b&&a?`, ${k(j.cart.itemCount,{count:a})}`:""}`;return(0,d.jsxs)("button",{type:"button",onClick:()=>c(!0),"aria-label":o,"data-testid":"cart-button",className:"relative inline-flex h-11 w-11 items-center justify-center rounded-[var(--radius-control)] text-primary hover:bg-leaf-tint",children:[(0,d.jsx)(e.A,{className:"h-6 w-6","aria-hidden":!0}),b&&a>0&&(0,d.jsx)("span",{"data-testid":"cart-count",className:`absolute -right-0.5 -top-0.5 min-w-5 rounded-full bg-accent-warm px-1 text-center text-[11px] font-semibold leading-5 text-ink ${m?"cart-pop":""}`,children:a>99?"99+":a.toLocaleString("bn"===l?"bn-BD":"en")})]})}},96487:()=>{},98112:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{T:()=>g,up:()=>f});var e=c(77761);async function f({db:a}){await a.execute((0,e.ll)`
    ALTER TABLE "products_variants" ADD CONSTRAINT "products_variants_stock_nonneg" CHECK ("stock" IS NULL OR "stock" >= 0);
    ALTER TABLE "products_variants" ADD CONSTRAINT "products_variants_price_nonneg" CHECK ("price" >= 0 AND ("sale_price" IS NULL OR "sale_price" >= 0));
    ALTER TABLE "orders" ADD CONSTRAINT "orders_amounts_nonneg" CHECK ("subtotal" >= 0 AND "total" >= 0 AND COALESCE("discount", 0) >= 0 AND COALESCE("shipping_fee", 0) >= 0);
    ALTER TABLE "orders_items" ADD CONSTRAINT "orders_items_qty_pos" CHECK ("quantity" > 0 AND "unit_price" >= 0 AND "line_total" >= 0);
    ALTER TABLE "coupons" ADD CONSTRAINT "coupons_used_nonneg" CHECK (COALESCE("used_count", 0) >= 0);
    CREATE INDEX IF NOT EXISTS "orders_created_at_status_idx" ON "orders" ("created_at", "status");
  `)}async function g({db:a}){await a.execute((0,e.ll)`
    ALTER TABLE "products_variants" DROP CONSTRAINT IF EXISTS "products_variants_stock_nonneg";
    ALTER TABLE "products_variants" DROP CONSTRAINT IF EXISTS "products_variants_price_nonneg";
    ALTER TABLE "orders" DROP CONSTRAINT IF EXISTS "orders_amounts_nonneg";
    ALTER TABLE "orders_items" DROP CONSTRAINT IF EXISTS "orders_items_qty_pos";
    ALTER TABLE "coupons" DROP CONSTRAINT IF EXISTS "coupons_used_nonneg";
    DROP INDEX IF EXISTS "orders_created_at_status_idx";
  `)}d()}catch(a){d(a)}})},98794:(a,b,c)=>{"use strict";c.d(b,{if:()=>f,x7:()=>g});let d=new Map,e=Date.now();function f(a,b,c,g=Date.now()){if(g-e>6e4){for(let[a,b]of d)b.resetAt<=g&&d.delete(a);e=g}let h=d.get(a);if(!h||h.resetAt<=g)return d.set(a,{count:1,resetAt:g+c}),{ok:!0,remaining:b-1,retryAfterSeconds:0};h.count+=1;let i=h.count<=b;return{ok:i,remaining:Math.max(0,b-h.count),retryAfterSeconds:i?0:Math.ceil((h.resetAt-g)/1e3)}}function g(a){let b=a.get("x-real-ip")?.trim();if(b)return b;let c=a.get("x-forwarded-for");if(c){let a=c.split(",").map(a=>a.trim()).filter(Boolean);if(a.length)return a[a.length-1]}return"unknown"}},99139:(a,b,c)=>{"use strict";c.d(b,{ib:()=>d});let d={bn:{label:"বাংলা",htmlLang:"bn",intl:"bn-BD",ogLocale:"bn_BD"},en:{label:"English",htmlLang:"en",intl:"en-BD",ogLocale:"en_US"}}},99459:(a,b,c)=>{"use strict";c.d(b,{TW:()=>f,ib:()=>d.ib,IB:()=>d.IB});var d=c(10550);let e={bn:{common:{skipToContent:"মূল বিষয়বস্তুতে যান",home:"হোম",breadcrumb:"পৃষ্ঠার অবস্থান",loading:"লোড হচ্ছে…",close:"বন্ধ করুন",menu:"মেনু",openMenu:"মেনু খুলুন",search:"খুঁজুন",searchPlaceholder:"আম, গুড়, ঘি খুঁজুন…",viewAll:"সব দেখুন",learnMore:"আরও জানুন",backToShop:"শপে ফিরে যান",tryAgain:"আবার চেষ্টা করুন",language:"ভাষা",required:"আবশ্যক",optional:"ঐচ্ছিক",sample:"নমুনা"},nav:{home:"হোম",breadcrumb:"পৃষ্ঠার অবস্থান",shop:"সব পণ্য",mangoes:"আম",categories:"ক্যাটাগরি",story:"আমাদের গল্প",blog:"ব্লগ",contact:"যোগাযোগ",trackOrder:"অর্ডার ট্র্যাক",cart:"কার্ট",shopNow:"কেনাকাটা করুন"},product:{addToCart:"কার্টে যোগ করুন",adding:"যোগ হচ্ছে…",added:"কার্টে যোগ হয়েছে",outOfStock:"স্টকে নেই",inStock:"স্টকে আছে",lowStock:"মাত্র {count}টি বাকি",buyNow:"এখনই কিনুন",quantity:"পরিমাণ",decrease:"পরিমাণ কমান",increase:"পরিমাণ বাড়ান",chooseOption:"সাইজ বেছে নিন",sale:"ছাড়",off:"{percent}% ছাড়",offUpTo:"সর্বোচ্চ {percent}% ছাড়",regularPrice:"নিয়মিত মূল্য",salePrice:"ছাড়ের মূল্য",description:"বিবরণ",details:"বিস্তারিত",sku:"এসকেইউ",delivery:"ডেলিভারি",deliveryNote:"আপনার জেলা অনুযায়ী চেকআউটে ডেলিভারি চার্জ হিসাব হবে।",related:"আপনার পছন্দ হতে পারে",viewProduct:"{name} দেখুন",addError:"কার্টে যোগ করা যায়নি। আবার চেষ্টা করুন।",gallery:"পণ্যের ছবি",showImage:"{index} নম্বর ছবি দেখুন",featured:"বিশেষ"},shop:{title:"সব পণ্য",resultsFor:"“{query}”-এর ফলাফল",resultCount:"{count}টি পণ্য",noResults:"এই ফিল্টারে কোনো পণ্য পাওয়া যায়নি।",noResultsHint:"অন্য শব্দে খুঁজুন অথবা ফিল্টার মুছে দিন।",clearFilters:"ফিল্টার মুছুন",filters:"ফিল্টার",category:"ক্যাটাগরি",allCategories:"সব ক্যাটাগরি",availability:"প্রাপ্যতা",inStockOnly:"শুধু স্টকে থাকা",price:"মূল্য (৳)",min:"সর্বনিম্ন",max:"সর্বোচ্চ",apply:"প্রয়োগ করুন",sort:"সাজান",sortFeatured:"বিশেষ পণ্য",sortNewest:"নতুন",sortPriceAsc:"দাম: কম থেকে বেশি",sortPriceDesc:"দাম: বেশি থেকে কম",previous:"আগের",next:"পরের",page:"পৃষ্ঠা {page} / {total}",pagination:"পৃষ্ঠা নেভিগেশন"},cart:{title:"আপনার কার্ট",empty:"আপনার কার্ট খালি।",emptyHint:"এই মৌসুমের ফসল থেকে কিছু বেছে নিয়ে শুরু করুন।",startShopping:"কেনাকাটা শুরু করুন",subtotal:"সাবটোটাল",discount:"ছাড়",shipping:"ডেলিভারি চার্জ",shippingAtCheckout:"চেকআউটে হিসাব হবে",free:"ফ্রি",total:"সর্বমোট",checkout:"চেকআউটে যান",continueShopping:"কেনাকাটা চালিয়ে যান",viewCart:"কার্ট দেখুন",remove:"সরান",removeItem:"{name} সরান",itemCount:"{count}টি পণ্য",addedTitle:"কার্টে যোগ হয়েছে",coupon:"কুপন কোড",applyCoupon:"প্রয়োগ করুন",removeCoupon:"কুপন সরান",couponApplied:"কুপন {code} প্রয়োগ হয়েছে",updating:"কার্ট আপডেট হচ্ছে…",issues:{product_unavailable:"এই পণ্যটি এখন আর পাওয়া যাচ্ছে না।",variant_unavailable:"এই সাইজটি এখন আর পাওয়া যাচ্ছে না।",out_of_stock:"স্টকে নেই — এগোতে পণ্যটি সরিয়ে দিন।",insufficient_stock:"মাত্র {available}টি আছে — এগোতে পরিমাণ কমান।",invalid_quantity:"১ থেকে ৫০-এর মধ্যে পরিমাণ বেছে নিন।"}},coupon:{coupon_not_found:"এই কুপন কোডটি নেই।",coupon_inactive:"এই কুপনটি সক্রিয় নয়।",coupon_not_started:"এই কুপনটি এখনও চালু হয়নি।",coupon_expired:"এই কুপনের মেয়াদ শেষ।",coupon_usage_limit:"এই কুপনের ব্যবহারসীমা শেষ।",coupon_min_subtotal:"এই কুপন ব্যবহার করতে আরও পণ্য যোগ করুন।"},checkout:{title:"চেকআউট",contact:"যোগাযোগের তথ্য",address:"ডেলিভারি ঠিকানা",deliveryMethod:"ডেলিভারি পদ্ধতি",payment:"পেমেন্ট",summary:"অর্ডারের সারসংক্ষেপ",name:"পূর্ণ নাম",phone:"মোবাইল নম্বর",phoneHint:"বাংলাদেশি নম্বর, যেমন ০১৭১২৩৪৫৬৭৮",email:"ইমেইল",emailHint:"অর্ডার নিশ্চিতকরণের জন্য",division:"বিভাগ",district:"জেলা",selectDivision:"বিভাগ নির্বাচন করুন",selectDistrict:"জেলা নির্বাচন করুন",area:"এলাকা / থানা",fullAddress:"বাসা, রোড ও পরিচিত স্থান",notes:"অর্ডার নোট",notesHint:"পছন্দের ডেলিভারি সময় বা অন্য কোনো তথ্য",placeOrder:"অর্ডার করুন",placing:"অর্ডার হচ্ছে…",payNow:"পেমেন্টে যান",redirecting:"পেমেন্ট পেজে নেওয়া হচ্ছে…",cod:"ক্যাশ অন ডেলিভারি",codHint:"পণ্য হাতে পেয়ে নগদ টাকা পরিশোধ করুন।",gatewayHint:"নিরাপদে পেমেন্টের জন্য আপনাকে {name}-এ নেওয়া হবে।",agree:"অর্ডার করার মাধ্যমে আপনি আমাদের শর্তাবলি ও নীতিমালায় সম্মত হচ্ছেন।",estimate:"আনুমানিক ডেলিভারি: {estimate}",noMethods:"এখনও কোনো ডেলিভারি পদ্ধতি চালু নেই। অর্ডার করতে আমাদের সাথে যোগাযোগ করুন।",noPayments:"এখনও কোনো পেমেন্ট পদ্ধতি চালু নেই। অর্ডার করতে আমাদের সাথে যোগাযোগ করুন।",emptyCart:"আপনার কার্ট খালি। চেকআউটের আগে পণ্য যোগ করুন।",fixCart:"অর্ডার করার আগে কার্টের কিছু পণ্য ঠিক করতে হবে।",genericError:"অর্ডারটি সম্পন্ন করা যায়নি। ফর্মটি দেখে আবার চেষ্টা করুন।",rateLimited:"অনেকবার চেষ্টা করা হয়েছে। এক মিনিট পর আবার চেষ্টা করুন।",stockChanged:"চেকআউটের সময় স্টক পরিবর্তন হয়েছে। কার্টটি আবার দেখুন।",errors:{name:"আপনার পূর্ণ নাম লিখুন (কমপক্ষে ২ অক্ষর)।",phone:"সঠিক বাংলাদেশি মোবাইল নম্বর দিন, যেমন ০১৭১২৩৪৫৬৭৮।",email:"সঠিক ইমেইল দিন অথবা ঘরটি খালি রাখুন।",division:"আপনার বিভাগ নির্বাচন করুন।",district:"আপনার জেলা নির্বাচন করুন।",area:"আপনার এলাকা বা থানার নাম লিখুন।",address:"পূর্ণ ঠিকানা লিখুন (কমপক্ষে ৮ অক্ষর)।",deliveryMethod:"একটি ডেলিভারি পদ্ধতি বেছে নিন।",paymentMethod:"একটি পেমেন্ট পদ্ধতি বেছে নিন।"}},order:{confirmedTitle:"ধন্যবাদ — আপনার অর্ডারটি গ্রহণ করা হয়েছে",confirmedBody:"পাঠানোর আগে নিশ্চিত করতে আমরা {phone} নম্বরে কল করব।",number:"অর্ডার নম্বর",placedOn:"অর্ডারের তারিখ",status:"অর্ডারের অবস্থা",paymentStatus:"পেমেন্ট",paymentMethod:"পেমেন্ট পদ্ধতি",items:"পণ্যসমূহ",deliverTo:"ডেলিভারি ঠিকানা",saveLink:"পরে অর্ডার দেখতে এই পেজের লিংকটি রেখে দিন, অথবা ফোন নম্বর দিয়ে অর্ডার ট্র্যাক করুন।",payPending:"আপনার পেমেন্ট এখনও সম্পন্ন হয়নি।",retryPayment:"আবার পেমেন্ট করুন",paymentFailed:"পেমেন্ট সম্পন্ন হয়নি। আপনার অর্ডারটি সংরক্ষিত আছে — আবার চেষ্টা করুন বা আমাদের সাথে যোগাযোগ করুন।",trackTitle:"অর্ডার ট্র্যাক করুন",trackIntro:"অর্ডার নম্বর এবং চেকআউটে দেওয়া মোবাইল নম্বরটি লিখুন।",trackSubmit:"অর্ডার খুঁজুন",trackNotFound:"এই অর্ডার নম্বর ও ফোন নম্বরের সাথে কোনো অর্ডার মেলেনি।",history:"অর্ডারের অগ্রগতি",statuses:{pending:"অপেক্ষমাণ",confirmed:"নিশ্চিত",processing:"প্রস্তুত হচ্ছে",shipped:"পাঠানো হয়েছে",delivered:"ডেলিভারি সম্পন্ন",cancelled:"বাতিল"},paymentStatuses:{unpaid:"অপরিশোধিত",pending:"পেমেন্টের অপেক্ষায়",paid:"পরিশোধিত",failed:"ব্যর্থ",refunded:"ফেরত দেওয়া হয়েছে",cancelled:"বাতিল"}},home:{shopByCategory:"ক্যাটাগরি অনুযায়ী কিনুন",featuredMangoes:"এই মৌসুমের আম",allMangoes:"সব আম দেখুন",traditional:"বাংলার রান্নাঘর থেকে",popular:"জনপ্রিয় পণ্য ও কম্বো",testimonials:"ক্রেতারা যা বলছেন",faq:"সাধারণ জিজ্ঞাসা",story:"আমাদের গল্প"},blog:{title:"ব্লগ",intro:"মৌসুম, বাগান আর বাংলার খাবার নিয়ে লেখা।",readMore:"পুরো লেখা পড়ুন",empty:"এখনও কোনো লেখা নেই।",publishedOn:"প্রকাশিত {date}"},footer:{shop:"শপ",help:"সহায়তা",policies:"নীতিমালা",contact:"যোগাযোগ",follow:"আমাদের অনুসরণ করুন",payments:"পেমেন্ট মাধ্যম",rights:"সর্বস্বত্ব সংরক্ষিত।"},whatsapp:{label:"হোয়াটসঅ্যাপে কথা বলুন",productMessage:"আসসালামু আলাইকুম! আমি “{name}” সম্পর্কে জানতে চাই: {url}",cartMessage:"আসসালামু আলাইকুম! আমার অর্ডারের বিষয়ে একটু সাহায্য দরকার।"},notFound:{title:"পেজটি খুঁজে পাওয়া যায়নি",body:"লিংকটি পুরোনো হতে পারে অথবা পেজটি সরানো হয়েছে।"},error:{title:"কিছু একটা সমস্যা হয়েছে",body:"আবার চেষ্টা করুন। সমস্যা থাকলে আমাদের সাথে যোগাযোগ করুন।"},seo:{shopTitle:"সব পণ্য",shopDescription:"বাংলাদেশের তাজা আম, গুড়, ঘি, আচার ও ঐতিহ্যবাহী খাবার।",blogTitle:"ব্লগ",trackTitle:"অর্ডার ট্র্যাক করুন",cartTitle:"আপনার কার্ট",checkoutTitle:"চেকআউট",pageSuffix:"পৃষ্ঠা {page}"},consent:{message:"সাইটটি কীভাবে ব্যবহার হচ্ছে বুঝতে আমরা অ্যানালিটিক্স কুকি ব্যবহার করি। আপনি গ্রহণ বা প্রত্যাখ্যান করতে পারেন।",accept:"গ্রহণ করুন",decline:"প্রত্যাখ্যান"}},en:{common:{skipToContent:"Skip to content",home:"Home",breadcrumb:"Breadcrumb",loading:"Loading…",close:"Close",menu:"Menu",openMenu:"Open menu",search:"Search",searchPlaceholder:"Search mangoes, gur, ghee…",viewAll:"View all",learnMore:"Learn more",backToShop:"Back to shop",tryAgain:"Try again",language:"Language",required:"required",optional:"optional",sample:"Sample"},nav:{home:"Home",breadcrumb:"Breadcrumb",shop:"All products",mangoes:"Mangoes",categories:"Categories",story:"Our story",blog:"Journal",contact:"Contact",trackOrder:"Track order",cart:"Cart",shopNow:"Shop now"},product:{addToCart:"Add to cart",adding:"Adding…",added:"Added to cart",outOfStock:"Out of stock",inStock:"In stock",lowStock:"Only {count} left",buyNow:"Buy now",quantity:"Quantity",decrease:"Decrease quantity",increase:"Increase quantity",chooseOption:"Choose a size",sale:"Sale",off:"{percent}% off",offUpTo:"Up to {percent}% off",regularPrice:"Regular price",salePrice:"Sale price",description:"Description",details:"Details",sku:"SKU",delivery:"Delivery",deliveryNote:"Delivery charge is calculated at checkout based on your district.",related:"You may also like",viewProduct:"View {name}",addError:"Could not add to cart. Please try again.",gallery:"Product images",showImage:"Show image {index}",featured:"Featured"},shop:{title:"All products",resultsFor:"Results for “{query}”",resultCount:"{count} products",noResults:"Nothing matches these filters.",noResultsHint:"Try a different search term or clear the filters.",clearFilters:"Clear filters",filters:"Filters",category:"Category",allCategories:"All categories",availability:"Availability",inStockOnly:"In stock only",price:"Price (৳)",min:"Min",max:"Max",apply:"Apply",sort:"Sort by",sortFeatured:"Featured",sortNewest:"Newest",sortPriceAsc:"Price: low to high",sortPriceDesc:"Price: high to low",previous:"Previous",next:"Next",page:"Page {page} of {total}",pagination:"Pagination"},cart:{title:"Your cart",empty:"Your cart is empty.",emptyHint:"Pick a few things from this season’s harvest to get started.",startShopping:"Start shopping",subtotal:"Subtotal",discount:"Discount",shipping:"Delivery",shippingAtCheckout:"Calculated at checkout",free:"Free",total:"Total",checkout:"Go to checkout",continueShopping:"Continue shopping",viewCart:"View cart",remove:"Remove",removeItem:"Remove {name}",itemCount:"{count} items",addedTitle:"Added to your cart",coupon:"Coupon code",applyCoupon:"Apply",removeCoupon:"Remove coupon",couponApplied:"Coupon {code} applied",updating:"Updating cart…",issues:{product_unavailable:"This product is no longer available.",variant_unavailable:"This size is no longer available.",out_of_stock:"Out of stock — remove it to continue.",insufficient_stock:"Only {available} available — lower the quantity to continue.",invalid_quantity:"Choose a quantity between 1 and 50."}},coupon:{coupon_not_found:"That coupon code does not exist.",coupon_inactive:"That coupon is not active.",coupon_not_started:"That coupon is not valid yet.",coupon_expired:"That coupon has expired.",coupon_usage_limit:"That coupon has reached its usage limit.",coupon_min_subtotal:"Add more items to use this coupon."},checkout:{title:"Checkout",contact:"Contact details",address:"Delivery address",deliveryMethod:"Delivery method",payment:"Payment",summary:"Order summary",name:"Full name",phone:"Mobile number",phoneHint:"Bangladeshi number, e.g. 01712345678",email:"Email",emailHint:"For your order confirmation",division:"Division",district:"District",selectDivision:"Select division",selectDistrict:"Select district",area:"Area / thana",fullAddress:"House, road and landmark",notes:"Order notes",notesHint:"Delivery time preference or anything we should know",placeOrder:"Place order",placing:"Placing order…",payNow:"Continue to payment",redirecting:"Redirecting to payment…",cod:"Cash on delivery",codHint:"Pay in cash when your order arrives.",gatewayHint:"You will be redirected to {name} to pay securely.",agree:"By placing this order you agree to our terms and policies.",estimate:"Estimated delivery: {estimate}",noMethods:"No delivery methods are configured yet. Please contact us to order.",noPayments:"No payment methods are enabled yet. Please contact us to order.",emptyCart:"Your cart is empty. Add products before checking out.",fixCart:"Some items in your cart need attention before you can order.",genericError:"We could not place your order. Please check the form and try again.",rateLimited:"Too many attempts. Please wait a minute and try again.",stockChanged:"Stock changed while you were checking out. Please review your cart.",errors:{name:"Enter your full name (at least 2 characters).",phone:"Enter a valid Bangladeshi mobile number, e.g. 01712345678.",email:"Enter a valid email address or leave it empty.",division:"Select your division.",district:"Select your district.",area:"Enter your area or thana.",address:"Enter your full address (at least 8 characters).",deliveryMethod:"Choose a delivery method.",paymentMethod:"Choose a payment method."}},order:{confirmedTitle:"Thank you — your order is in",confirmedBody:"We will call you at {phone} to confirm before dispatch.",number:"Order number",placedOn:"Placed on",status:"Order status",paymentStatus:"Payment",paymentMethod:"Payment method",items:"Items",deliverTo:"Delivering to",saveLink:"Keep this page’s link to check your order later, or use order tracking with your phone number.",payPending:"Your payment has not been completed yet.",retryPayment:"Try payment again",paymentFailed:"The payment was not completed. Your order is saved — you can try again or contact us.",trackTitle:"Track your order",trackIntro:"Enter your order number and the mobile number used at checkout.",trackSubmit:"Find order",trackNotFound:"No order matches that order number and phone number.",history:"Order progress",statuses:{pending:"Pending",confirmed:"Confirmed",processing:"Processing",shipped:"Shipped",delivered:"Delivered",cancelled:"Cancelled"},paymentStatuses:{unpaid:"Unpaid",pending:"Awaiting payment",paid:"Paid",failed:"Failed",refunded:"Refunded",cancelled:"Cancelled"}},home:{shopByCategory:"Shop by category",featuredMangoes:"This season’s mangoes",allMangoes:"See all mangoes",traditional:"From the Bengal kitchen",popular:"Popular picks and bundles",testimonials:"What customers say",faq:"Questions, answered",story:"Our story"},blog:{title:"Journal",intro:"Notes on seasons, orchards and the food of Bengal.",readMore:"Read article",empty:"No articles yet.",publishedOn:"Published {date}"},footer:{shop:"Shop",help:"Help",policies:"Policies",contact:"Contact",follow:"Follow us",payments:"We accept",rights:"All rights reserved."},whatsapp:{label:"Chat with us on WhatsApp",productMessage:"Hello! I’d like to know about “{name}”: {url}",cartMessage:"Hello! I need some help with my order."},notFound:{title:"This page could not be found",body:"The link may be old or the page may have moved."},error:{title:"Something went wrong",body:"Please try again. If the problem continues, contact us."},seo:{shopTitle:"All products",shopDescription:"Fresh Bangladeshi mangoes, gur, ghee, achar and traditional foods.",blogTitle:"Journal",trackTitle:"Track your order",cartTitle:"Your cart",checkoutTitle:"Checkout",pageSuffix:"Page {page}"},consent:{message:"We use analytics cookies to understand how the shop is used. You can accept or decline.",accept:"Accept",decline:"Decline"}}};function f(a){return e[(0,d.Zd)(a)?a:d.q]}},99795:(a,b,c)=>{"use strict";function d(a,{req:b}){return"bn"!==(b?.locale??"bn")||!!("string"==typeof a?a.trim().length>0:null!=a)||"Required in বাংলা (the default language)."}c.d(b,{E:()=>d})},99879:(a,b,c)=>{"use strict";c.d(b,{N:()=>h});var d=c(78853),e=c(54027),f=c(16332);let g=a=>String(a??"").replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[a]),h={path:"/:id/invoice",method:"get",handler:async a=>{let b;if(!(0,d.hf)(a.user,"admin","manager"))return new Response("Forbidden",{status:403});let c=Number(a.routeParams?.id);if(!Number.isInteger(c))return new Response("Not found",{status:404});try{b=await a.payload.findByID({collection:"orders",id:c,depth:0,req:a,overrideAccess:!1})}catch{return new Response("Not found",{status:404})}let h=await a.payload.findGlobal({slug:"branding",locale:"en",depth:1,req:a}),i=a=>(0,f.$g)(a??0,"en"),j="object"==typeof h.logo&&h.logo?.url?`<img src="${g(h.logo.url)}" alt="" style="height:48px">`:"",k=(b.items??[]).map(a=>`<tr><td>${g(a.productName)}${a.productNameEn&&a.productNameEn!==a.productName?`<br><small>${g(a.productNameEn)}</small>`:""}</td>
        <td>${g(a.variantLabel)}</td><td>${g(a.sku)}</td><td class="n">${a.quantity}</td><td class="n">${i(a.unitPrice)}</td><td class="n">${i(a.lineTotal)}</td></tr>`).join("");return new Response(`<!doctype html><html lang="bn"><head><meta charset="utf-8"><title>Invoice ${g(b.orderNumber)}</title>
<style>
body{font-family:"Hind Siliguri","Noto Sans Bengali",system-ui,sans-serif;color:#243126;max-width:820px;margin:32px auto;padding:0 24px}
h1{font-size:22px;margin:0}table{width:100%;border-collapse:collapse;margin-top:16px}th,td{padding:8px;border-bottom:1px solid #e4dccb;text-align:left;vertical-align:top}
th{background:#f6f0e2;font-weight:600}.n{text-align:right;white-space:nowrap}.grid{display:flex;justify-content:space-between;gap:24px;margin-top:24px}
.tot td{border:none}.tot tr:last-child td{font-weight:700;font-size:18px;border-top:2px solid #243126}small{color:#5b6b5e}
@media print{.noprint{display:none}body{margin:0}}
</style></head><body>
<p class="noprint"><button onclick="window.print()">Print / Save as PDF</button></p>
<div class="grid"><div>${j}<h1>${g(h.brandName)}</h1><small>${g(h.address??"")}<br>${g(h.phone??"")} ${g(h.email??"")}</small></div>
<div style="text-align:right"><h1>Invoice</h1><div>${g(b.orderNumber)}</div><small>${new Date(b.createdAt).toLocaleString("en-GB",{timeZone:"Asia/Dhaka"})}</small></div></div>
<div class="grid"><div><strong>Deliver to</strong><br>${g(b.customerName)}<br>${g(b.customerPhone)}<br>${g(b.address)}<br>${g(b.area)}, ${g(b.district?(0,e.Ce)(b.district,"en"):"")}</div>
<div style="text-align:right"><strong>Payment</strong><br>${g(b.paymentMethod)} — ${g(b.paymentStatus)}<br><strong>Status</strong><br>${g(b.status)}</div></div>
<table><thead><tr><th>Product</th><th>Size</th><th>SKU</th><th class="n">Qty</th><th class="n">Unit</th><th class="n">Total</th></tr></thead><tbody>${k}</tbody></table>
<table class="tot" style="max-width:320px;margin-left:auto"><tr><td>Subtotal</td><td class="n">${i(b.subtotal)}</td></tr>
${b.discount?`<tr><td>Discount ${g(b.couponCode??"")}</td><td class="n">−${i(b.discount)}</td></tr>`:""}
<tr><td>Delivery</td><td class="n">${i(b.shippingFee)}</td></tr><tr><td>Total</td><td class="n">${i(b.total)}</td></tr></table>
${b.customerNotes?`<p><strong>Customer note:</strong> ${g(b.customerNotes)}</p>`:""}
</body></html>`,{headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store","X-Robots-Tag":"noindex"}})}}}};