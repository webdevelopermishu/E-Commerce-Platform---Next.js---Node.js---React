exports.id=6168,exports.ids=[6168],exports.modules={5003:(a,b,c)=>{"use strict";function d(a){return async({doc:b,previousDoc:c,operation:d,req:e})=>{if("update"!==d)return b;let f=c?.slug,g=b?.slug;if(!f||!g||f===g)return b;try{for(let b of(await e.payload.find({collection:"redirects",where:{and:[{type:{equals:a}},{toSlug:{equals:f}}]},limit:100,depth:0,req:e,overrideAccess:!0})).docs)await e.payload.update({collection:"redirects",id:b.id,data:{toSlug:g},req:e,overrideAccess:!0});await e.payload.delete({collection:"redirects",where:{and:[{type:{equals:a}},{fromSlug:{equals:g}}]},req:e,overrideAccess:!0}),await e.payload.create({collection:"redirects",data:{type:a,fromSlug:f,toSlug:g,automatic:!0},req:e,overrideAccess:!0})}catch(a){e.payload.logger.error({err:a,msg:"Failed to create slug redirect"})}return b}}c.d(b,{L:()=>d})},7773:(a,b,c)=>{"use strict";c.d(b,{CQ:()=>m,Gg:()=>n,Me:()=>i,Vx:()=>l,cu:()=>j,sW:()=>o});var d=c(61236),e=c(70667),f=c(29918),g=c(74374);let h=(a,b,c)=>({name:a,label:b,type:"text",defaultValue:c,admin:{width:"33%",components:{Field:"/components/admin/ColorField#ColorField"}},validate:a=>!!(!a||/^#[0-9a-fA-F]{6}$/.test(a))||"Use a 6-digit hex colour like #245B32."}),i={slug:"branding",label:"Branding",admin:{group:"Website Settings",description:"Name, logos, favicon, colours and default SEO. Changes appear on the site immediately."},access:{read:d.ZZ,update:d.Xl},fields:[{type:"tabs",tabs:[{label:"Identity",fields:[{name:"brandName",type:"text",required:!0,localized:!0,validate:g.E,defaultValue:"আম্রকুঞ্জ"},{name:"tagline",type:"text",localized:!0},{name:"siteTitle",label:"Website title",type:"text",required:!0,localized:!0,validate:g.E,admin:{description:"Shown in browser tabs and appended to page titles."}},{type:"row",fields:[{name:"logo",label:"Main logo",type:"upload",relationTo:"media",admin:{width:"33%",description:"SVG or PNG. Wide logos work best."}},{name:"logoMobile",label:"Mobile logo",type:"upload",relationTo:"media",admin:{width:"33%",description:"Optional compact version."}},{name:"logoFooter",label:"Footer logo",type:"upload",relationTo:"media",admin:{width:"33%",description:"Optional light version for dark backgrounds."}}]},{name:"favicon",type:"upload",relationTo:"media",admin:{description:"Square PNG (at least 192\xd7192), SVG or ICO."},filterOptions:{mimeType:{in:["image/png","image/svg+xml","image/x-icon","image/vnd.microsoft.icon"]}}}]},{label:"Colours",description:"Brand colours used across the storefront. Keep good contrast between text and background colours.",fields:[{name:"colors",type:"group",fields:[{type:"row",fields:[h("primary","Primary (deep green)","#245B32"),h("secondary","Secondary (leaf green)","#477B3B"),h("accent","Accent (mango yellow)","#FFC928")]},{type:"row",fields:[h("accentWarm","Warm accent (mango orange)","#F59A23"),h("background","Background (cream)","#FFF9ED"),h("text","Text","#243126")]}]}]},{label:"Default SEO",fields:[{name:"defaultSeoTitle",label:"Default SEO title",type:"text",localized:!0,maxLength:70},{name:"defaultSeoDescription",label:"Default meta description",type:"textarea",localized:!0,maxLength:200},{name:"defaultShareImage",label:"Default social sharing image",type:"upload",relationTo:"media",admin:{description:"1200\xd7630 works best."}}]},{label:"Business contact",fields:[{type:"row",fields:[{name:"phone",type:"text",admin:{width:"50%",description:"Shown to customers, e.g. +880 1712-345678"}},{name:"email",type:"email",admin:{width:"50%"}}]},{name:"address",type:"textarea",localized:!0},{name:"socials",type:"array",labels:{singular:"Social link",plural:"Social links"},fields:[{type:"row",fields:[{name:"platform",type:"select",required:!0,admin:{width:"30%"},options:["facebook","instagram","youtube","tiktok","linkedin","x"].map(a=>({label:a,value:a}))},{name:"url",type:"text",required:!0,admin:{width:"70%"},validate:a=>!!(a&&/^https:\/\//.test(a))||"Use a full https:// link."}]}]}]}]}]},j={slug:"contact-settings",label:"Contact & WhatsApp",admin:{group:"Website Settings"},access:{read:d.ZZ,update:d.Xl},fields:[{name:"whatsappEnabled",label:"Show the WhatsApp button",type:"checkbox",defaultValue:!0},{name:"whatsappNumber",type:"text",admin:{description:"With country code, digits only, e.g. 8801712345678. The button stays hidden until this is set."},validate:a=>!!(!a||/^\d{10,15}$/.test(a.replace(/\D/g,"")))||"Enter 10–15 digits including the country code."},{name:"messageBn",label:"Default message (বাংলা)",type:"textarea",defaultValue:"আসসালামু আলাইকুম! আমি আপনাদের পণ্য সম্পর্কে জানতে চাই।"},{name:"messageEn",label:"Default message (English)",type:"textarea",defaultValue:"Hello! I'd like to know more about your products."},{name:"tooltip",type:"text",localized:!0,admin:{description:"Optional short label shown next to the button on larger screens."}},{name:"position",type:"select",defaultValue:"right",options:[{label:"Bottom right",value:"right"},{label:"Bottom left",value:"left"}]},{name:"showOn",label:"Show on these pages",type:"select",hasMany:!0,defaultValue:["home","shop","category","product","cart","blog","pages","order"],options:[{label:"Homepage",value:"home"},{label:"Shop & search",value:"shop"},{label:"Category pages",value:"category"},{label:"Product pages",value:"product"},{label:"Cart",value:"cart"},{label:"Checkout",value:"checkout"},{label:"Blog",value:"blog"},{label:"Policy & info pages",value:"pages"},{label:"Order & tracking pages",value:"order"}]}]},k=[{type:"row",fields:[{name:"label",type:"text",required:!0,localized:!0,validate:g.E,admin:{width:"50%"}},{name:"href",type:"text",required:!0,admin:{width:"50%",description:"Site path without language, e.g. /shop or /category/mango — or a full https:// URL."},validate:a=>!!(a&&(/^\/[^\s]*$/.test(a)||/^https?:\/\//.test(a)))||"Start with / or https://"}]}],l={slug:"navigation",label:"Header & footer",admin:{group:"Website Settings"},access:{read:d.ZZ,update:d.Xl},fields:[{type:"tabs",tabs:[{label:"Header",fields:[{name:"headerLinks",type:"array",maxRows:8,labels:{singular:"Menu link",plural:"Menu links"},admin:{description:"Main menu. Cart, search and language switch are always shown."},fields:k}]},{label:"Footer",fields:[{name:"footerDescription",type:"textarea",localized:!0},{name:"footerColumns",type:"array",maxRows:4,fields:[{name:"title",type:"text",required:!0,localized:!0,validate:g.E},{name:"links",type:"array",fields:k}]},{name:"paymentNote",type:"text",localized:!0,admin:{description:'e.g. "Cash on delivery, bKash, Nagad and cards via SSLCommerz"'}},{name:"copyright",type:"text",localized:!0,admin:{description:"The year and brand name are added automatically when this is empty."}}]}]}]},m={slug:"delivery-settings",label:"Delivery",admin:{group:"Website Settings",description:"Delivery zones, charges and methods used at checkout."},access:{read:d.ZZ,update:d.k3},fields:[{name:"zones",type:"array",minRows:1,labels:{singular:"Delivery zone",plural:"Delivery zones"},admin:{description:"A district uses the zone that lists it; otherwise the default zone applies. Districts with no zone and no default cannot order."},fields:[{type:"row",fields:[{name:"code",type:"text",required:!0,admin:{width:"25%",description:"e.g. inside-dhaka"}},{name:"name",type:"text",required:!0,localized:!0,validate:g.E,admin:{width:"45%"}},{name:"enabled",type:"checkbox",defaultValue:!0,admin:{width:"15%"}},{name:"isDefault",type:"checkbox",defaultValue:!1,admin:{width:"15%"}}]},{type:"row",fields:[(0,e.$)({name:"fee",label:"Delivery fee (৳)",required:!0,admin:{width:"33%"}}),(0,e.$)({name:"freeOver",label:"Free over (৳)",admin:{width:"33%",description:"Optional"}}),{name:"estimate",type:"text",localized:!0,admin:{width:"34%",description:'e.g. "১–২ দিন" / "1–2 days"'}}]},{name:"districts",type:"select",hasMany:!0,options:f.dn}]},{name:"methods",type:"array",minRows:1,labels:{singular:"Delivery method",plural:"Delivery methods"},fields:[{type:"row",fields:[{name:"code",type:"text",required:!0,admin:{width:"25%",description:"e.g. standard"}},{name:"name",type:"text",required:!0,localized:!0,validate:g.E,admin:{width:"45%"}},(0,e.$)({name:"surcharge",label:"Extra charge (৳)",defaultValue:0,admin:{width:"15%"}}),{name:"enabled",type:"checkbox",defaultValue:!0,admin:{width:"15%"}}]},{name:"description",type:"text",localized:!0}]},{name:"productPageNote",type:"textarea",localized:!0,admin:{description:"Short delivery note shown on every product page."}}]},n={slug:"payment-settings",label:"Payments",admin:{group:"Website Settings",description:"Turn payment methods on or off. Gateway credentials are set as server environment variables, never here."},access:{read:d.Xl,update:d.qc},fields:[{name:"gatewayStatus",type:"ui",admin:{components:{Field:"/components/admin/GatewayStatus#GatewayStatus"}}},{name:"codEnabled",label:"Cash on delivery",type:"checkbox",defaultValue:!0},(0,e.$)({name:"codMaxTotal",label:"Cash on delivery limit (৳)",admin:{description:"Optional: hide COD for orders above this total."}}),{name:"sslcommerzEnabled",label:"SSLCommerz (cards, mobile banking)",type:"checkbox",defaultValue:!1},{name:"bkashEnabled",label:"bKash",type:"checkbox",defaultValue:!1},{name:"nagadEnabled",label:"Nagad",type:"checkbox",defaultValue:!1},{name:"checkoutNote",type:"textarea",localized:!0,admin:{description:"Optional payment instructions shown at checkout."}}]},o={slug:"analytics-settings",label:"Analytics & verification",admin:{group:"Website Settings"},access:{read:d.ZZ,update:d.qc},fields:[{name:"ga4Id",label:"Google Analytics 4 measurement ID",type:"text",admin:{description:"e.g. G-XXXXXXXXXX. Leave empty to load no analytics."},validate:a=>!!(!a||/^G-[A-Z0-9]{4,}$/.test(a))||"Format: G-XXXXXXXXXX"},{name:"gtmId",label:"Google Tag Manager container ID",type:"text",admin:{description:"e.g. GTM-XXXXXXX. Use either GA4 or GTM, usually not both."},validate:a=>!!(!a||/^GTM-[A-Z0-9]{4,}$/.test(a))||"Format: GTM-XXXXXXX"},{name:"searchConsoleVerification",label:"Google Search Console verification code",type:"text",admin:{description:"Only the content value of the google-site-verification meta tag."}},{name:"requireConsent",label:"Ask visitors for consent before loading analytics",type:"checkbox",defaultValue:!0}]}},10550:(a,b,c)=>{"use strict";c.d(b,{IB:()=>d,Zd:()=>g,ib:()=>f,q:()=>e});let d=["bn","en"],e="bn",f={bn:{label:"বাংলা",htmlLang:"bn",intl:"bn-BD",ogLocale:"bn_BD"},en:{label:"English",htmlLang:"en",intl:"en-BD",ogLocale:"en_US"}};function g(a){return"string"==typeof a&&d.includes(a)}},14654:(a,b,c)=>{"use strict";c.d(b,{_:()=>j});let d="phase-production-build"===process.env.NEXT_PHASE;function e(a,b){let c=process.env[a];if(c&&c.trim())return c.trim();if(d)return b??"";throw Error(`Missing required environment variable ${a}. See .env.example.`)}let f=a=>{let b=process.env[a];return b&&b.trim()?b.trim():void 0},g=(a,b)=>{let c=Number(process.env[a]);return Number.isFinite(c)&&c>0?c:b},h=(a,b=!1)=>{let c=process.env[a];return null==c||""===c?b:["1","true","yes"].includes(c.toLowerCase())},i=e("PAYLOAD_SECRET","dev-only-insecure-secret-change-me");if(!d&&i.length<32)throw Error("PAYLOAD_SECRET must be at least 32 characters in production.");let j={isProd:!0,DATABASE_URL:e("DATABASE_URL","postgres://mango:mango_dev_pw@127.0.0.1:5432/mango_shop"),DATABASE_POOL_MAX:g("DATABASE_POOL_MAX",10),DATABASE_PUSH:!1,PAYLOAD_SECRET:i,NEXT_PUBLIC_SERVER_URL:(f("NEXT_PUBLIC_SERVER_URL")||"http://localhost:3000").replace(/\/$/,""),MAX_UPLOAD_BYTES:g("MAX_UPLOAD_BYTES",8388608),S3_BUCKET:f("S3_BUCKET"),S3_REGION:f("S3_REGION"),S3_ENDPOINT:f("S3_ENDPOINT"),S3_PREFIX:f("S3_PREFIX"),S3_ACCESS_KEY_ID:f("S3_ACCESS_KEY_ID"),S3_SECRET_ACCESS_KEY:f("S3_SECRET_ACCESS_KEY"),S3_FORCE_PATH_STYLE:h("S3_FORCE_PATH_STYLE",!1),SMTP_HOST:f("SMTP_HOST"),SMTP_PORT:g("SMTP_PORT",587),SMTP_USER:f("SMTP_USER"),SMTP_PASS:f("SMTP_PASS"),EMAIL_FROM_ADDRESS:f("EMAIL_FROM_ADDRESS"),EMAIL_FROM_NAME:f("EMAIL_FROM_NAME"),ORDER_NOTIFICATION_EMAIL:f("ORDER_NOTIFICATION_EMAIL"),PAYMENTS_SANDBOX:h("PAYMENTS_SANDBOX",!0),SSLCOMMERZ_STORE_ID:f("SSLCOMMERZ_STORE_ID"),SSLCOMMERZ_STORE_PASSWORD:f("SSLCOMMERZ_STORE_PASSWORD"),BKASH_APP_KEY:f("BKASH_APP_KEY"),BKASH_APP_SECRET:f("BKASH_APP_SECRET"),BKASH_USERNAME:f("BKASH_USERNAME"),BKASH_PASSWORD:f("BKASH_PASSWORD"),BKASH_BASE_URL:f("BKASH_BASE_URL"),NAGAD_MERCHANT_ID:f("NAGAD_MERCHANT_ID"),NAGAD_MERCHANT_NUMBER:f("NAGAD_MERCHANT_NUMBER"),NAGAD_MERCHANT_PRIVATE_KEY:f("NAGAD_MERCHANT_PRIVATE_KEY"),NAGAD_PG_PUBLIC_KEY:f("NAGAD_PG_PUBLIC_KEY"),NAGAD_BASE_URL:f("NAGAD_BASE_URL")}},14898:(a,b,c)=>{"use strict";c.d(b,{C:()=>g});var d=c(61236),e=c(70667),f=c(29918);let g={slug:"customers",labels:{singular:"Customer",plural:"Customers"},admin:{group:"Sales",useAsTitle:"name",defaultColumns:["name","phone","email","orderCount","totalSpent","lastOrderAt"],listSearchableFields:["name","phone","email"]},defaultSort:"-lastOrderAt",access:{read:d.k3,create:d.k3,update:d.k3,delete:d.qc},fields:[{name:"name",type:"text",required:!0},{name:"phone",type:"text",required:!0,unique:!0,index:!0},{name:"email",type:"email"},{name:"lastAddress",type:"group",fields:[{name:"division",type:"text"},{name:"district",type:"select",options:f.dn},{name:"area",type:"text"},{name:"address",type:"textarea"}]},{name:"orderCount",type:"number",defaultValue:0,admin:{readOnly:!0}},(0,e.$)({name:"totalSpent",defaultValue:0,admin:{readOnly:!0,description:"Sum of order totals (excluding cancelled orders at the time of ordering)."}}),{name:"lastOrderAt",type:"date",admin:{readOnly:!0}},{name:"notes",type:"textarea",admin:{description:"Internal notes."}},{name:"orders",type:"join",collection:"orders",on:"customer"}]}},16043:(a,b,c)=>{"use strict";c.d(b,{I:()=>e,n:()=>g});var d=c(28964);function e(){return{name:"translationStatus",type:"select",defaultValue:"missing_en",options:[{label:"Complete (বাংলা + English)",value:"complete"},{label:"Missing English",value:"missing_en"},{label:"Missing বাংলা",value:"missing_bn"},{label:"Missing both",value:"missing_both"}],admin:{position:"sidebar",readOnly:!0,description:"Updated automatically on save. Switch the language at the top of the form to edit each translation."}}}function f(a){return null!=a&&("string"==typeof a?a.trim().length>0:"object"!=typeof a||JSON.stringify(a).replace(/[{}[\]",:\s]|"text"|"root"/g,"").length>20)}function g(a){return async({data:b,req:c,originalDoc:e,collection:g,operation:h})=>{let i=c.locale||"bn",j={};"update"===h&&e?.id&&(j=await (0,d.N)(c,()=>c.payload.findByID({collection:g.slug,id:e.id,locale:"all",depth:0,req:c,overrideAccess:!0})));let k=c=>a.every(a=>{if(c===i&&a in b)return f(b[a]);let d=j[a];return f(d?.[c])}),l=k("bn"),m=k("en");return b.translationStatus=l&&m?"complete":l?"missing_en":m?"missing_bn":"missing_both",b}}},17976:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{T:()=>g,up:()=>f});var e=c(5744);async function f({db:a,payload:b,req:c}){await a.execute((0,e.ll)`
   CREATE TYPE "public"."_locales" AS ENUM('bn', 'en');
  CREATE TYPE "public"."enum_products_variants_unit" AS ENUM('g', 'kg', 'ml', 'l', 'pcs', 'jar', 'box', 'pack');
  CREATE TYPE "public"."enum_products_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_products_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_categories_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_categories_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_stock_adjustments_reason" AS ENUM('restock', 'correction', 'damage', 'return', 'order', 'order_cancel');
  CREATE TYPE "public"."enum_orders_district" AS ENUM('barguna', 'barishal', 'bhola', 'jhalokati', 'patuakhali', 'pirojpur', 'bandarban', 'brahmanbaria', 'chandpur', 'chattogram', 'cumilla', 'coxsbazar', 'feni', 'khagrachhari', 'lakshmipur', 'noakhali', 'rangamati', 'dhaka', 'faridpur', 'gazipur', 'gopalganj', 'kishoreganj', 'madaripur', 'manikganj', 'munshiganj', 'narayanganj', 'narsingdi', 'rajbari', 'shariatpur', 'tangail', 'bagerhat', 'chuadanga', 'jashore', 'jhenaidah', 'khulna', 'kushtia', 'magura', 'meherpur', 'narail', 'satkhira', 'jamalpur', 'mymensingh', 'netrokona', 'sherpur', 'bogura', 'chapainawabganj', 'joypurhat', 'naogaon', 'natore', 'pabna', 'rajshahi', 'sirajganj', 'dinajpur', 'gaibandha', 'kurigram', 'lalmonirhat', 'nilphamari', 'panchagarh', 'rangpur', 'thakurgaon', 'habiganj', 'moulvibazar', 'sunamganj', 'sylhet');
  CREATE TYPE "public"."enum_orders_status" AS ENUM('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled');
  CREATE TYPE "public"."enum_orders_payment_status" AS ENUM('unpaid', 'pending', 'paid', 'failed', 'refunded', 'cancelled');
  CREATE TYPE "public"."enum_orders_payment_method" AS ENUM('cod', 'sslcommerz', 'bkash', 'nagad');
  CREATE TYPE "public"."enum_orders_locale" AS ENUM('bn', 'en');
  CREATE TYPE "public"."enum_payments_provider" AS ENUM('cod', 'sslcommerz', 'bkash', 'nagad');
  CREATE TYPE "public"."enum_payments_status" AS ENUM('initiated', 'succeeded', 'failed', 'cancelled');
  CREATE TYPE "public"."enum_customers_last_address_district" AS ENUM('barguna', 'barishal', 'bhola', 'jhalokati', 'patuakhali', 'pirojpur', 'bandarban', 'brahmanbaria', 'chandpur', 'chattogram', 'cumilla', 'coxsbazar', 'feni', 'khagrachhari', 'lakshmipur', 'noakhali', 'rangamati', 'dhaka', 'faridpur', 'gazipur', 'gopalganj', 'kishoreganj', 'madaripur', 'manikganj', 'munshiganj', 'narayanganj', 'narsingdi', 'rajbari', 'shariatpur', 'tangail', 'bagerhat', 'chuadanga', 'jashore', 'jhenaidah', 'khulna', 'kushtia', 'magura', 'meherpur', 'narail', 'satkhira', 'jamalpur', 'mymensingh', 'netrokona', 'sherpur', 'bogura', 'chapainawabganj', 'joypurhat', 'naogaon', 'natore', 'pabna', 'rajshahi', 'sirajganj', 'dinajpur', 'gaibandha', 'kurigram', 'lalmonirhat', 'nilphamari', 'panchagarh', 'rangpur', 'thakurgaon', 'habiganj', 'moulvibazar', 'sunamganj', 'sylhet');
  CREATE TYPE "public"."enum_coupons_type" AS ENUM('percent', 'fixed');
  CREATE TYPE "public"."enum_faqs_topic" AS ENUM('orders', 'delivery', 'packaging', 'payment', 'availability', 'returns');
  CREATE TYPE "public"."enum_faqs_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_faqs_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_testimonials_moderation" AS ENUM('pending', 'approved', 'rejected');
  CREATE TYPE "public"."enum_posts_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_posts_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_pages_kind" AS ENUM('info', 'policy');
  CREATE TYPE "public"."enum_pages_status" AS ENUM('published', 'draft');
  CREATE TYPE "public"."enum_pages_translation_status" AS ENUM('complete', 'missing_en', 'missing_bn', 'missing_both');
  CREATE TYPE "public"."enum_redirects_type" AS ENUM('product', 'category', 'post', 'page');
  CREATE TYPE "public"."enum_users_roles" AS ENUM('admin', 'manager', 'editor');
  CREATE TYPE "public"."enum_homepage_benefits_icon" AS ENUM('leaf', 'package', 'truck', 'wallet', 'shield', 'phone', 'clock', 'heart');
  CREATE TYPE "public"."enum_homepage_announcement_tone" AS ENUM('green', 'mango', 'cream');
  CREATE TYPE "public"."enum_branding_socials_platform" AS ENUM('facebook', 'instagram', 'youtube', 'tiktok', 'linkedin', 'x');
  CREATE TYPE "public"."enum_contact_settings_show_on" AS ENUM('home', 'shop', 'category', 'product', 'cart', 'checkout', 'blog', 'pages', 'order');
  CREATE TYPE "public"."enum_contact_settings_position" AS ENUM('right', 'left');
  CREATE TYPE "public"."enum_delivery_settings_zones_districts" AS ENUM('barguna', 'barishal', 'bhola', 'jhalokati', 'patuakhali', 'pirojpur', 'bandarban', 'brahmanbaria', 'chandpur', 'chattogram', 'cumilla', 'coxsbazar', 'feni', 'khagrachhari', 'lakshmipur', 'noakhali', 'rangamati', 'dhaka', 'faridpur', 'gazipur', 'gopalganj', 'kishoreganj', 'madaripur', 'manikganj', 'munshiganj', 'narayanganj', 'narsingdi', 'rajbari', 'shariatpur', 'tangail', 'bagerhat', 'chuadanga', 'jashore', 'jhenaidah', 'khulna', 'kushtia', 'magura', 'meherpur', 'narail', 'satkhira', 'jamalpur', 'mymensingh', 'netrokona', 'sherpur', 'bogura', 'chapainawabganj', 'joypurhat', 'naogaon', 'natore', 'pabna', 'rajshahi', 'sirajganj', 'dinajpur', 'gaibandha', 'kurigram', 'lalmonirhat', 'nilphamari', 'panchagarh', 'rangpur', 'thakurgaon', 'habiganj', 'moulvibazar', 'sunamganj', 'sylhet');
  CREATE TABLE "products_attributes" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "products_attributes_locales" (
  	"label" varchar NOT NULL,
  	"value" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "products_variants" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"sku" varchar NOT NULL,
  	"pack_size" numeric,
  	"unit" "enum_products_variants_unit" DEFAULT 'kg',
  	"price" numeric NOT NULL,
  	"sale_price" numeric,
  	"sale_starts_at" timestamp(3) with time zone,
  	"sale_ends_at" timestamp(3) with time zone,
  	"stock" numeric DEFAULT 0,
  	"low_stock_threshold" numeric DEFAULT 5,
  	"weight_grams" numeric
  );
  
  CREATE TABLE "products_variants_locales" (
  	"label" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "products" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"status" "enum_products_status" DEFAULT 'draft' NOT NULL,
  	"featured" boolean DEFAULT false,
  	"best_seller" boolean DEFAULT false,
  	"is_bundle" boolean DEFAULT false,
  	"sort_order" numeric DEFAULT 0,
  	"translation_status" "enum_products_translation_status" DEFAULT 'missing_en',
  	"min_price" numeric,
  	"total_stock" numeric DEFAULT 0,
  	"search_text" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "products_locales" (
  	"name" varchar NOT NULL,
  	"short_description" varchar,
  	"description" jsonb,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "products_texts" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer NOT NULL,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"text" varchar
  );
  
  CREATE TABLE "products_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"media_id" integer,
  	"categories_id" integer,
  	"products_id" integer
  );
  
  CREATE TABLE "categories" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"image_id" integer,
  	"banner_id" integer,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"status" "enum_categories_status" DEFAULT 'published' NOT NULL,
  	"parent_id" integer,
  	"featured" boolean DEFAULT false,
  	"sort_order" numeric DEFAULT 0,
  	"translation_status" "enum_categories_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "categories_locales" (
  	"name" varchar NOT NULL,
  	"description" varchar,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "stock_adjustments" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"sku" varchar NOT NULL,
  	"delta" numeric NOT NULL,
  	"reason" "enum_stock_adjustments_reason" DEFAULT 'restock' NOT NULL,
  	"note" varchar,
  	"product_id" integer,
  	"variant_id" varchar,
  	"order_id" integer,
  	"stock_before" numeric,
  	"stock_after" numeric,
  	"created_by" varchar,
  	"system_generated" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "orders_items" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"product_id" integer,
  	"product_name" varchar NOT NULL,
  	"product_name_en" varchar,
  	"variant_id" varchar,
  	"variant_label" varchar,
  	"sku" varchar,
  	"unit_price" numeric NOT NULL,
  	"regular_price" numeric,
  	"quantity" numeric NOT NULL,
  	"line_total" numeric NOT NULL
  );
  
  CREATE TABLE "orders_status_history" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"status" varchar,
  	"payment_status" varchar,
  	"at" timestamp(3) with time zone,
  	"by" varchar,
  	"note" varchar
  );
  
  CREATE TABLE "orders" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"subtotal" numeric NOT NULL,
  	"discount" numeric DEFAULT 0,
  	"shipping_fee" numeric DEFAULT 0,
  	"total" numeric NOT NULL,
  	"coupon_code" varchar,
  	"delivery_method" varchar,
  	"delivery_zone" varchar,
  	"customer_name" varchar NOT NULL,
  	"customer_phone" varchar NOT NULL,
  	"customer_email" varchar,
  	"division" varchar,
  	"district" "enum_orders_district",
  	"area" varchar,
  	"address" varchar NOT NULL,
  	"customer_notes" varchar,
  	"customer_id" integer,
  	"order_number" varchar NOT NULL,
  	"status" "enum_orders_status" DEFAULT 'pending' NOT NULL,
  	"payment_status" "enum_orders_payment_status" DEFAULT 'unpaid' NOT NULL,
  	"payment_method" "enum_orders_payment_method" NOT NULL,
  	"status_note" varchar,
  	"admin_notes" varchar,
  	"locale" "enum_orders_locale" DEFAULT 'bn',
  	"idempotency_key" varchar,
  	"stock_restored" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "payments" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order_id" integer NOT NULL,
  	"reference" varchar NOT NULL,
  	"provider" "enum_payments_provider" NOT NULL,
  	"amount" numeric NOT NULL,
  	"currency" varchar DEFAULT 'BDT',
  	"status" "enum_payments_status" DEFAULT 'initiated' NOT NULL,
  	"transaction_id" varchar,
  	"gateway_payment_id" varchar,
  	"verified_at" timestamp(3) with time zone,
  	"failure_reason" varchar,
  	"gateway_response" jsonb,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "customers" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"name" varchar NOT NULL,
  	"phone" varchar NOT NULL,
  	"email" varchar,
  	"last_address_division" varchar,
  	"last_address_district" "enum_customers_last_address_district",
  	"last_address_area" varchar,
  	"last_address_address" varchar,
  	"order_count" numeric DEFAULT 0,
  	"total_spent" numeric DEFAULT 0,
  	"last_order_at" timestamp(3) with time zone,
  	"notes" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "coupons" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"code" varchar NOT NULL,
  	"description" varchar,
  	"active" boolean DEFAULT true,
  	"type" "enum_coupons_type" DEFAULT 'percent' NOT NULL,
  	"percent" numeric,
  	"amount" numeric,
  	"min_subtotal" numeric,
  	"max_discount" numeric,
  	"starts_at" timestamp(3) with time zone,
  	"ends_at" timestamp(3) with time zone,
  	"usage_limit" numeric,
  	"used_count" numeric DEFAULT 0,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "media" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"credit" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"url" varchar,
  	"thumbnail_u_r_l" varchar,
  	"filename" varchar,
  	"mime_type" varchar,
  	"filesize" numeric,
  	"width" numeric,
  	"height" numeric,
  	"focal_x" numeric,
  	"focal_y" numeric,
  	"sizes_thumbnail_url" varchar,
  	"sizes_thumbnail_width" numeric,
  	"sizes_thumbnail_height" numeric,
  	"sizes_thumbnail_mime_type" varchar,
  	"sizes_thumbnail_filesize" numeric,
  	"sizes_thumbnail_filename" varchar,
  	"sizes_card_url" varchar,
  	"sizes_card_width" numeric,
  	"sizes_card_height" numeric,
  	"sizes_card_mime_type" varchar,
  	"sizes_card_filesize" numeric,
  	"sizes_card_filename" varchar,
  	"sizes_large_url" varchar,
  	"sizes_large_width" numeric,
  	"sizes_large_height" numeric,
  	"sizes_large_mime_type" varchar,
  	"sizes_large_filesize" numeric,
  	"sizes_large_filename" varchar,
  	"sizes_og_url" varchar,
  	"sizes_og_width" numeric,
  	"sizes_og_height" numeric,
  	"sizes_og_mime_type" varchar,
  	"sizes_og_filesize" numeric,
  	"sizes_og_filename" varchar
  );
  
  CREATE TABLE "media_locales" (
  	"alt" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "faqs" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"topic" "enum_faqs_topic" DEFAULT 'orders',
  	"show_on_home" boolean DEFAULT true,
  	"sort_order" numeric DEFAULT 0,
  	"status" "enum_faqs_status" DEFAULT 'published' NOT NULL,
  	"translation_status" "enum_faqs_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "faqs_locales" (
  	"question" varchar NOT NULL,
  	"answer" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "testimonials" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"customer_name" varchar NOT NULL,
  	"rating" numeric,
  	"product_id" integer,
  	"order_id" integer,
  	"moderation" "enum_testimonials_moderation" DEFAULT 'pending' NOT NULL,
  	"consent_to_publish" boolean DEFAULT false,
  	"source" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "testimonials_locales" (
  	"location" varchar,
  	"quote" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "posts" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"cover_image_id" integer,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"status" "enum_posts_status" DEFAULT 'draft' NOT NULL,
  	"published_at" timestamp(3) with time zone,
  	"author" varchar,
  	"translation_status" "enum_posts_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "posts_locales" (
  	"title" varchar NOT NULL,
  	"excerpt" varchar,
  	"content" jsonb,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "posts_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"products_id" integer
  );
  
  CREATE TABLE "pages" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"slug" varchar NOT NULL,
  	"kind" "enum_pages_kind" DEFAULT 'info',
  	"status" "enum_pages_status" DEFAULT 'published' NOT NULL,
  	"translation_status" "enum_pages_translation_status" DEFAULT 'missing_en',
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "pages_locales" (
  	"title" varchar NOT NULL,
  	"intro" varchar,
  	"content" jsonb,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "redirects" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"type" "enum_redirects_type" NOT NULL,
  	"from_slug" varchar NOT NULL,
  	"to_slug" varchar NOT NULL,
  	"automatic" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "users_roles" (
  	"order" integer NOT NULL,
  	"parent_id" integer NOT NULL,
  	"value" "enum_users_roles",
  	"id" serial PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "users_sessions" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"created_at" timestamp(3) with time zone,
  	"expires_at" timestamp(3) with time zone NOT NULL
  );
  
  CREATE TABLE "users" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"name" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"email" varchar NOT NULL,
  	"reset_password_token" varchar,
  	"reset_password_expiration" timestamp(3) with time zone,
  	"salt" varchar,
  	"hash" varchar,
  	"reset_password_requested_at" timestamp(3) with time zone,
  	"login_attempts" numeric DEFAULT 0,
  	"lock_until" timestamp(3) with time zone
  );
  
  CREATE TABLE "payload_kv" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"key" varchar NOT NULL,
  	"data" jsonb NOT NULL
  );
  
  CREATE TABLE "payload_locked_documents" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"global_slug" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "payload_locked_documents_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"products_id" integer,
  	"categories_id" integer,
  	"stock_adjustments_id" integer,
  	"orders_id" integer,
  	"payments_id" integer,
  	"customers_id" integer,
  	"coupons_id" integer,
  	"media_id" integer,
  	"faqs_id" integer,
  	"testimonials_id" integer,
  	"posts_id" integer,
  	"pages_id" integer,
  	"redirects_id" integer,
  	"users_id" integer
  );
  
  CREATE TABLE "payload_preferences" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"key" varchar,
  	"value" jsonb,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "payload_preferences_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"users_id" integer
  );
  
  CREATE TABLE "payload_migrations" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"name" varchar,
  	"batch" numeric,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "homepage_benefits" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"icon" "enum_homepage_benefits_icon" DEFAULT 'leaf'
  );
  
  CREATE TABLE "homepage_benefits_locales" (
  	"title" varchar NOT NULL,
  	"text" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "homepage" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"announcement_enabled" boolean DEFAULT true,
  	"announcement_href" varchar,
  	"announcement_tone" "enum_homepage_announcement_tone" DEFAULT 'green',
  	"hero_image_id" integer,
  	"hero_primary_cta_href" varchar,
  	"hero_secondary_cta_href" varchar,
  	"hero_seasonal_badge_enabled" boolean DEFAULT true,
  	"categories_section_enabled" boolean DEFAULT true,
  	"featured_enabled" boolean DEFAULT true,
  	"featured_category_id" integer,
  	"featured_limit" numeric DEFAULT 8,
  	"featured_cta_href" varchar,
  	"traditional_enabled" boolean DEFAULT true,
  	"traditional_per_category" numeric DEFAULT 4,
  	"popular_enabled" boolean DEFAULT true,
  	"promo_enabled" boolean DEFAULT true,
  	"promo_image_id" integer,
  	"promo_cta_href" varchar,
  	"story_enabled" boolean DEFAULT true,
  	"story_image_id" integer,
  	"story_cta_href" varchar,
  	"testimonials_enabled" boolean DEFAULT true,
  	"faq_enabled" boolean DEFAULT true,
  	"seo_og_image_id" integer,
  	"seo_canonical_url" varchar,
  	"seo_noindex" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "homepage_locales" (
  	"announcement_text" varchar,
  	"hero_headline" varchar NOT NULL,
  	"hero_subheadline" varchar,
  	"hero_primary_cta_label" varchar,
  	"hero_secondary_cta_label" varchar,
  	"hero_seasonal_badge_text" varchar,
  	"categories_section_heading" varchar,
  	"featured_heading" varchar,
  	"featured_intro" varchar,
  	"featured_cta_label" varchar,
  	"traditional_heading" varchar,
  	"traditional_intro" varchar,
  	"popular_heading" varchar,
  	"promo_heading" varchar,
  	"promo_text" varchar,
  	"promo_cta_label" varchar,
  	"story_heading" varchar,
  	"story_body" varchar,
  	"story_cta_label" varchar,
  	"testimonials_heading" varchar,
  	"faq_heading" varchar,
  	"seo_title" varchar,
  	"seo_description" varchar,
  	"seo_focus_keyword" varchar,
  	"seo_og_title" varchar,
  	"seo_og_description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "homepage_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" integer NOT NULL,
  	"path" varchar NOT NULL,
  	"categories_id" integer,
  	"products_id" integer
  );
  
  CREATE TABLE "branding_socials" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"platform" "enum_branding_socials_platform" NOT NULL,
  	"url" varchar NOT NULL
  );
  
  CREATE TABLE "branding" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"logo_id" integer,
  	"logo_mobile_id" integer,
  	"logo_footer_id" integer,
  	"favicon_id" integer,
  	"colors_primary" varchar DEFAULT '#245B32',
  	"colors_secondary" varchar DEFAULT '#477B3B',
  	"colors_accent" varchar DEFAULT '#FFC928',
  	"colors_accent_warm" varchar DEFAULT '#F59A23',
  	"colors_background" varchar DEFAULT '#FFF9ED',
  	"colors_text" varchar DEFAULT '#243126',
  	"default_share_image_id" integer,
  	"phone" varchar,
  	"email" varchar,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "branding_locales" (
  	"brand_name" varchar DEFAULT 'আম্রকুঞ্জ' NOT NULL,
  	"tagline" varchar,
  	"site_title" varchar NOT NULL,
  	"default_seo_title" varchar,
  	"default_seo_description" varchar,
  	"address" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "contact_settings_show_on" (
  	"order" integer NOT NULL,
  	"parent_id" integer NOT NULL,
  	"value" "enum_contact_settings_show_on",
  	"id" serial PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "contact_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"whatsapp_enabled" boolean DEFAULT true,
  	"whatsapp_number" varchar,
  	"message_bn" varchar DEFAULT 'আসসালামু আলাইকুম! আমি আপনাদের পণ্য সম্পর্কে জানতে চাই।',
  	"message_en" varchar DEFAULT 'Hello! I''d like to know more about your products.',
  	"position" "enum_contact_settings_position" DEFAULT 'right',
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "contact_settings_locales" (
  	"tooltip" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "navigation_header_links" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"href" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_header_links_locales" (
  	"label" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns_links" (
  	"_order" integer NOT NULL,
  	"_parent_id" varchar NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"href" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns_links_locales" (
  	"label" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "navigation_footer_columns_locales" (
  	"title" varchar NOT NULL,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "navigation" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "navigation_locales" (
  	"footer_description" varchar,
  	"payment_note" varchar,
  	"copyright" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "delivery_settings_zones_districts" (
  	"order" integer NOT NULL,
  	"parent_id" varchar NOT NULL,
  	"value" "enum_delivery_settings_zones_districts",
  	"id" serial PRIMARY KEY NOT NULL
  );
  
  CREATE TABLE "delivery_settings_zones" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"code" varchar NOT NULL,
  	"enabled" boolean DEFAULT true,
  	"is_default" boolean DEFAULT false,
  	"fee" numeric NOT NULL,
  	"free_over" numeric
  );
  
  CREATE TABLE "delivery_settings_zones_locales" (
  	"name" varchar NOT NULL,
  	"estimate" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "delivery_settings_methods" (
  	"_order" integer NOT NULL,
  	"_parent_id" integer NOT NULL,
  	"id" varchar PRIMARY KEY NOT NULL,
  	"code" varchar NOT NULL,
  	"surcharge" numeric DEFAULT 0,
  	"enabled" boolean DEFAULT true
  );
  
  CREATE TABLE "delivery_settings_methods_locales" (
  	"name" varchar NOT NULL,
  	"description" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" varchar NOT NULL
  );
  
  CREATE TABLE "delivery_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "delivery_settings_locales" (
  	"product_page_note" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "payment_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"cod_enabled" boolean DEFAULT true,
  	"cod_max_total" numeric,
  	"sslcommerz_enabled" boolean DEFAULT false,
  	"bkash_enabled" boolean DEFAULT false,
  	"nagad_enabled" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  CREATE TABLE "payment_settings_locales" (
  	"checkout_note" varchar,
  	"id" serial PRIMARY KEY NOT NULL,
  	"_locale" "_locales" NOT NULL,
  	"_parent_id" integer NOT NULL
  );
  
  CREATE TABLE "analytics_settings" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"ga4_id" varchar,
  	"gtm_id" varchar,
  	"search_console_verification" varchar,
  	"require_consent" boolean DEFAULT true,
  	"updated_at" timestamp(3) with time zone,
  	"created_at" timestamp(3) with time zone
  );
  
  ALTER TABLE "products_attributes" ADD CONSTRAINT "products_attributes_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_attributes_locales" ADD CONSTRAINT "products_attributes_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products_attributes"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_variants" ADD CONSTRAINT "products_variants_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_variants_locales" ADD CONSTRAINT "products_variants_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products_variants"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products" ADD CONSTRAINT "products_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "products_locales" ADD CONSTRAINT "products_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_texts" ADD CONSTRAINT "products_texts_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_media_fk" FOREIGN KEY ("media_id") REFERENCES "public"."media"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_categories_fk" FOREIGN KEY ("categories_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "products_rels" ADD CONSTRAINT "products_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_image_id_media_id_fk" FOREIGN KEY ("image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_banner_id_media_id_fk" FOREIGN KEY ("banner_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories" ADD CONSTRAINT "categories_parent_id_categories_id_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."categories"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "categories_locales" ADD CONSTRAINT "categories_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "orders_items" ADD CONSTRAINT "orders_items_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "orders_items" ADD CONSTRAINT "orders_items_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "orders_status_history" ADD CONSTRAINT "orders_status_history_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "orders" ADD CONSTRAINT "orders_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "payments" ADD CONSTRAINT "payments_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "media_locales" ADD CONSTRAINT "media_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."media"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "faqs_locales" ADD CONSTRAINT "faqs_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."faqs"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "testimonials" ADD CONSTRAINT "testimonials_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "testimonials" ADD CONSTRAINT "testimonials_order_id_orders_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "testimonials_locales" ADD CONSTRAINT "testimonials_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."testimonials"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "posts" ADD CONSTRAINT "posts_cover_image_id_media_id_fk" FOREIGN KEY ("cover_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "posts" ADD CONSTRAINT "posts_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "posts_locales" ADD CONSTRAINT "posts_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "posts_rels" ADD CONSTRAINT "posts_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "posts_rels" ADD CONSTRAINT "posts_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "pages" ADD CONSTRAINT "pages_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "pages_locales" ADD CONSTRAINT "pages_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."pages"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "users_roles" ADD CONSTRAINT "users_roles_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "users_sessions" ADD CONSTRAINT "users_sessions_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."payload_locked_documents"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_categories_fk" FOREIGN KEY ("categories_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_stock_adjustments_fk" FOREIGN KEY ("stock_adjustments_id") REFERENCES "public"."stock_adjustments"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_orders_fk" FOREIGN KEY ("orders_id") REFERENCES "public"."orders"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_payments_fk" FOREIGN KEY ("payments_id") REFERENCES "public"."payments"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_customers_fk" FOREIGN KEY ("customers_id") REFERENCES "public"."customers"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_coupons_fk" FOREIGN KEY ("coupons_id") REFERENCES "public"."coupons"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_media_fk" FOREIGN KEY ("media_id") REFERENCES "public"."media"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_faqs_fk" FOREIGN KEY ("faqs_id") REFERENCES "public"."faqs"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_testimonials_fk" FOREIGN KEY ("testimonials_id") REFERENCES "public"."testimonials"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_posts_fk" FOREIGN KEY ("posts_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_pages_fk" FOREIGN KEY ("pages_id") REFERENCES "public"."pages"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_redirects_fk" FOREIGN KEY ("redirects_id") REFERENCES "public"."redirects"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_preferences_rels" ADD CONSTRAINT "payload_preferences_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."payload_preferences"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_preferences_rels" ADD CONSTRAINT "payload_preferences_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_benefits" ADD CONSTRAINT "homepage_benefits_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."homepage"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_benefits_locales" ADD CONSTRAINT "homepage_benefits_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."homepage_benefits"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_hero_image_id_media_id_fk" FOREIGN KEY ("hero_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_featured_category_id_categories_id_fk" FOREIGN KEY ("featured_category_id") REFERENCES "public"."categories"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_promo_image_id_media_id_fk" FOREIGN KEY ("promo_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_story_image_id_media_id_fk" FOREIGN KEY ("story_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage" ADD CONSTRAINT "homepage_seo_og_image_id_media_id_fk" FOREIGN KEY ("seo_og_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "homepage_locales" ADD CONSTRAINT "homepage_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."homepage"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_rels" ADD CONSTRAINT "homepage_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."homepage"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_rels" ADD CONSTRAINT "homepage_rels_categories_fk" FOREIGN KEY ("categories_id") REFERENCES "public"."categories"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "homepage_rels" ADD CONSTRAINT "homepage_rels_products_fk" FOREIGN KEY ("products_id") REFERENCES "public"."products"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "branding_socials" ADD CONSTRAINT "branding_socials_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."branding"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_logo_id_media_id_fk" FOREIGN KEY ("logo_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_logo_mobile_id_media_id_fk" FOREIGN KEY ("logo_mobile_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_logo_footer_id_media_id_fk" FOREIGN KEY ("logo_footer_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_favicon_id_media_id_fk" FOREIGN KEY ("favicon_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding" ADD CONSTRAINT "branding_default_share_image_id_media_id_fk" FOREIGN KEY ("default_share_image_id") REFERENCES "public"."media"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "branding_locales" ADD CONSTRAINT "branding_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."branding"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "contact_settings_show_on" ADD CONSTRAINT "contact_settings_show_on_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."contact_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "contact_settings_locales" ADD CONSTRAINT "contact_settings_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."contact_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_header_links" ADD CONSTRAINT "navigation_header_links_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_header_links_locales" ADD CONSTRAINT "navigation_header_links_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_header_links"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns_links" ADD CONSTRAINT "navigation_footer_columns_links_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_footer_columns"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns_links_locales" ADD CONSTRAINT "navigation_footer_columns_links_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_footer_columns_links"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns" ADD CONSTRAINT "navigation_footer_columns_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_footer_columns_locales" ADD CONSTRAINT "navigation_footer_columns_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation_footer_columns"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "navigation_locales" ADD CONSTRAINT "navigation_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."navigation"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_zones_districts" ADD CONSTRAINT "delivery_settings_zones_districts_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."delivery_settings_zones"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_zones" ADD CONSTRAINT "delivery_settings_zones_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_zones_locales" ADD CONSTRAINT "delivery_settings_zones_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings_zones"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_methods" ADD CONSTRAINT "delivery_settings_methods_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_methods_locales" ADD CONSTRAINT "delivery_settings_methods_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings_methods"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "delivery_settings_locales" ADD CONSTRAINT "delivery_settings_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."delivery_settings"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payment_settings_locales" ADD CONSTRAINT "payment_settings_locales_parent_id_fk" FOREIGN KEY ("_parent_id") REFERENCES "public"."payment_settings"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "products_attributes_order_idx" ON "products_attributes" USING btree ("_order");
  CREATE INDEX "products_attributes_parent_id_idx" ON "products_attributes" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "products_attributes_locales_locale_parent_id_unique" ON "products_attributes_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "products_attributes_locales_parent_id_idx" ON "products_attributes_locales" USING btree ("_parent_id");
  CREATE INDEX "products_variants_order_idx" ON "products_variants" USING btree ("_order");
  CREATE INDEX "products_variants_parent_id_idx" ON "products_variants" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "products_variants_locales_locale_parent_id_unique" ON "products_variants_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "products_variants_locales_parent_id_idx" ON "products_variants_locales" USING btree ("_parent_id");
  CREATE INDEX "products_seo_seo_og_image_idx" ON "products" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "products_slug_idx" ON "products" USING btree ("slug");
  CREATE INDEX "products_status_idx" ON "products" USING btree ("status");
  CREATE INDEX "products_total_stock_idx" ON "products" USING btree ("total_stock");
  CREATE INDEX "products_search_text_idx" ON "products" USING btree ("search_text");
  CREATE INDEX "products_updated_at_idx" ON "products" USING btree ("updated_at");
  CREATE INDEX "products_created_at_idx" ON "products" USING btree ("created_at");
  CREATE UNIQUE INDEX "products_locales_locale_parent_id_unique" ON "products_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "products_locales_parent_id_idx" ON "products_locales" USING btree ("_parent_id");
  CREATE INDEX "products_texts_order_parent" ON "products_texts" USING btree ("order","parent_id");
  CREATE INDEX "products_rels_order_idx" ON "products_rels" USING btree ("order");
  CREATE INDEX "products_rels_parent_idx" ON "products_rels" USING btree ("parent_id");
  CREATE INDEX "products_rels_path_idx" ON "products_rels" USING btree ("path");
  CREATE INDEX "products_rels_media_id_idx" ON "products_rels" USING btree ("media_id");
  CREATE INDEX "products_rels_categories_id_idx" ON "products_rels" USING btree ("categories_id");
  CREATE INDEX "products_rels_products_id_idx" ON "products_rels" USING btree ("products_id");
  CREATE INDEX "categories_image_idx" ON "categories" USING btree ("image_id");
  CREATE INDEX "categories_banner_idx" ON "categories" USING btree ("banner_id");
  CREATE INDEX "categories_seo_seo_og_image_idx" ON "categories" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "categories_slug_idx" ON "categories" USING btree ("slug");
  CREATE INDEX "categories_parent_idx" ON "categories" USING btree ("parent_id");
  CREATE INDEX "categories_updated_at_idx" ON "categories" USING btree ("updated_at");
  CREATE INDEX "categories_created_at_idx" ON "categories" USING btree ("created_at");
  CREATE UNIQUE INDEX "categories_locales_locale_parent_id_unique" ON "categories_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "categories_locales_parent_id_idx" ON "categories_locales" USING btree ("_parent_id");
  CREATE INDEX "stock_adjustments_sku_idx" ON "stock_adjustments" USING btree ("sku");
  CREATE INDEX "stock_adjustments_product_idx" ON "stock_adjustments" USING btree ("product_id");
  CREATE INDEX "stock_adjustments_order_idx" ON "stock_adjustments" USING btree ("order_id");
  CREATE INDEX "stock_adjustments_updated_at_idx" ON "stock_adjustments" USING btree ("updated_at");
  CREATE INDEX "stock_adjustments_created_at_idx" ON "stock_adjustments" USING btree ("created_at");
  CREATE INDEX "orders_items_order_idx" ON "orders_items" USING btree ("_order");
  CREATE INDEX "orders_items_parent_id_idx" ON "orders_items" USING btree ("_parent_id");
  CREATE INDEX "orders_items_product_idx" ON "orders_items" USING btree ("product_id");
  CREATE INDEX "orders_status_history_order_idx" ON "orders_status_history" USING btree ("_order");
  CREATE INDEX "orders_status_history_parent_id_idx" ON "orders_status_history" USING btree ("_parent_id");
  CREATE INDEX "orders_customer_phone_idx" ON "orders" USING btree ("customer_phone");
  CREATE INDEX "orders_customer_idx" ON "orders" USING btree ("customer_id");
  CREATE UNIQUE INDEX "orders_order_number_idx" ON "orders" USING btree ("order_number");
  CREATE INDEX "orders_status_idx" ON "orders" USING btree ("status");
  CREATE INDEX "orders_payment_status_idx" ON "orders" USING btree ("payment_status");
  CREATE UNIQUE INDEX "orders_idempotency_key_idx" ON "orders" USING btree ("idempotency_key");
  CREATE INDEX "orders_updated_at_idx" ON "orders" USING btree ("updated_at");
  CREATE INDEX "orders_created_at_idx" ON "orders" USING btree ("created_at");
  CREATE INDEX "payments_order_idx" ON "payments" USING btree ("order_id");
  CREATE UNIQUE INDEX "payments_reference_idx" ON "payments" USING btree ("reference");
  CREATE INDEX "payments_transaction_id_idx" ON "payments" USING btree ("transaction_id");
  CREATE INDEX "payments_gateway_payment_id_idx" ON "payments" USING btree ("gateway_payment_id");
  CREATE INDEX "payments_updated_at_idx" ON "payments" USING btree ("updated_at");
  CREATE INDEX "payments_created_at_idx" ON "payments" USING btree ("created_at");
  CREATE UNIQUE INDEX "customers_phone_idx" ON "customers" USING btree ("phone");
  CREATE INDEX "customers_updated_at_idx" ON "customers" USING btree ("updated_at");
  CREATE INDEX "customers_created_at_idx" ON "customers" USING btree ("created_at");
  CREATE UNIQUE INDEX "coupons_code_idx" ON "coupons" USING btree ("code");
  CREATE INDEX "coupons_updated_at_idx" ON "coupons" USING btree ("updated_at");
  CREATE INDEX "coupons_created_at_idx" ON "coupons" USING btree ("created_at");
  CREATE INDEX "media_updated_at_idx" ON "media" USING btree ("updated_at");
  CREATE INDEX "media_created_at_idx" ON "media" USING btree ("created_at");
  CREATE UNIQUE INDEX "media_filename_idx" ON "media" USING btree ("filename");
  CREATE INDEX "media_sizes_thumbnail_sizes_thumbnail_filename_idx" ON "media" USING btree ("sizes_thumbnail_filename");
  CREATE INDEX "media_sizes_card_sizes_card_filename_idx" ON "media" USING btree ("sizes_card_filename");
  CREATE INDEX "media_sizes_large_sizes_large_filename_idx" ON "media" USING btree ("sizes_large_filename");
  CREATE INDEX "media_sizes_og_sizes_og_filename_idx" ON "media" USING btree ("sizes_og_filename");
  CREATE UNIQUE INDEX "media_locales_locale_parent_id_unique" ON "media_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "media_locales_parent_id_idx" ON "media_locales" USING btree ("_parent_id");
  CREATE INDEX "faqs_status_idx" ON "faqs" USING btree ("status");
  CREATE INDEX "faqs_updated_at_idx" ON "faqs" USING btree ("updated_at");
  CREATE INDEX "faqs_created_at_idx" ON "faqs" USING btree ("created_at");
  CREATE UNIQUE INDEX "faqs_locales_locale_parent_id_unique" ON "faqs_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "faqs_locales_parent_id_idx" ON "faqs_locales" USING btree ("_parent_id");
  CREATE INDEX "testimonials_product_idx" ON "testimonials" USING btree ("product_id");
  CREATE INDEX "testimonials_order_idx" ON "testimonials" USING btree ("order_id");
  CREATE INDEX "testimonials_updated_at_idx" ON "testimonials" USING btree ("updated_at");
  CREATE INDEX "testimonials_created_at_idx" ON "testimonials" USING btree ("created_at");
  CREATE UNIQUE INDEX "testimonials_locales_locale_parent_id_unique" ON "testimonials_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "testimonials_locales_parent_id_idx" ON "testimonials_locales" USING btree ("_parent_id");
  CREATE INDEX "posts_cover_image_idx" ON "posts" USING btree ("cover_image_id");
  CREATE INDEX "posts_seo_seo_og_image_idx" ON "posts" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "posts_slug_idx" ON "posts" USING btree ("slug");
  CREATE INDEX "posts_status_idx" ON "posts" USING btree ("status");
  CREATE INDEX "posts_updated_at_idx" ON "posts" USING btree ("updated_at");
  CREATE INDEX "posts_created_at_idx" ON "posts" USING btree ("created_at");
  CREATE UNIQUE INDEX "posts_locales_locale_parent_id_unique" ON "posts_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "posts_locales_parent_id_idx" ON "posts_locales" USING btree ("_parent_id");
  CREATE INDEX "posts_rels_order_idx" ON "posts_rels" USING btree ("order");
  CREATE INDEX "posts_rels_parent_idx" ON "posts_rels" USING btree ("parent_id");
  CREATE INDEX "posts_rels_path_idx" ON "posts_rels" USING btree ("path");
  CREATE INDEX "posts_rels_products_id_idx" ON "posts_rels" USING btree ("products_id");
  CREATE INDEX "pages_seo_seo_og_image_idx" ON "pages" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "pages_slug_idx" ON "pages" USING btree ("slug");
  CREATE INDEX "pages_status_idx" ON "pages" USING btree ("status");
  CREATE INDEX "pages_updated_at_idx" ON "pages" USING btree ("updated_at");
  CREATE INDEX "pages_created_at_idx" ON "pages" USING btree ("created_at");
  CREATE UNIQUE INDEX "pages_locales_locale_parent_id_unique" ON "pages_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "pages_locales_parent_id_idx" ON "pages_locales" USING btree ("_parent_id");
  CREATE INDEX "redirects_from_slug_idx" ON "redirects" USING btree ("from_slug");
  CREATE INDEX "redirects_updated_at_idx" ON "redirects" USING btree ("updated_at");
  CREATE INDEX "redirects_created_at_idx" ON "redirects" USING btree ("created_at");
  CREATE INDEX "users_roles_order_idx" ON "users_roles" USING btree ("order");
  CREATE INDEX "users_roles_parent_idx" ON "users_roles" USING btree ("parent_id");
  CREATE INDEX "users_sessions_order_idx" ON "users_sessions" USING btree ("_order");
  CREATE INDEX "users_sessions_parent_id_idx" ON "users_sessions" USING btree ("_parent_id");
  CREATE INDEX "users_updated_at_idx" ON "users" USING btree ("updated_at");
  CREATE INDEX "users_created_at_idx" ON "users" USING btree ("created_at");
  CREATE UNIQUE INDEX "users_email_idx" ON "users" USING btree ("email");
  CREATE UNIQUE INDEX "payload_kv_key_idx" ON "payload_kv" USING btree ("key");
  CREATE INDEX "payload_locked_documents_global_slug_idx" ON "payload_locked_documents" USING btree ("global_slug");
  CREATE INDEX "payload_locked_documents_updated_at_idx" ON "payload_locked_documents" USING btree ("updated_at");
  CREATE INDEX "payload_locked_documents_created_at_idx" ON "payload_locked_documents" USING btree ("created_at");
  CREATE INDEX "payload_locked_documents_rels_order_idx" ON "payload_locked_documents_rels" USING btree ("order");
  CREATE INDEX "payload_locked_documents_rels_parent_idx" ON "payload_locked_documents_rels" USING btree ("parent_id");
  CREATE INDEX "payload_locked_documents_rels_path_idx" ON "payload_locked_documents_rels" USING btree ("path");
  CREATE INDEX "payload_locked_documents_rels_products_id_idx" ON "payload_locked_documents_rels" USING btree ("products_id");
  CREATE INDEX "payload_locked_documents_rels_categories_id_idx" ON "payload_locked_documents_rels" USING btree ("categories_id");
  CREATE INDEX "payload_locked_documents_rels_stock_adjustments_id_idx" ON "payload_locked_documents_rels" USING btree ("stock_adjustments_id");
  CREATE INDEX "payload_locked_documents_rels_orders_id_idx" ON "payload_locked_documents_rels" USING btree ("orders_id");
  CREATE INDEX "payload_locked_documents_rels_payments_id_idx" ON "payload_locked_documents_rels" USING btree ("payments_id");
  CREATE INDEX "payload_locked_documents_rels_customers_id_idx" ON "payload_locked_documents_rels" USING btree ("customers_id");
  CREATE INDEX "payload_locked_documents_rels_coupons_id_idx" ON "payload_locked_documents_rels" USING btree ("coupons_id");
  CREATE INDEX "payload_locked_documents_rels_media_id_idx" ON "payload_locked_documents_rels" USING btree ("media_id");
  CREATE INDEX "payload_locked_documents_rels_faqs_id_idx" ON "payload_locked_documents_rels" USING btree ("faqs_id");
  CREATE INDEX "payload_locked_documents_rels_testimonials_id_idx" ON "payload_locked_documents_rels" USING btree ("testimonials_id");
  CREATE INDEX "payload_locked_documents_rels_posts_id_idx" ON "payload_locked_documents_rels" USING btree ("posts_id");
  CREATE INDEX "payload_locked_documents_rels_pages_id_idx" ON "payload_locked_documents_rels" USING btree ("pages_id");
  CREATE INDEX "payload_locked_documents_rels_redirects_id_idx" ON "payload_locked_documents_rels" USING btree ("redirects_id");
  CREATE INDEX "payload_locked_documents_rels_users_id_idx" ON "payload_locked_documents_rels" USING btree ("users_id");
  CREATE INDEX "payload_preferences_key_idx" ON "payload_preferences" USING btree ("key");
  CREATE INDEX "payload_preferences_updated_at_idx" ON "payload_preferences" USING btree ("updated_at");
  CREATE INDEX "payload_preferences_created_at_idx" ON "payload_preferences" USING btree ("created_at");
  CREATE INDEX "payload_preferences_rels_order_idx" ON "payload_preferences_rels" USING btree ("order");
  CREATE INDEX "payload_preferences_rels_parent_idx" ON "payload_preferences_rels" USING btree ("parent_id");
  CREATE INDEX "payload_preferences_rels_path_idx" ON "payload_preferences_rels" USING btree ("path");
  CREATE INDEX "payload_preferences_rels_users_id_idx" ON "payload_preferences_rels" USING btree ("users_id");
  CREATE INDEX "payload_migrations_updated_at_idx" ON "payload_migrations" USING btree ("updated_at");
  CREATE INDEX "payload_migrations_created_at_idx" ON "payload_migrations" USING btree ("created_at");
  CREATE INDEX "homepage_benefits_order_idx" ON "homepage_benefits" USING btree ("_order");
  CREATE INDEX "homepage_benefits_parent_id_idx" ON "homepage_benefits" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "homepage_benefits_locales_locale_parent_id_unique" ON "homepage_benefits_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "homepage_benefits_locales_parent_id_idx" ON "homepage_benefits_locales" USING btree ("_parent_id");
  CREATE INDEX "homepage_hero_hero_image_idx" ON "homepage" USING btree ("hero_image_id");
  CREATE INDEX "homepage_featured_featured_category_idx" ON "homepage" USING btree ("featured_category_id");
  CREATE INDEX "homepage_promo_promo_image_idx" ON "homepage" USING btree ("promo_image_id");
  CREATE INDEX "homepage_story_story_image_idx" ON "homepage" USING btree ("story_image_id");
  CREATE INDEX "homepage_seo_seo_og_image_idx" ON "homepage" USING btree ("seo_og_image_id");
  CREATE UNIQUE INDEX "homepage_locales_locale_parent_id_unique" ON "homepage_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "homepage_locales_parent_id_idx" ON "homepage_locales" USING btree ("_parent_id");
  CREATE INDEX "homepage_rels_order_idx" ON "homepage_rels" USING btree ("order");
  CREATE INDEX "homepage_rels_parent_idx" ON "homepage_rels" USING btree ("parent_id");
  CREATE INDEX "homepage_rels_path_idx" ON "homepage_rels" USING btree ("path");
  CREATE INDEX "homepage_rels_categories_id_idx" ON "homepage_rels" USING btree ("categories_id");
  CREATE INDEX "homepage_rels_products_id_idx" ON "homepage_rels" USING btree ("products_id");
  CREATE INDEX "branding_socials_order_idx" ON "branding_socials" USING btree ("_order");
  CREATE INDEX "branding_socials_parent_id_idx" ON "branding_socials" USING btree ("_parent_id");
  CREATE INDEX "branding_logo_idx" ON "branding" USING btree ("logo_id");
  CREATE INDEX "branding_logo_mobile_idx" ON "branding" USING btree ("logo_mobile_id");
  CREATE INDEX "branding_logo_footer_idx" ON "branding" USING btree ("logo_footer_id");
  CREATE INDEX "branding_favicon_idx" ON "branding" USING btree ("favicon_id");
  CREATE INDEX "branding_default_share_image_idx" ON "branding" USING btree ("default_share_image_id");
  CREATE UNIQUE INDEX "branding_locales_locale_parent_id_unique" ON "branding_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "branding_locales_parent_id_idx" ON "branding_locales" USING btree ("_parent_id");
  CREATE INDEX "contact_settings_show_on_order_idx" ON "contact_settings_show_on" USING btree ("order");
  CREATE INDEX "contact_settings_show_on_parent_idx" ON "contact_settings_show_on" USING btree ("parent_id");
  CREATE UNIQUE INDEX "contact_settings_locales_locale_parent_id_unique" ON "contact_settings_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "contact_settings_locales_parent_id_idx" ON "contact_settings_locales" USING btree ("_parent_id");
  CREATE INDEX "navigation_header_links_order_idx" ON "navigation_header_links" USING btree ("_order");
  CREATE INDEX "navigation_header_links_parent_id_idx" ON "navigation_header_links" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_header_links_locales_locale_parent_id_unique" ON "navigation_header_links_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_header_links_locales_parent_id_idx" ON "navigation_header_links_locales" USING btree ("_parent_id");
  CREATE INDEX "navigation_footer_columns_links_order_idx" ON "navigation_footer_columns_links" USING btree ("_order");
  CREATE INDEX "navigation_footer_columns_links_parent_id_idx" ON "navigation_footer_columns_links" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_footer_columns_links_locales_locale_parent_id_uni" ON "navigation_footer_columns_links_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_footer_columns_links_locales_parent_id_idx" ON "navigation_footer_columns_links_locales" USING btree ("_parent_id");
  CREATE INDEX "navigation_footer_columns_order_idx" ON "navigation_footer_columns" USING btree ("_order");
  CREATE INDEX "navigation_footer_columns_parent_id_idx" ON "navigation_footer_columns" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_footer_columns_locales_locale_parent_id_unique" ON "navigation_footer_columns_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_footer_columns_locales_parent_id_idx" ON "navigation_footer_columns_locales" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "navigation_locales_locale_parent_id_unique" ON "navigation_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "navigation_locales_parent_id_idx" ON "navigation_locales" USING btree ("_parent_id");
  CREATE INDEX "delivery_settings_zones_districts_order_idx" ON "delivery_settings_zones_districts" USING btree ("order");
  CREATE INDEX "delivery_settings_zones_districts_parent_idx" ON "delivery_settings_zones_districts" USING btree ("parent_id");
  CREATE INDEX "delivery_settings_zones_order_idx" ON "delivery_settings_zones" USING btree ("_order");
  CREATE INDEX "delivery_settings_zones_parent_id_idx" ON "delivery_settings_zones" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "delivery_settings_zones_locales_locale_parent_id_unique" ON "delivery_settings_zones_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "delivery_settings_zones_locales_parent_id_idx" ON "delivery_settings_zones_locales" USING btree ("_parent_id");
  CREATE INDEX "delivery_settings_methods_order_idx" ON "delivery_settings_methods" USING btree ("_order");
  CREATE INDEX "delivery_settings_methods_parent_id_idx" ON "delivery_settings_methods" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "delivery_settings_methods_locales_locale_parent_id_unique" ON "delivery_settings_methods_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "delivery_settings_methods_locales_parent_id_idx" ON "delivery_settings_methods_locales" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "delivery_settings_locales_locale_parent_id_unique" ON "delivery_settings_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "delivery_settings_locales_parent_id_idx" ON "delivery_settings_locales" USING btree ("_parent_id");
  CREATE UNIQUE INDEX "payment_settings_locales_locale_parent_id_unique" ON "payment_settings_locales" USING btree ("_locale","_parent_id");
  CREATE INDEX "payment_settings_locales_parent_id_idx" ON "payment_settings_locales" USING btree ("_parent_id");`)}async function g({db:a,payload:b,req:c}){await a.execute((0,e.ll)`
   DROP TABLE "products_attributes" CASCADE;
  DROP TABLE "products_attributes_locales" CASCADE;
  DROP TABLE "products_variants" CASCADE;
  DROP TABLE "products_variants_locales" CASCADE;
  DROP TABLE "products" CASCADE;
  DROP TABLE "products_locales" CASCADE;
  DROP TABLE "products_texts" CASCADE;
  DROP TABLE "products_rels" CASCADE;
  DROP TABLE "categories" CASCADE;
  DROP TABLE "categories_locales" CASCADE;
  DROP TABLE "stock_adjustments" CASCADE;
  DROP TABLE "orders_items" CASCADE;
  DROP TABLE "orders_status_history" CASCADE;
  DROP TABLE "orders" CASCADE;
  DROP TABLE "payments" CASCADE;
  DROP TABLE "customers" CASCADE;
  DROP TABLE "coupons" CASCADE;
  DROP TABLE "media" CASCADE;
  DROP TABLE "media_locales" CASCADE;
  DROP TABLE "faqs" CASCADE;
  DROP TABLE "faqs_locales" CASCADE;
  DROP TABLE "testimonials" CASCADE;
  DROP TABLE "testimonials_locales" CASCADE;
  DROP TABLE "posts" CASCADE;
  DROP TABLE "posts_locales" CASCADE;
  DROP TABLE "posts_rels" CASCADE;
  DROP TABLE "pages" CASCADE;
  DROP TABLE "pages_locales" CASCADE;
  DROP TABLE "redirects" CASCADE;
  DROP TABLE "users_roles" CASCADE;
  DROP TABLE "users_sessions" CASCADE;
  DROP TABLE "users" CASCADE;
  DROP TABLE "payload_kv" CASCADE;
  DROP TABLE "payload_locked_documents" CASCADE;
  DROP TABLE "payload_locked_documents_rels" CASCADE;
  DROP TABLE "payload_preferences" CASCADE;
  DROP TABLE "payload_preferences_rels" CASCADE;
  DROP TABLE "payload_migrations" CASCADE;
  DROP TABLE "homepage_benefits" CASCADE;
  DROP TABLE "homepage_benefits_locales" CASCADE;
  DROP TABLE "homepage" CASCADE;
  DROP TABLE "homepage_locales" CASCADE;
  DROP TABLE "homepage_rels" CASCADE;
  DROP TABLE "branding_socials" CASCADE;
  DROP TABLE "branding" CASCADE;
  DROP TABLE "branding_locales" CASCADE;
  DROP TABLE "contact_settings_show_on" CASCADE;
  DROP TABLE "contact_settings" CASCADE;
  DROP TABLE "contact_settings_locales" CASCADE;
  DROP TABLE "navigation_header_links" CASCADE;
  DROP TABLE "navigation_header_links_locales" CASCADE;
  DROP TABLE "navigation_footer_columns_links" CASCADE;
  DROP TABLE "navigation_footer_columns_links_locales" CASCADE;
  DROP TABLE "navigation_footer_columns" CASCADE;
  DROP TABLE "navigation_footer_columns_locales" CASCADE;
  DROP TABLE "navigation" CASCADE;
  DROP TABLE "navigation_locales" CASCADE;
  DROP TABLE "delivery_settings_zones_districts" CASCADE;
  DROP TABLE "delivery_settings_zones" CASCADE;
  DROP TABLE "delivery_settings_zones_locales" CASCADE;
  DROP TABLE "delivery_settings_methods" CASCADE;
  DROP TABLE "delivery_settings_methods_locales" CASCADE;
  DROP TABLE "delivery_settings" CASCADE;
  DROP TABLE "delivery_settings_locales" CASCADE;
  DROP TABLE "payment_settings" CASCADE;
  DROP TABLE "payment_settings_locales" CASCADE;
  DROP TABLE "analytics_settings" CASCADE;
  DROP TYPE "public"."_locales";
  DROP TYPE "public"."enum_products_variants_unit";
  DROP TYPE "public"."enum_products_status";
  DROP TYPE "public"."enum_products_translation_status";
  DROP TYPE "public"."enum_categories_status";
  DROP TYPE "public"."enum_categories_translation_status";
  DROP TYPE "public"."enum_stock_adjustments_reason";
  DROP TYPE "public"."enum_orders_district";
  DROP TYPE "public"."enum_orders_status";
  DROP TYPE "public"."enum_orders_payment_status";
  DROP TYPE "public"."enum_orders_payment_method";
  DROP TYPE "public"."enum_orders_locale";
  DROP TYPE "public"."enum_payments_provider";
  DROP TYPE "public"."enum_payments_status";
  DROP TYPE "public"."enum_customers_last_address_district";
  DROP TYPE "public"."enum_coupons_type";
  DROP TYPE "public"."enum_faqs_topic";
  DROP TYPE "public"."enum_faqs_status";
  DROP TYPE "public"."enum_faqs_translation_status";
  DROP TYPE "public"."enum_testimonials_moderation";
  DROP TYPE "public"."enum_posts_status";
  DROP TYPE "public"."enum_posts_translation_status";
  DROP TYPE "public"."enum_pages_kind";
  DROP TYPE "public"."enum_pages_status";
  DROP TYPE "public"."enum_pages_translation_status";
  DROP TYPE "public"."enum_redirects_type";
  DROP TYPE "public"."enum_users_roles";
  DROP TYPE "public"."enum_homepage_benefits_icon";
  DROP TYPE "public"."enum_homepage_announcement_tone";
  DROP TYPE "public"."enum_branding_socials_platform";
  DROP TYPE "public"."enum_contact_settings_show_on";
  DROP TYPE "public"."enum_contact_settings_position";
  DROP TYPE "public"."enum_delivery_settings_zones_districts";`)}d()}catch(a){d(a)}})},18128:(a,b,c)=>{"use strict";c.d(b,{V:()=>i});var d=c(61236),e=c(86806),f=c(74374);let g=(a,b)=>({name:a,label:b,type:"group",fields:[{type:"row",fields:[{name:"label",type:"text",localized:!0,admin:{width:"50%"}},{name:"href",type:"text",admin:{width:"50%",description:"e.g. /category/mango"}}]}]}),h=(a=!0)=>({name:"enabled",type:"checkbox",defaultValue:a}),i={slug:"homepage",label:"Homepage",admin:{group:"Content",description:"Every homepage section, in page order. Hidden sections are skipped."},access:{read:d.ZZ,update:d.Xl},fields:[{type:"tabs",tabs:[{label:"Top",fields:[{name:"announcement",label:"Announcement bar",type:"group",fields:[h(),{name:"text",type:"text",localized:!0},{name:"href",type:"text",admin:{description:"Optional link, e.g. /category/mango"}},{name:"tone",type:"select",defaultValue:"green",options:[{label:"Deep green",value:"green"},{label:"Mango yellow",value:"mango"},{label:"Cream",value:"cream"}]}]},{name:"hero",type:"group",fields:[{name:"headline",type:"text",required:!0,localized:!0,validate:f.E},{name:"subheadline",type:"textarea",localized:!0},{name:"image",type:"upload",relationTo:"media",admin:{description:"Large mango photograph or artwork. Transparent PNG/WebP cut-outs look best."}},g("primaryCta","Primary button"),g("secondaryCta","Secondary button"),{name:"seasonalBadge",type:"group",fields:[h(),{name:"text",type:"text",localized:!0,admin:{description:'e.g. "মৌসুম চলছে"'}}]}]},{name:"benefits",label:"Trust benefits",type:"array",maxRows:4,admin:{description:"Up to four short promises you can keep."},fields:[{type:"row",fields:[{name:"icon",type:"select",defaultValue:"leaf",admin:{width:"25%"},options:["leaf","package","truck","wallet","shield","phone","clock","heart"].map(a=>({label:a,value:a}))},{name:"title",type:"text",required:!0,localized:!0,validate:f.E,admin:{width:"35%"}},{name:"text",type:"text",localized:!0,admin:{width:"40%"}}]}]}]},{label:"Products",fields:[{name:"categoriesSection",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"categories",type:"relationship",relationTo:"categories",hasMany:!0,admin:{description:"In display order. Empty = featured categories."}}]},{name:"featured",label:"Featured mangoes",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"intro",type:"text",localized:!0},{name:"category",type:"relationship",relationTo:"categories",admin:{description:"Products come from this category (featured first)."}},{name:"products",type:"relationship",relationTo:"products",hasMany:!0,admin:{description:"Optional hand-picked list, overrides the category."}},{name:"limit",type:"number",defaultValue:8,min:2,max:16},g("cta","Button")]},{name:"traditional",label:"Other traditional foods",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"intro",type:"text",localized:!0},{name:"categories",type:"relationship",relationTo:"categories",hasMany:!0,admin:{description:"Which categories appear, in order."}},{name:"perCategory",type:"number",defaultValue:4,min:1,max:8}]},{name:"popular",label:"Popular products & bundles",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"products",type:"relationship",relationTo:"products",hasMany:!0,admin:{description:'Empty = products marked "best seller" and bundles.'}}]}]},{label:"Story & promo",fields:[{name:"promo",label:"Promotional banner",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"text",type:"textarea",localized:!0},{name:"image",type:"upload",relationTo:"media"},g("cta","Button")]},{name:"story",label:"Brand story",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0},{name:"body",type:"textarea",localized:!0,admin:{description:"Paragraphs separated by a blank line. Only include claims you can stand behind."}},{name:"image",type:"upload",relationTo:"media"},g("cta","Button")]}]},{label:"Reviews & FAQ",fields:[{name:"testimonials",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0}],admin:{description:"Shows approved reviews that customers agreed to publish. Hidden automatically when there are none."}},{name:"faq",type:"group",fields:[h(),{name:"heading",type:"text",localized:!0}]}]},{label:"SEO",fields:[(0,e.Z)()]}]}]}},28964:(a,b,c)=>{"use strict";async function d(a,b){if(!a)return b();let c={locale:a.locale,fallbackLocale:a.fallbackLocale};try{return await b()}finally{a.locale=c.locale,a.fallbackLocale=c.fallbackLocale}}c.d(b,{N:()=>d})},29918:(a,b,c)=>{"use strict";c.d(b,{Ce:()=>f,dn:()=>g});let d=(a,b,c,d)=>({code:b,division:a,en:c,bn:d}),e=[d("barishal","barguna","Barguna","বরগুনা"),d("barishal","barishal","Barishal","বরিশাল"),d("barishal","bhola","Bhola","ভোলা"),d("barishal","jhalokati","Jhalokati","ঝালকাঠি"),d("barishal","patuakhali","Patuakhali","পটুয়াখালী"),d("barishal","pirojpur","Pirojpur","পিরোজপুর"),d("chattogram","bandarban","Bandarban","বান্দরবান"),d("chattogram","brahmanbaria","Brahmanbaria","ব্রাহ্মণবাড়িয়া"),d("chattogram","chandpur","Chandpur","চাঁদপুর"),d("chattogram","chattogram","Chattogram","চট্টগ্রাম"),d("chattogram","cumilla","Cumilla","কুমিল্লা"),d("chattogram","coxsbazar","Cox's Bazar","কক্সবাজার"),d("chattogram","feni","Feni","ফেনী"),d("chattogram","khagrachhari","Khagrachhari","খাগড়াছড়ি"),d("chattogram","lakshmipur","Lakshmipur","লক্ষ্মীপুর"),d("chattogram","noakhali","Noakhali","নোয়াখালী"),d("chattogram","rangamati","Rangamati","রাঙ্গামাটি"),d("dhaka","dhaka","Dhaka","ঢাকা"),d("dhaka","faridpur","Faridpur","ফরিদপুর"),d("dhaka","gazipur","Gazipur","গাজীপুর"),d("dhaka","gopalganj","Gopalganj","গোপালগঞ্জ"),d("dhaka","kishoreganj","Kishoreganj","কিশোরগঞ্জ"),d("dhaka","madaripur","Madaripur","মাদারীপুর"),d("dhaka","manikganj","Manikganj","মানিকগঞ্জ"),d("dhaka","munshiganj","Munshiganj","মুন্সীগঞ্জ"),d("dhaka","narayanganj","Narayanganj","নারায়ণগঞ্জ"),d("dhaka","narsingdi","Narsingdi","নরসিংদী"),d("dhaka","rajbari","Rajbari","রাজবাড়ী"),d("dhaka","shariatpur","Shariatpur","শরীয়তপুর"),d("dhaka","tangail","Tangail","টাঙ্গাইল"),d("khulna","bagerhat","Bagerhat","বাগেরহাট"),d("khulna","chuadanga","Chuadanga","চুয়াডাঙ্গা"),d("khulna","jashore","Jashore","যশোর"),d("khulna","jhenaidah","Jhenaidah","ঝিনাইদহ"),d("khulna","khulna","Khulna","খুলনা"),d("khulna","kushtia","Kushtia","কুষ্টিয়া"),d("khulna","magura","Magura","মাগুরা"),d("khulna","meherpur","Meherpur","মেহেরপুর"),d("khulna","narail","Narail","নড়াইল"),d("khulna","satkhira","Satkhira","সাতক্ষীরা"),d("mymensingh","jamalpur","Jamalpur","জামালপুর"),d("mymensingh","mymensingh","Mymensingh","ময়মনসিংহ"),d("mymensingh","netrokona","Netrokona","নেত্রকোণা"),d("mymensingh","sherpur","Sherpur","শেরপুর"),d("rajshahi","bogura","Bogura","বগুড়া"),d("rajshahi","chapainawabganj","Chapai Nawabganj","চাঁপাইনবাবগঞ্জ"),d("rajshahi","joypurhat","Joypurhat","জয়পুরহাট"),d("rajshahi","naogaon","Naogaon","নওগাঁ"),d("rajshahi","natore","Natore","নাটোর"),d("rajshahi","pabna","Pabna","পাবনা"),d("rajshahi","rajshahi","Rajshahi","রাজশাহী"),d("rajshahi","sirajganj","Sirajganj","সিরাজগঞ্জ"),d("rangpur","dinajpur","Dinajpur","দিনাজপুর"),d("rangpur","gaibandha","Gaibandha","গাইবান্ধা"),d("rangpur","kurigram","Kurigram","কুড়িগ্রাম"),d("rangpur","lalmonirhat","Lalmonirhat","লালমনিরহাট"),d("rangpur","nilphamari","Nilphamari","নীলফামারী"),d("rangpur","panchagarh","Panchagarh","পঞ্চগড়"),d("rangpur","rangpur","Rangpur","রংপুর"),d("rangpur","thakurgaon","Thakurgaon","ঠাকুরগাঁও"),d("sylhet","habiganj","Habiganj","হবিগঞ্জ"),d("sylhet","moulvibazar","Moulvibazar","মৌলভীবাজার"),d("sylhet","sunamganj","Sunamganj","সুনামগঞ্জ"),d("sylhet","sylhet","Sylhet","সিলেট")];function f(a,b){return e.find(b=>b.code===a)?.[b]??a}e.map(a=>a.code),[{code:"barishal",en:"Barishal",bn:"বরিশাল"},{code:"chattogram",en:"Chattogram",bn:"চট্টগ্রাম"},{code:"dhaka",en:"Dhaka",bn:"ঢাকা"},{code:"khulna",en:"Khulna",bn:"খুলনা"},{code:"mymensingh",en:"Mymensingh",bn:"ময়মনসিংহ"},{code:"rajshahi",en:"Rajshahi",bn:"রাজশাহী"},{code:"rangpur",en:"Rangpur",bn:"রংপুর"},{code:"sylhet",en:"Sylhet",bn:"সিলেট"}].map(a=>a.code);let g=e.map(a=>({label:`${a.en} — ${a.bn}`,value:a.code}))},31211:(a,b,c)=>{"use strict";function d(a){if(!a)return null;let b=a instanceof Date?a.getTime():Date.parse(a);return Number.isNaN(b)?null:b}function e(a,b=new Date){let c=function(a,b=new Date){if(null==a.salePrice||a.salePrice<=0||a.salePrice>=a.price)return!1;let c=d(a.saleStartsAt),e=d(a.saleEndsAt),f=b.getTime();return(null===c||!(f<c))&&(null===e||!(f>e))}(a,b),f=c?a.salePrice:a.price,g=c?Math.floor((a.price-f)*100/a.price):0;return{unitPrice:f,regularPrice:a.price,onSale:c,discountPercent:g}}c.d(b,{n:()=>e})},31719:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{l:()=>s});var e=c(61236),f=c(70667),g=c(86806),h=c(75688),i=c(16043),j=c(5003),k=c(31211),l=c(84392),m=c(99224),n=c(28964),o=c(74374),p=a([l]);l=(p.then?(await p)():p)[0];let q=async({data:a,req:b,originalDoc:c})=>{let d=a.variants??[],e=d.map(a=>(a.sku??"").trim().toUpperCase()).filter(Boolean),f=e.find((a,b)=>e.indexOf(a)!==b);if(f)throw Error(`SKU "${f}" is used twice in this product.`);if(d.forEach(a=>{a.sku&&(a.sku=a.sku.trim().toUpperCase())}),e.length){let a={"variants.sku":{in:e}};if(c?.id&&(a.id={not_equals:c.id}),(await b.payload.find({collection:"products",where:a,limit:1,depth:0,req:b,overrideAccess:!0})).docs.length)throw Error(`One of these SKUs is already used by another product: ${e.join(", ")}`)}return a},r=async({data:a,req:b,originalDoc:c,operation:d})=>{let e=a.variants??[],f=e.filter(a=>"number"==typeof a.price).map(a=>(0,k.n)({price:a.price,salePrice:a.salePrice,saleStartsAt:a.saleStartsAt,saleEndsAt:a.saleEndsAt}).unitPrice);a.minPrice=f.length?Math.min(...f):0;let g=b.locale||"bn",h={};"update"===d&&c?.id&&(h=await (0,n.N)(b,()=>b.payload.findByID({collection:"products",id:c.id,locale:"all",depth:0,req:b,overrideAccess:!0})));let i=b=>["string"==typeof a[b]?a[b]:"",("bn"===g?h[b]?.en:h[b]?.bn)??""];return a.searchText=[...i("name"),...i("shortDescription"),...a.tags??[],...e.map(a=>a.sku??"")].filter(Boolean).join(" ").toLowerCase().slice(0,4e3),a},s={slug:"products",labels:{singular:"Product",plural:"Products"},admin:{useAsTitle:"name",group:"Catalog",defaultColumns:["name","categories","minPrice","totalStock","status","featured","translationStatus"],listSearchableFields:["name","slug","searchText"],preview:(a,{locale:b})=>`/${b||"bn"}/product/${a.slug}?preview=1`,components:{beforeListTable:["/components/admin/ProductImportExport#ProductImportExport"]}},defaultSort:"sortOrder",access:{read:e.qp,create:e.Xl,update:e.Xl,delete:e.Xl},endpoints:[m.Yu,m.dE],hooks:{beforeChange:[q,r,(0,i.n)(["name","shortDescription"])],afterChange:[(0,j.L)("product"),async({doc:a,req:b})=>(await (0,l.R7)(b.payload,a.id,b),a)],beforeDelete:[async({id:a,req:b})=>{if((await b.payload.find({collection:"orders",where:{"items.product":{equals:a}},limit:1,depth:0,req:b,overrideAccess:!0})).totalDocs>0)throw Error('This product appears in existing orders and cannot be deleted. Set its status to "Hidden" instead.')}]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"name",type:"text",required:!0,localized:!0,validate:o.E},{name:"shortDescription",type:"textarea",localized:!0,maxLength:300,admin:{description:"One or two sentences for product cards and search results."}},{name:"description",type:"richText",localized:!0},{name:"images",type:"upload",relationTo:"media",hasMany:!0,admin:{description:"Drag to reorder. The first image is the main image."}},{name:"attributes",type:"array",labels:{singular:"Attribute",plural:"Attributes"},admin:{description:"Facts shown on the product page, e.g. Origin: Rajshahi, Season: June–July.",initCollapsed:!0},fields:[{type:"row",fields:[{name:"label",type:"text",required:!0,localized:!0,validate:o.E,admin:{width:"40%"}},{name:"value",type:"text",required:!0,localized:!0,validate:o.E,admin:{width:"60%"}}]}]}]},{label:"Prices & stock",fields:[{name:"variants",type:"array",minRows:1,required:!0,labels:{singular:"Size / pack",plural:"Sizes / packs"},admin:{description:"Each size or pack has its own SKU, price and stock. The first one is selected by default. Stock can be set when a size is created; afterwards change it from Inventory → Stock adjustments so every change is recorded."},fields:[{type:"row",fields:[{name:"label",type:"text",required:!0,localized:!0,validate:o.E,admin:{width:"34%",description:'e.g. "৫ কেজি" / "5 kg"'}},{name:"sku",type:"text",required:!0,admin:{width:"22%"}},{name:"packSize",type:"number",min:0,admin:{width:"20%",step:.1}},{name:"unit",type:"select",defaultValue:"kg",admin:{width:"24%"},options:[{label:"gram (g)",value:"g"},{label:"kilogram (kg)",value:"kg"},{label:"millilitre (ml)",value:"ml"},{label:"litre (l)",value:"l"},{label:"piece",value:"pcs"},{label:"jar",value:"jar"},{label:"box",value:"box"},{label:"pack",value:"pack"}]}]},{type:"row",fields:[(0,f.$)({name:"price",label:"Regular price (৳)",required:!0,admin:{width:"25%"}}),(0,f.$)({name:"salePrice",label:"Sale price (৳)",admin:{width:"25%",description:"Leave empty for no sale."}}),{name:"saleStartsAt",type:"date",admin:{width:"25%",date:{pickerAppearance:"dayAndTime"},description:"Optional sale start"}},{name:"saleEndsAt",type:"date",admin:{width:"25%",date:{pickerAppearance:"dayAndTime"},description:"Optional sale end"}}]},{type:"row",fields:[{name:"stock",type:"number",min:0,defaultValue:0,access:{update:()=>!1},admin:{width:"25%",description:"Units in stock"}},{name:"lowStockThreshold",type:"number",min:0,defaultValue:5,admin:{width:"25%"}},{name:"weightGrams",type:"number",min:0,admin:{width:"25%",description:"Shipping weight (optional)"}}]}]}]},{label:"SEO",fields:[(0,g.Z)()]}]},(0,h.O)("name"),{name:"status",type:"select",required:!0,defaultValue:"draft",index:!0,options:[{label:"Published",value:"published"},{label:"Hidden (draft)",value:"draft"}],admin:{position:"sidebar"}},{name:"categories",type:"relationship",relationTo:"categories",hasMany:!0,required:!0,admin:{position:"sidebar"}},{name:"tags",type:"text",hasMany:!0,admin:{position:"sidebar"}},{name:"featured",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"Show in homepage featured sections."}},{name:"bestSeller",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:'Show in "Popular picks".'}},{name:"isBundle",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"Combo / gift box."}},{name:"sortOrder",type:"number",defaultValue:0,admin:{position:"sidebar"}},{name:"relatedProducts",type:"relationship",relationTo:"products",hasMany:!0,admin:{position:"sidebar",description:"Optional. Otherwise products from the same category are shown."},filterOptions:({id:a})=>!a||{id:{not_equals:a}}},(0,i.I)(),(0,f.$)({name:"minPrice",label:"From price",admin:{readOnly:!0,position:"sidebar",description:"Calculated"}}),{name:"totalStock",type:"number",defaultValue:0,index:!0,admin:{readOnly:!0,position:"sidebar",description:"Calculated from sizes"}},{name:"searchText",type:"text",index:!0,admin:{hidden:!0}}]};d()}catch(a){d(a)}})},36757:(a,b,c)=>{"use strict";function d(a){if(null==a)return"";let b=String(a);return/^[=+\-@\t\r]/.test(b)&&(b=`'${b}`),/[",\n\r]/.test(b)?`"${b.replace(/"/g,'""')}"`:b}function e(a,b){return"\uFEFF"+[a,...b].map(a=>a.map(d).join(",")).join("\r\n")+"\r\n"}function f(a){let b=[],c=[],d="",e=!1,f=a.replace(/^﻿/,"");for(let a=0;a<f.length;a++){let g=f[a];e?'"'===g&&'"'===f[a+1]?(d+='"',a++):'"'===g?e=!1:d+=g:'"'===g?e=!0:","===g?(c.push(d),d=""):"\n"===g||"\r"===g?("\r"===g&&"\n"===f[a+1]&&a++,c.push(d),c.some(a=>""!==a)&&b.push(c),c=[],d=""):d+=g}return c.push(d),c.some(a=>""!==a)&&b.push(c),b}c.d(b,{Wk:()=>f,gD:()=>e,r$:()=>g});let g=a=>null==a?"":(a/100).toFixed(2)},37507:(a,b,c)=>{"use strict";c.d(b,{$g:()=>g,GW:()=>j,Yq:()=>i,ZV:()=>h});var d=c(10550);let e=new Map;function f(a,b){let c=`${a}:${b}`,f=e.get(c);return f||(f=new Intl.NumberFormat(d.ib[a].intl,{minimumFractionDigits:b,maximumFractionDigits:b}),e.set(c,f)),f}function g(a,b){let c=f(b,2*(a%100!=0)).format(a/100);return"bn"===b?`৳ ${c}`:`৳${c}`}function h(a,b){return f(b,0).format(a)}function i(a,b,c=!1){let e="string"==typeof a?new Date(a):a;return new Intl.DateTimeFormat(d.ib[b].intl,{year:"numeric",month:"long",day:"numeric",...c?{hour:"numeric",minute:"2-digit"}:{},timeZone:"Asia/Dhaka"}).format(e)}function j(a,b){return a.replace(/\{(\w+)\}/g,(a,c)=>c in b?String(b[c]):`{${c}}`)}},39727:()=>{},40803:(a,b,c)=>{"use strict";c.d(b,{z:()=>f});var d=c(8658),e=c(61236);let f={slug:"users",labels:{singular:"Staff user",plural:"Staff users"},admin:{useAsTitle:"email",defaultColumns:["email","name","roles","updatedAt"],group:"Settings"},auth:{tokenExpiration:28800,maxLoginAttempts:5,lockTime:9e5,useSessions:!0,cookies:{sameSite:"Lax",secure:"true"!==process.env.INSECURE_COOKIES}},access:{read:({req:a})=>!!(0,e.hf)(a.user,"admin")||!!a.user&&{id:{equals:a.user.id}},create:e.qc,delete:e.qc,update:({req:a})=>!!(0,e.hf)(a.user,"admin")||!!a.user&&{id:{equals:a.user.id}},admin:({req:a})=>(0,e.hf)(a.user,"admin","manager","editor")},hooks:{beforeOperation:[({operation:a,req:b,args:c})=>{if("create"!==a||b.user||b.context?.allowStaffBootstrap===!0||"true"===process.env.ALLOW_WEB_FIRST_USER)return c;throw new d.c(b.t)}]},fields:[{name:"name",type:"text"},{name:"roles",type:"select",hasMany:!0,required:!0,defaultValue:["editor"],saveToJWT:!0,options:[{label:"Admin — full access",value:"admin"},{label:"Manager — catalog, content, orders",value:"manager"},{label:"Editor — catalog and content",value:"editor"}],access:{create:e.g8,update:e.g8}}]}},43807:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{w:()=>h});var e=c(17976),f=c(44807),g=a([e,f]);[e,f]=g.then?(await g)():g;let h=[{up:e.up,down:e.T,name:"20261026_084826_initial"},{up:f.up,down:f.T,name:"20261026_090000_integrity_constraints"}];d()}catch(a){d(a)}})},44731:(a,b,c)=>{"use strict";c.d(b,{S:()=>f});var d=c(61236),e=c(70667);let f={slug:"coupons",labels:{singular:"Coupon",plural:"Coupons"},admin:{group:"Sales",useAsTitle:"code",defaultColumns:["code","active","type","percent","amount","usedCount","usageLimit","endsAt"]},access:{read:d.k3,create:d.k3,update:d.k3,delete:d.k3},fields:[{name:"code",type:"text",required:!0,unique:!0,index:!0,hooks:{beforeValidate:[({value:a})=>"string"==typeof a?a.trim().toUpperCase().replace(/\s+/g,""):a]},admin:{description:"Letters and numbers, e.g. MANGO10. Case-insensitive for customers."}},{name:"description",type:"text",admin:{description:"Internal note."}},{name:"active",type:"checkbox",defaultValue:!0},{name:"type",type:"select",required:!0,defaultValue:"percent",options:[{label:"Percentage off",value:"percent"},{label:"Fixed amount off",value:"fixed"}]},{name:"percent",type:"number",min:1,max:100,admin:{condition:(a,b)=>b?.type==="percent",description:"e.g. 10 for 10% off"},validate:(a,{siblingData:b})=>b?.type!=="percent"||null!=a&&!(a<=0)&&!(a>100)||"Enter a percentage between 1 and 100."},(0,e.$)({name:"amount",label:"Amount off (৳)",admin:{condition:(a,b)=>b?.type==="fixed"}}),(0,e.$)({name:"minSubtotal",label:"Minimum order subtotal (৳)"}),(0,e.$)({name:"maxDiscount",label:"Maximum discount (৳)",admin:{description:"Cap for percentage coupons (optional)."}}),{type:"row",fields:[{name:"startsAt",type:"date",admin:{width:"50%",date:{pickerAppearance:"dayAndTime"}}},{name:"endsAt",type:"date",admin:{width:"50%",date:{pickerAppearance:"dayAndTime"}}}]},{type:"row",fields:[{name:"usageLimit",type:"number",min:0,admin:{width:"50%",description:"Total uses allowed. Empty or 0 = unlimited."}},{name:"usedCount",type:"number",defaultValue:0,admin:{width:"50%",readOnly:!0}}]}]}},44807:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{T:()=>g,up:()=>f});var e=c(5744);async function f({db:a}){await a.execute((0,e.ll)`
    ALTER TABLE "products_variants" ADD CONSTRAINT "products_variants_stock_nonneg" CHECK ("stock" IS NULL OR "stock" >= 0);
    ALTER TABLE "products_variants" ADD CONSTRAINT "products_variants_price_nonneg" CHECK ("price" >= 0 AND ("sale_price" IS NULL OR "sale_price" >= 0));
    ALTER TABLE "orders" ADD CONSTRAINT "orders_amounts_nonneg" CHECK ("subtotal" >= 0 AND "total" >= 0 AND COALESCE("discount", 0) >= 0 AND COALESCE("shipping_fee", 0) >= 0);
    ALTER TABLE "orders_items" ADD CONSTRAINT "orders_items_qty_pos" CHECK ("quantity" > 0 AND "unit_price" >= 0 AND "line_total" >= 0);
    ALTER TABLE "coupons" ADD CONSTRAINT "coupons_used_nonneg" CHECK (COALESCE("used_count", 0) >= 0);
    CREATE INDEX IF NOT EXISTS "orders_created_at_status_idx" ON "orders" ("created_at", "status");
  `)}async function g({db:a}){await a.execute((0,e.ll)`
    ALTER TABLE "products_variants" DROP CONSTRAINT IF EXISTS "products_variants_stock_nonneg";
    ALTER TABLE "products_variants" DROP CONSTRAINT IF EXISTS "products_variants_price_nonneg";
    ALTER TABLE "orders" DROP CONSTRAINT IF EXISTS "orders_amounts_nonneg";
    ALTER TABLE "orders_items" DROP CONSTRAINT IF EXISTS "orders_items_qty_pos";
    ALTER TABLE "coupons" DROP CONSTRAINT IF EXISTS "coupons_used_nonneg";
    DROP INDEX IF EXISTS "orders_created_at_status_idx";
  `)}d()}catch(a){d(a)}})},47990:()=>{},54971:(a,b,c)=>{"use strict";c.d(b,{L:()=>j});var d=c(61236),e=c(86806),f=c(75688),g=c(16043),h=c(5003),i=c(74374);let j={slug:"categories",labels:{singular:"Category",plural:"Categories"},admin:{useAsTitle:"name",group:"Catalog",defaultColumns:["name","slug","status","featured","sortOrder","translationStatus"],listSearchableFields:["name","slug"],preview:(a,{locale:b})=>`/${b||"bn"}/category/${a.slug}`},defaultSort:"sortOrder",access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["name"])],afterChange:[(0,h.L)("category")]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"name",type:"text",required:!0,localized:!0,validate:i.E},{name:"description",type:"textarea",localized:!0,admin:{description:"One or two sentences shown on category cards and the category page."}},{name:"image",type:"upload",relationTo:"media",admin:{description:"Square-ish image for category cards."}},{name:"banner",type:"upload",relationTo:"media",admin:{description:"Optional wide banner on the category page."}}]},{label:"SEO",fields:[(0,e.Z)()]}]},(0,f.O)("name"),{name:"status",type:"select",required:!0,defaultValue:"published",options:[{label:"Published",value:"published"},{label:"Hidden",value:"draft"}],admin:{position:"sidebar"}},{name:"parent",type:"relationship",relationTo:"categories",admin:{position:"sidebar"},filterOptions:({id:a})=>!a||{id:{not_equals:a}}},{name:"featured",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"Show on the homepage category row."}},{name:"sortOrder",type:"number",defaultValue:0,admin:{position:"sidebar",description:"Lower numbers appear first."}},(0,g.I)()]}},57762:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{ao:()=>p});var e=c(61236),f=c(70667),g=c(29918),h=c(98013),i=c(75065),j=c(60346),k=a([h]);h=(k.then?(await k)():k)[0];let l={pending:["confirmed","processing","cancelled"],confirmed:["processing","shipped","cancelled"],processing:["shipped","cancelled"],shipped:["delivered","cancelled"],delivered:[],cancelled:[]},m=()=>!1,n=a=>a.charAt(0).toUpperCase()+a.slice(1),o=async({data:a,originalDoc:b,operation:c,req:d})=>{if("update"!==c||!b)return a;let e=b.status,f=a.status??e,g=b.paymentStatus,i=a.paymentStatus??g;if(f!==e&&!l[e]?.includes(f))throw Error(`An order cannot move from "${n(e)}" to "${n(f)}".`);let j=Array.isArray(b.statusHistory)?[...b.statusHistory]:[];return a.stockRestored=!!b.stockRestored,(f!==e||i!==g)&&j.push({status:f,paymentStatus:i,note:"string"==typeof a.statusNote&&a.statusNote.trim()?a.statusNote.trim():void 0,at:new Date().toISOString(),by:d.user?.email??"system"}),a.statusHistory=j,a.statusNote="","cancelled"!==f||"cancelled"===e||b.stockRestored||(await (0,h.v)(d,b),a.stockRestored=!0),a},p={slug:"orders",labels:{singular:"Order",plural:"Orders"},admin:{useAsTitle:"orderNumber",group:"Sales",defaultColumns:["orderNumber","createdAt","customerName","customerPhone","total","status","paymentStatus","paymentMethod"],listSearchableFields:["orderNumber","customerName","customerPhone","customerEmail"],components:{beforeListTable:["/components/admin/OrdersExport#OrdersExport"]}},defaultSort:"-createdAt",access:{read:e.k3,update:e.k3,create:e.eP,delete:e.qc},endpoints:[i.f,j.N],hooks:{beforeChange:[o]},fields:[{type:"tabs",tabs:[{label:"Order",fields:[{name:"items",type:"array",required:!0,access:{update:m},admin:{readOnly:!0,description:"Snapshot of what was bought, at the price paid. Not affected by later product changes."},fields:[{name:"product",type:"relationship",relationTo:"products"},{name:"productName",type:"text",required:!0},{name:"productNameEn",type:"text"},{name:"variantId",type:"text"},{name:"variantLabel",type:"text"},{name:"sku",type:"text"},(0,f.$)({name:"unitPrice",required:!0}),(0,f.$)({name:"regularPrice"}),{name:"quantity",type:"number",required:!0,min:1},(0,f.$)({name:"lineTotal",required:!0})]},{type:"row",fields:[(0,f.$)({name:"subtotal",required:!0,access:{update:m},admin:{readOnly:!0,width:"25%"}}),(0,f.$)({name:"discount",defaultValue:0,access:{update:m},admin:{readOnly:!0,width:"25%"}}),(0,f.$)({name:"shippingFee",label:"Delivery fee",defaultValue:0,access:{update:m},admin:{readOnly:!0,width:"25%"}}),(0,f.$)({name:"total",required:!0,access:{update:m},admin:{readOnly:!0,width:"25%"}})]},{type:"row",fields:[{name:"couponCode",type:"text",access:{update:m},admin:{readOnly:!0,width:"33%"}},{name:"deliveryMethod",type:"text",access:{update:m},admin:{readOnly:!0,width:"33%"}},{name:"deliveryZone",type:"text",access:{update:m},admin:{readOnly:!0,width:"33%"}}]}]},{label:"Customer & address",fields:[{type:"row",fields:[{name:"customerName",type:"text",required:!0,admin:{width:"34%"}},{name:"customerPhone",type:"text",required:!0,index:!0,admin:{width:"33%"}},{name:"customerEmail",type:"email",admin:{width:"33%"}}]},{type:"row",fields:[{name:"division",type:"text",admin:{width:"33%"}},{name:"district",type:"select",options:g.dn,admin:{width:"33%"}},{name:"area",type:"text",admin:{width:"34%"}}]},{name:"address",type:"textarea",required:!0},{name:"customerNotes",type:"textarea",admin:{readOnly:!0}},{name:"customer",type:"relationship",relationTo:"customers",admin:{readOnly:!0}}]},{label:"History",fields:[{name:"statusHistory",type:"array",admin:{readOnly:!0},fields:[{type:"row",fields:[{name:"status",type:"text",admin:{width:"20%"}},{name:"paymentStatus",type:"text",admin:{width:"20%"}},{name:"at",type:"date",admin:{width:"30%",date:{pickerAppearance:"dayAndTime"}}},{name:"by",type:"text",admin:{width:"30%"}}]},{name:"note",type:"text"}]},{name:"payments",type:"join",collection:"payments",on:"order",admin:{defaultColumns:["provider","status","amount","transactionId","createdAt"]}}]}]},{name:"orderNumber",type:"text",required:!0,unique:!0,index:!0,access:{update:m},admin:{position:"sidebar",readOnly:!0}},{name:"status",label:"Fulfilment status",type:"select",required:!0,defaultValue:"pending",index:!0,options:["pending","confirmed","processing","shipped","delivered","cancelled"].map(a=>({label:n(a),value:a})),admin:{position:"sidebar"}},{name:"paymentStatus",type:"select",required:!0,defaultValue:"unpaid",index:!0,options:["unpaid","pending","paid","failed","refunded","cancelled"].map(a=>({label:n(a),value:a})),admin:{position:"sidebar",description:"Online payments are set automatically after the gateway confirms them server-side."}},{name:"paymentMethod",type:"select",required:!0,options:[{label:"Cash on delivery",value:"cod"},{label:"SSLCommerz",value:"sslcommerz"},{label:"bKash",value:"bkash"},{label:"Nagad",value:"nagad"}],access:{update:m},admin:{position:"sidebar",readOnly:!0}},{name:"statusNote",type:"text",admin:{position:"sidebar",description:"Optional note saved into the history with the next status change."}},{name:"adminNotes",type:"textarea",admin:{position:"sidebar",description:"Internal only."}},{name:"orderActions",type:"ui",admin:{position:"sidebar",components:{Field:"/components/admin/OrderActions#OrderActions"}}},{name:"locale",type:"select",options:["bn","en"],defaultValue:"bn",access:{update:m},admin:{position:"sidebar",readOnly:!0}},{name:"idempotencyKey",type:"text",unique:!0,index:!0,access:{read:()=>!1,update:m},admin:{hidden:!0}},{name:"stockRestored",type:"checkbox",defaultValue:!1,admin:{hidden:!0}}]};d()}catch(a){d(a)}})},60346:(a,b,c)=>{"use strict";c.d(b,{N:()=>h});var d=c(61236),e=c(29918),f=c(37507);let g=a=>String(a??"").replace(/[&<>"']/g,a=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[a]),h={path:"/:id/invoice",method:"get",handler:async a=>{let b;if(!(0,d.hf)(a.user,"admin","manager"))return new Response("Forbidden",{status:403});let c=Number(a.routeParams?.id);if(!Number.isInteger(c))return new Response("Not found",{status:404});try{b=await a.payload.findByID({collection:"orders",id:c,depth:0,req:a,overrideAccess:!1})}catch{return new Response("Not found",{status:404})}let h=await a.payload.findGlobal({slug:"branding",locale:"en",depth:1,req:a}),i=a=>(0,f.$g)(a??0,"en"),j="object"==typeof h.logo&&h.logo?.url?`<img src="${g(h.logo.url)}" alt="" style="height:48px">`:"",k=(b.items??[]).map(a=>`<tr><td>${g(a.productName)}${a.productNameEn&&a.productNameEn!==a.productName?`<br><small>${g(a.productNameEn)}</small>`:""}</td>
        <td>${g(a.variantLabel)}</td><td>${g(a.sku)}</td><td class="n">${a.quantity}</td><td class="n">${i(a.unitPrice)}</td><td class="n">${i(a.lineTotal)}</td></tr>`).join("");return new Response(`<!doctype html><html lang="bn"><head><meta charset="utf-8"><title>Invoice ${g(b.orderNumber)}</title>
<style>
body{font-family:"Hind Siliguri","Noto Sans Bengali",system-ui,sans-serif;color:#243126;max-width:820px;margin:32px auto;padding:0 24px}
h1{font-size:22px;margin:0}table{width:100%;border-collapse:collapse;margin-top:16px}th,td{padding:8px;border-bottom:1px solid #e4dccb;text-align:left;vertical-align:top}
th{background:#f6f0e2;font-weight:600}.n{text-align:right;white-space:nowrap}.grid{display:flex;justify-content:space-between;gap:24px;margin-top:24px}
.tot td{border:none}.tot tr:last-child td{font-weight:700;font-size:18px;border-top:2px solid #243126}small{color:#5b6b5e}
@media print{.noprint{display:none}body{margin:0}}
</style></head><body>
<p class="noprint"><button onclick="window.print()">Print / Save as PDF</button></p>
<div class="grid"><div>${j}<h1>${g(h.brandName)}</h1><small>${g(h.address??"")}<br>${g(h.phone??"")} ${g(h.email??"")}</small></div>
<div style="text-align:right"><h1>Invoice</h1><div>${g(b.orderNumber)}</div><small>${new Date(b.createdAt).toLocaleString("en-GB",{timeZone:"Asia/Dhaka"})}</small></div></div>
<div class="grid"><div><strong>Deliver to</strong><br>${g(b.customerName)}<br>${g(b.customerPhone)}<br>${g(b.address)}<br>${g(b.area)}, ${g(b.district?(0,e.Ce)(b.district,"en"):"")}</div>
<div style="text-align:right"><strong>Payment</strong><br>${g(b.paymentMethod)} — ${g(b.paymentStatus)}<br><strong>Status</strong><br>${g(b.status)}</div></div>
<table><thead><tr><th>Product</th><th>Size</th><th>SKU</th><th class="n">Qty</th><th class="n">Unit</th><th class="n">Total</th></tr></thead><tbody>${k}</tbody></table>
<table class="tot" style="max-width:320px;margin-left:auto"><tr><td>Subtotal</td><td class="n">${i(b.subtotal)}</td></tr>
${b.discount?`<tr><td>Discount ${g(b.couponCode??"")}</td><td class="n">−${i(b.discount)}</td></tr>`:""}
<tr><td>Delivery</td><td class="n">${i(b.shippingFee)}</td></tr><tr><td>Total</td><td class="n">${i(b.total)}</td></tr></table>
${b.customerNotes?`<p><strong>Customer note:</strong> ${g(b.customerNotes)}</p>`:""}
</body></html>`,{headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store","X-Robots-Tag":"noindex"}})}}},61236:(a,b,c)=>{"use strict";function d(a,...b){return!!a&&"users"===a.collection&&(a.roles??[]).some(a=>b.includes(a))}c.d(b,{Xl:()=>f,ZZ:()=>h,eP:()=>i,g8:()=>k,hf:()=>d,k3:()=>g,qc:()=>e,qp:()=>j});let e=({req:a})=>d(a.user,"admin"),f=({req:a})=>d(a.user,"admin","manager","editor"),g=({req:a})=>d(a.user,"admin","manager"),h=()=>!0,i=()=>!1,j=({req:a})=>!!d(a.user,"admin","manager","editor")||{status:{equals:"published"}},k=({req:a})=>d(a.user,"admin")},66946:(a,b,c)=>{"use strict";c.d(b,{AC:()=>o,AF:()=>m,au:()=>k,bQ:()=>n,bZ:()=>l});var d=c(61236),e=c(86806),f=c(75688),g=c(16043),h=c(5003),i=c(74374);let j=(a="published")=>({name:"status",type:"select",required:!0,defaultValue:a,index:!0,options:[{label:"Published",value:"published"},{label:"Hidden (draft)",value:"draft"}],admin:{position:"sidebar"}}),k={slug:"faqs",labels:{singular:"FAQ",plural:"FAQs"},admin:{group:"Content",useAsTitle:"question",defaultColumns:["question","topic","showOnHome","status","translationStatus"]},defaultSort:"sortOrder",access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["question","answer"])]},fields:[{name:"question",type:"text",required:!0,localized:!0,validate:i.E},{name:"answer",type:"textarea",required:!0,localized:!0,validate:i.E},{name:"topic",type:"select",defaultValue:"orders",options:[{label:"Orders",value:"orders"},{label:"Delivery",value:"delivery"},{label:"Packaging",value:"packaging"},{label:"Payment",value:"payment"},{label:"Availability",value:"availability"},{label:"Returns",value:"returns"}],admin:{position:"sidebar"}},{name:"showOnHome",type:"checkbox",defaultValue:!0,admin:{position:"sidebar"}},{name:"sortOrder",type:"number",defaultValue:0,admin:{position:"sidebar"}},j(),(0,g.I)()]},l={slug:"testimonials",labels:{singular:"Customer review",plural:"Customer reviews"},admin:{group:"Content",useAsTitle:"customerName",defaultColumns:["customerName","rating","moderation","consentToPublish","createdAt"],description:"Publish only real reviews from real customers, with their permission."},access:{read:({req:a})=>!!a.user||{and:[{moderation:{equals:"approved"}},{consentToPublish:{equals:!0}}]},create:d.Xl,update:d.Xl,delete:d.Xl},fields:[{name:"customerName",type:"text",required:!0},{name:"location",type:"text",localized:!0,admin:{description:'e.g. "Dhaka" — optional'}},{name:"quote",type:"textarea",required:!0,localized:!0,validate:i.E,admin:{description:"Use the customer’s own words. Translate for the other language if needed."}},{name:"rating",type:"number",min:1,max:5,admin:{description:"1–5, optional. Only enter the rating the customer actually gave."}},{name:"product",type:"relationship",relationTo:"products",admin:{position:"sidebar"}},{name:"order",type:"relationship",relationTo:"orders",admin:{position:"sidebar",description:"Verified purchase (optional)"}},{name:"moderation",type:"select",required:!0,defaultValue:"pending",options:[{label:"Pending review",value:"pending"},{label:"Approved",value:"approved"},{label:"Rejected",value:"rejected"}],admin:{position:"sidebar"}},{name:"consentToPublish",type:"checkbox",defaultValue:!1,admin:{position:"sidebar",description:"The customer agreed to this review being shown."}},{name:"source",type:"text",admin:{position:"sidebar",description:"Where it came from (Facebook comment, WhatsApp, phone call…). Internal."}}]},m={slug:"posts",labels:{singular:"Blog post",plural:"Blog posts"},admin:{group:"Content",useAsTitle:"title",defaultColumns:["title","publishedAt","status","translationStatus"],preview:(a,{locale:b})=>`/${b||"bn"}/blog/${a.slug}?preview=1`},defaultSort:"-publishedAt",access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["title","excerpt"])],afterChange:[(0,h.L)("post")]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"title",type:"text",required:!0,localized:!0,validate:i.E},{name:"excerpt",type:"textarea",localized:!0,maxLength:300},{name:"coverImage",type:"upload",relationTo:"media"},{name:"content",type:"richText",localized:!0}]},{label:"SEO",fields:[(0,e.Z)()]}]},(0,f.O)("title"),j("draft"),{name:"publishedAt",type:"date",admin:{position:"sidebar",date:{pickerAppearance:"dayAndTime"}},defaultValue:()=>new Date().toISOString()},{name:"author",type:"text",admin:{position:"sidebar"}},{name:"relatedProducts",type:"relationship",relationTo:"products",hasMany:!0,admin:{position:"sidebar"}},(0,g.I)()]},n={slug:"pages",labels:{singular:"Page",plural:"Pages & policies"},admin:{group:"Content",useAsTitle:"title",defaultColumns:["title","slug","kind","status","translationStatus"],preview:(a,{locale:b})=>`/${b||"bn"}/pages/${a.slug}?preview=1`},access:{read:d.qp,create:d.Xl,update:d.Xl,delete:d.Xl},hooks:{beforeChange:[(0,g.n)(["title"])],afterChange:[(0,h.L)("page")]},fields:[{type:"tabs",tabs:[{label:"Content",fields:[{name:"title",type:"text",required:!0,localized:!0,validate:i.E},{name:"intro",type:"textarea",localized:!0},{name:"content",type:"richText",localized:!0}]},{label:"SEO",fields:[(0,e.Z)()]}]},(0,f.O)("title"),{name:"kind",type:"select",defaultValue:"info",options:[{label:"Information page",value:"info"},{label:"Policy",value:"policy"}],admin:{position:"sidebar"}},j(),(0,g.I)()]},o={slug:"redirects",labels:{singular:"Redirect",plural:"Redirects"},admin:{group:"Settings",useAsTitle:"fromSlug",defaultColumns:["type","fromSlug","toSlug","automatic"],description:"Old URLs that permanently redirect to new ones. Created automatically when a slug changes."},access:{read:d.ZZ,create:d.Xl,update:d.Xl,delete:d.qc},fields:[{name:"type",type:"select",required:!0,options:[{label:"Product",value:"product"},{label:"Category",value:"category"},{label:"Blog post",value:"post"},{label:"Page",value:"page"}]},{name:"fromSlug",type:"text",required:!0,index:!0},{name:"toSlug",type:"text",required:!0},{name:"automatic",type:"checkbox",defaultValue:!1,admin:{readOnly:!0}}]}},67644:(a,b,c)=>{"use strict";c.d(b,{y:()=>f});var d=c(61236),e=c(70667);let f={slug:"payments",labels:{singular:"Payment",plural:"Payments"},admin:{group:"Sales",useAsTitle:"reference",defaultColumns:["createdAt","order","provider","amount","status","transactionId"]},defaultSort:"-createdAt",access:{read:d.k3,create:d.eP,update:d.eP,delete:d.qc},fields:[{name:"order",type:"relationship",relationTo:"orders",required:!0,index:!0},{name:"reference",type:"text",required:!0,unique:!0,admin:{description:"Our reference sent to the gateway (tran_id / merchantInvoiceNumber / orderId)."}},{name:"provider",type:"select",required:!0,options:[{label:"Cash on delivery",value:"cod"},{label:"SSLCommerz",value:"sslcommerz"},{label:"bKash",value:"bkash"},{label:"Nagad",value:"nagad"}]},(0,e.$)({name:"amount",required:!0}),{name:"currency",type:"text",defaultValue:"BDT"},{name:"status",type:"select",required:!0,defaultValue:"initiated",options:[{label:"Initiated",value:"initiated"},{label:"Succeeded",value:"succeeded"},{label:"Failed",value:"failed"},{label:"Cancelled",value:"cancelled"}]},{name:"transactionId",type:"text",index:!0,admin:{description:"Gateway transaction ID (trxID, val_id/bank_tran_id, issuerPaymentRefNo)."}},{name:"gatewayPaymentId",type:"text",index:!0,admin:{description:"Gateway session/payment ID used for verification."}},{name:"verifiedAt",type:"date"},{name:"failureReason",type:"text"},{name:"gatewayResponse",type:"json",admin:{description:"Verification response from the gateway (no credentials are stored)."}}]}},70667:(a,b,c)=>{"use strict";function d(a){let{admin:b,...c}=a;return{type:"number",min:0,validate:(a,{required:b})=>null==a?!b||"This field is required.":Number.isInteger(a)?!(a<0)||"Amount cannot be negative.":"Amount must be whole poisha (max 2 decimal places in taka).",...c,admin:{...b,components:{Field:"/components/admin/MoneyField#MoneyField",Cell:"/components/admin/MoneyCell#MoneyCell",...b?.components}}}}c.d(b,{$:()=>d})},74374:(a,b,c)=>{"use strict";function d(a,{req:b}){return"bn"!==(b?.locale??"bn")||!!("string"==typeof a?a.trim().length>0:null!=a)||"Required in বাংলা (the default language)."}c.d(b,{E:()=>d})},75065:(a,b,c)=>{"use strict";c.d(b,{f:()=>f});var d=c(61236),e=c(36757);let f={path:"/export.csv",method:"get",handler:async a=>{if(!(0,d.hf)(a.user,"admin","manager"))return Response.json({error:"Forbidden"},{status:403});let b=a.searchParams,c=[],f=b.get("from"),g=b.get("to"),h=b.get("status");f&&/^\d{4}-\d{2}-\d{2}$/.test(f)&&c.push({createdAt:{greater_than_equal:`${f}T00:00:00+06:00`}}),g&&/^\d{4}-\d{2}-\d{2}$/.test(g)&&c.push({createdAt:{less_than_equal:`${g}T23:59:59+06:00`}}),h&&c.push({status:{equals:h}});let i=(await a.payload.find({collection:"orders",where:c.length?{and:c}:void 0,sort:"-createdAt",limit:5e3,depth:0,pagination:!1,req:a,overrideAccess:!1})).docs.map(a=>[a.orderNumber,new Date(a.createdAt).toLocaleString("en-GB",{timeZone:"Asia/Dhaka"}),a.status,a.paymentStatus,a.paymentMethod,a.customerName,a.customerPhone,a.customerEmail??"",a.district??"",a.area??"",a.address,(a.items??[]).map(a=>`${a.sku??""} ${a.productNameEn||a.productName} (${a.variantLabel??""}) x${a.quantity}`).join("; "),(0,e.r$)(a.subtotal),(0,e.r$)(a.discount),(0,e.r$)(a.shippingFee),(0,e.r$)(a.total),a.couponCode??""]);return new Response((0,e.gD)(["Order number","Created (Dhaka)","Status","Payment status","Payment method","Customer","Phone","Email","District","Area","Address","Items","Subtotal (BDT)","Discount (BDT)","Delivery (BDT)","Total (BDT)","Coupon"],i),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":`attachment; filename="orders-${new Date().toISOString().slice(0,10)}.csv"`,"Cache-Control":"no-store"}})}}},75688:(a,b,c)=>{"use strict";function d(a){return a.normalize("NFKD").replace(/[̀-ͯ]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,80)}function e(a="name"){return{name:"slug",type:"text",required:!0,unique:!0,index:!0,admin:{position:"sidebar",description:'URL part, e.g. "himsagar-mango". Lowercase letters, numbers and dashes. Changing it creates a redirect from the old URL.'},validate:a=>a?!!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(a)||"Use lowercase letters, numbers and single dashes only.":"A slug is required.",hooks:{beforeValidate:[({value:b,data:c,req:e})=>{if("string"==typeof b&&b.trim())return d(b);let f=c?.[a],g="string"==typeof f?f:f&&"object"==typeof f?f.en??f[e.locale??"en"]:"";return g?d(String(g)):b}],beforeDuplicate:[({value:a})=>a?`${a}-copy-${Date.now().toString(36)}`:a]}}}c.d(b,{O:()=>e,Y:()=>d})},79251:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{A:()=>F});var e=c(26387),f=c(66599),g=c(47607),h=c(3724),i=c(33873),j=c.n(i),k=c(71656),l=c(42482),m=c(43807),n=c(1932),o=c(54971),p=c(66946),q=c(44731),r=c(14898),s=c(88603),t=c(57762),u=c(67644),v=c(31719),w=c(79905),x=c(40803),y=c(18128),z=c(7773),A=c(14654),B=a([l,m,t,v,w,e]);[l,m,t,v,w,e]=B.then?(await B)():B;let C=(0,n.fileURLToPath)("file:///C:/Users/towfi/Documents/mango-shop/mango-shop/src/payload.config.ts"),D=j().dirname(C),E=[];A._.S3_BUCKET&&E.push((0,h.u)({collections:{media:{prefix:A._.S3_PREFIX||"media"}},bucket:A._.S3_BUCKET,config:{region:A._.S3_REGION||"auto",endpoint:A._.S3_ENDPOINT||void 0,forcePathStyle:A._.S3_FORCE_PATH_STYLE,credentials:{accessKeyId:A._.S3_ACCESS_KEY_ID||"",secretAccessKey:A._.S3_SECRET_ACCESS_KEY||""}}}));let F=(0,k.f)({serverURL:A._.NEXT_PUBLIC_SERVER_URL,secret:A._.PAYLOAD_SECRET,admin:{user:x.z.slug,avatar:"default",meta:{titleSuffix:" — Admin",robots:"noindex, nofollow"},importMap:{baseDir:j().resolve(D)},components:{beforeDashboard:["/components/admin/Dashboard#Dashboard"],graphics:{Logo:"/components/admin/AdminLogo#AdminLogo",Icon:"/components/admin/AdminLogo#AdminIcon"}},dateFormat:"d MMM yyyy, h:mm a"},collections:[v.l,o.L,w.X,t.ao,u.y,r.C,q.S,s.$U,p.au,p.bZ,p.AF,p.bQ,p.AC,x.z],globals:[y.V,z.Me,z.cu,z.Vx,z.CQ,z.Gg,z.sW],localization:{locales:[{code:"bn",label:"বাংলা"},{code:"en",label:"English"}],defaultLocale:"bn",fallback:!0},i18n:{fallbackLanguage:"en"},editor:(0,g.qf)(),typescript:{outputFile:j().resolve(D,"payload-types.ts")},db:(0,e.V8)({pool:{connectionString:A._.DATABASE_URL,max:A._.DATABASE_POOL_MAX},migrationDir:j().resolve(D,"migrations"),push:A._.DATABASE_PUSH,..."true"===process.env.RUN_MIGRATIONS_ON_START?{prodMigrations:m.w}:{}}),email:A._.SMTP_HOST?(0,f.y)({defaultFromAddress:A._.EMAIL_FROM_ADDRESS||"no-reply@example.com",defaultFromName:A._.EMAIL_FROM_NAME||"Shop",transportOptions:{host:A._.SMTP_HOST,port:A._.SMTP_PORT,secure:465===A._.SMTP_PORT,auth:A._.SMTP_USER?{user:A._.SMTP_USER,pass:A._.SMTP_PASS}:void 0}}):void 0,upload:{limits:{fileSize:A._.MAX_UPLOAD_BYTES}},cors:[A._.NEXT_PUBLIC_SERVER_URL],csrf:[A._.NEXT_PUBLIC_SERVER_URL],graphQL:{disable:!0},sharp:l.default,plugins:E,telemetry:!1});d()}catch(a){d(a)}})},79905:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{X:()=>h});var e=c(61236),f=c(84392),g=a([f]);f=(g.then?(await g)():g)[0];let h={slug:"stock-adjustments",labels:{singular:"Stock adjustment",plural:"Stock adjustments"},admin:{group:"Inventory",useAsTitle:"sku",defaultColumns:["createdAt","sku","delta","stockBefore","stockAfter","reason","createdBy"],description:"Add a row to receive new stock or correct a count. Use negative numbers to remove stock."},defaultSort:"-createdAt",access:{read:e.k3,create:e.k3,update:e.eP,delete:e.eP},hooks:{beforeChange:[async({data:a,req:b,operation:c})=>{if("create"!==c||a.systemGenerated)return a;let d=String(a.sku??"").trim().toUpperCase(),e=Number(a.delta);if(!d)throw Error("Enter the SKU of the size/pack to adjust.");if(!Number.isInteger(e)||0===e)throw Error("Change must be a whole number other than 0.");let g=(await b.payload.find({collection:"products",where:{"variants.sku":{equals:d}},limit:1,depth:0,req:b,overrideAccess:!0,locale:"en"})).docs[0],h=g?.variants?.find(a=>a.sku===d);if(!g||!h?.id)throw Error(`No product size with SKU "${d}".`);let i=await (0,f.hP)(b.payload,{productId:g.id,variantId:h.id,delta:e},b);if(!i)throw Error("Could not update stock for this SKU.");return a.sku=d,a.product=g.id,a.variantId=h.id,a.stockBefore=i.before,a.stockAfter=i.after,a.createdBy=b.user?.email??"system",a}],afterChange:[async({doc:a,req:b,operation:c})=>{if("create"===c&&a.product){let c="object"==typeof a.product?a.product.id:a.product;await (0,f.R7)(b.payload,c,b)}return a}]},fields:[{name:"sku",type:"text",required:!0,index:!0,admin:{description:"SKU of the size/pack, e.g. MNG-HIM-5KG"}},{name:"delta",label:"Change (+/−)",type:"number",required:!0},{name:"reason",type:"select",required:!0,defaultValue:"restock",options:[{label:"New stock received",value:"restock"},{label:"Count correction",value:"correction"},{label:"Damaged / spoiled",value:"damage"},{label:"Customer return",value:"return"},{label:"Order placed (automatic)",value:"order"},{label:"Order cancelled (automatic)",value:"order_cancel"}]},{name:"note",type:"textarea"},{name:"product",type:"relationship",relationTo:"products",admin:{readOnly:!0}},{name:"variantId",type:"text",admin:{readOnly:!0,hidden:!0}},{name:"order",type:"relationship",relationTo:"orders",admin:{readOnly:!0}},{name:"stockBefore",type:"number",admin:{readOnly:!0}},{name:"stockAfter",type:"number",admin:{readOnly:!0}},{name:"createdBy",type:"text",admin:{readOnly:!0}},{name:"systemGenerated",type:"checkbox",defaultValue:!1,admin:{hidden:!0},access:{create:()=>!1,update:()=>!1}}]};d()}catch(a){d(a)}})},84392:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{R7:()=>g,SB:()=>f,hP:()=>h});var e=c(5744);async function f(a,b){let c=a.db;if(b?.transactionID){let a=await b.transactionID,d=c.sessions?.[String(a)];if(d?.db)return d.db}return c.drizzle}async function g(a,b,c){let d=await f(a,c);await d.execute((0,e.ll)`
    UPDATE products
       SET total_stock = COALESCE((SELECT SUM(GREATEST(stock, 0)) FROM products_variants WHERE _parent_id = ${Number(b)}), 0)
     WHERE id = ${Number(b)}
  `)}async function h(a,b,c){let d=await f(a,c),g=await d.execute((0,e.ll)`
    WITH prev AS (
      SELECT stock FROM products_variants
       WHERE id = ${b.variantId} AND _parent_id = ${Number(b.productId)}
       FOR UPDATE
    )
    UPDATE products_variants v
       SET stock = GREATEST(0, v.stock + ${b.delta})
      FROM prev
     WHERE v.id = ${b.variantId} AND v._parent_id = ${Number(b.productId)}
    RETURNING prev.stock AS before, v.stock AS after
  `);return g.rows.length?{before:Number(g.rows[0].before),after:Number(g.rows[0].after)}:null}d()}catch(a){d(a)}})},86806:(a,b,c)=>{"use strict";function d(){return{name:"seo",type:"group",label:"SEO",admin:{description:"Optional. Leave empty to use automatic values generated from the title and description."},fields:[{name:"title",type:"text",localized:!0,maxLength:70,admin:{description:"Search result title (≈50–60 characters)."}},{name:"description",type:"textarea",localized:!0,maxLength:200,admin:{description:"Search result snippet (≈140–160 characters)."}},{name:"focusKeyword",type:"text",localized:!0,admin:{description:"For your own reference while writing."}},{name:"ogTitle",label:"Social share title",type:"text",localized:!0},{name:"ogDescription",label:"Social share description",type:"textarea",localized:!0},{name:"ogImage",label:"Social share image",type:"upload",relationTo:"media"},{name:"canonicalUrl",type:"text",admin:{description:"Only if this content officially lives at another URL. Must be an absolute https:// URL."},validate:a=>!!(!a||/^https:\/\/[^\s]+$/.test(a))||"Use an absolute https:// URL or leave empty."},{name:"noindex",type:"checkbox",label:"Hide from search engines (noindex)",defaultValue:!1}]}}c.d(b,{Z:()=>d})},88603:(a,b,c)=>{"use strict";c.d(b,{$U:()=>k});var d=c(55511),e=c.n(d),f=c(33873),g=c.n(f),h=c(61236),i=c(75688);let j=g().resolve(process.env.MEDIA_DIR||g().join(process.cwd(),"media")),k={slug:"media",labels:{singular:"Image",plural:"Media library"},admin:{group:"Content",defaultColumns:["filename","alt","mimeType","filesize","updatedAt"]},access:{read:h.ZZ,create:h.Xl,update:h.Xl,delete:h.Xl},hooks:{beforeOperation:[({req:a,operation:b})=>{let c=a.file;if(("create"===b||"update"===b)&&c?.name){let a=g().extname(c.name).toLowerCase(),b=(0,i.Y)(g().basename(c.name,a))||"image";c.name=`${b.slice(0,40)}-${e().randomBytes(5).toString("hex")}${a}`}}]},upload:{staticDir:j,mimeTypes:["image/jpeg","image/png","image/webp","image/avif","image/svg+xml","image/x-icon","image/vnd.microsoft.icon"],focalPoint:!0,crop:!0,imageSizes:[{name:"thumbnail",width:240,height:240,position:"centre",formatOptions:{format:"webp",options:{quality:78}}},{name:"card",width:640,height:640,position:"centre",formatOptions:{format:"webp",options:{quality:80}}},{name:"large",width:1400,withoutEnlargement:!0,formatOptions:{format:"webp",options:{quality:82}}},{name:"og",width:1200,height:630,position:"centre",formatOptions:{format:"jpeg",options:{quality:82}}}],adminThumbnail:"thumbnail"},fields:[{name:"alt",type:"text",localized:!0,required:!0,admin:{description:"Describe the image for screen readers and search engines, in each language."}},{name:"credit",type:"text",admin:{description:"Photographer / licence note (internal)."}}]}},98013:(a,b,c)=>{"use strict";c.a(a,async(a,d)=>{try{c.d(b,{v:()=>g});var e=c(84392),f=a([e]);async function g(a,b){let c=new Set;for(let d of b.items??[]){let f="object"==typeof d.product&&d.product?d.product.id:d.product;if(!f||!d.variantId)continue;let g=await (0,e.hP)(a.payload,{productId:f,variantId:d.variantId,delta:d.quantity},a);g&&(c.add(Number(f)),await a.payload.create({collection:"stock-adjustments",req:a,overrideAccess:!0,data:{sku:d.sku??"",delta:d.quantity,reason:"order_cancel",product:Number(f),variantId:d.variantId,order:b.id,stockBefore:g.before,stockAfter:g.after,createdBy:a.user?.email??"system",systemGenerated:!0,note:`Cancelled ${b.orderNumber}`}}))}for(let b of c)await (0,e.R7)(a.payload,b,a)}e=(f.then?(await f)():f)[0],d()}catch(a){d(a)}})},99224:(a,b,c)=>{"use strict";c.d(b,{Yu:()=>i,dE:()=>k});var d=c(61236),e=c(75688),f=c(36757),g=c(28964);let h=["sku","product_slug","status","name_bn","name_en","short_bn","short_en","size_bn","size_en","categories","price_bdt","sale_price_bdt","stock","featured"],i={path:"/export.csv",method:"get",handler:async a=>{if(!(0,d.hf)(a.user,"admin","manager","editor"))return Response.json({error:"Forbidden"},{status:403});let b=await (0,g.N)(a,()=>a.payload.find({collection:"products",locale:"all",depth:1,limit:5e3,pagination:!1,req:a,overrideAccess:!0})),c=[];for(let a of b.docs){let b=a.categories.map(a=>"object"==typeof a?a.slug:a).join("|");for(let d of a.variants??[])c.push([d.sku,a.slug,a.status,a.name?.bn??"",a.name?.en??"",a.shortDescription?.bn??"",a.shortDescription?.en??"",d.label?.bn??"",d.label?.en??"",b,(0,f.r$)(d.price),(0,f.r$)(d.salePrice),d.stock??0,a.featured?"yes":"no"])}return new Response((0,f.gD)([...h],c),{headers:{"Content-Type":"text/csv; charset=utf-8","Content-Disposition":`attachment; filename="products-${new Date().toISOString().slice(0,10)}.csv"`,"Cache-Control":"no-store"}})}},j=a=>{let b=a.trim().replace(/,/g,"");if(!b)return null;if(!/^\d+(\.\d{1,2})?$/.test(b))return"invalid";let[c,d=""]=b.split(".");return 100*Number(c)+Number(d.padEnd(2,"0"))},k={path:"/import",method:"post",handler:async a=>{if(!(0,d.hf)(a.user,"admin","manager"))return Response.json({error:"Forbidden"},{status:403});let b=await a.formData?.().catch(()=>null),c=b?.get("file");if(!c||"string"==typeof c)return Response.json({error:'Attach a CSV file in the "file" field.'},{status:400});if(c.size>2097152)return Response.json({error:"CSV is larger than 2 MB."},{status:400});let g=(0,f.Wk)(await c.text()),h=g.shift()?.map(a=>a.trim().toLowerCase())??[],i=["sku","product_slug","name_bn","price_bdt"].filter(a=>!h.includes(a));if(i.length)return Response.json({error:`Missing columns: ${i.join(", ")}`},{status:400});if(g.length>2e3)return Response.json({error:"At most 2000 rows per import."},{status:400});let k=new Map((await a.payload.find({collection:"categories",limit:500,depth:0,pagination:!1,req:a,overrideAccess:!0})).docs.map(a=>[a.slug,a.id])),l=0,m=0,n=[];for(let[b,c]of g.entries()){let d=a=>(c[h.indexOf(a)]??"").trim(),f=b+2;try{let b=d("sku").toUpperCase(),c=(0,e.Y)(d("product_slug")),f=j(d("price_bdt")),g=j(d("sale_price_bdt"));if(!b||!c)throw Error("sku and product_slug are required");if("invalid"===f||null===f||"invalid"===g)throw Error("invalid price");let h=d("categories").split("|").map(a=>k.get(a.trim())).filter(a=>"number"==typeof a),i="published"===d("status")?"published":"draft"===d("status")?"draft":void 0,n=d("featured")?["yes","true","1"].includes(d("featured").toLowerCase()):void 0,o=Math.max(0,Math.floor(Number(d("stock"))||0)),p=await a.payload.find({collection:"products",where:{"variants.sku":{equals:b}},limit:1,depth:0,req:a,overrideAccess:!0,locale:"bn"}),q=p.docs[0]?null:await a.payload.find({collection:"products",where:{slug:{equals:c}},limit:1,depth:0,req:a,overrideAccess:!0,locale:"bn"}),r=p.docs[0]??q?.docs[0];if(!r){if(!h.length)throw Error("new products need at least one valid category slug");let e=await a.payload.create({collection:"products",locale:"bn",req:a,overrideAccess:!0,data:{name:d("name_bn")||d("name_en"),shortDescription:d("short_bn")||void 0,slug:c,status:i??"draft",featured:n??!1,categories:h,variants:[{label:d("size_bn")||d("size_en")||"১টি",sku:b,price:f,salePrice:g??void 0,stock:o}]}});d("name_en")&&await a.payload.update({collection:"products",id:e.id,locale:"en",req:a,overrideAccess:!0,data:{name:d("name_en"),shortDescription:d("short_en")||void 0,variants:(e.variants??[]).map(a=>({...a,label:d("size_en")||a.label}))}}),l++;continue}let s=(r.variants??[]).map(({stock:a,...b})=>({...b})),t=s.find(a=>a.sku===b);if(t?(t.price=f,t.salePrice=g??null,d("size_bn")&&(t.label=d("size_bn"))):s.push({label:d("size_bn")||d("size_en")||b,sku:b,price:f,salePrice:g??null,stock:o}),await a.payload.update({collection:"products",id:r.id,locale:"bn",req:a,overrideAccess:!0,data:{...d("name_bn")?{name:d("name_bn")}:{},...d("short_bn")?{shortDescription:d("short_bn")}:{},...i?{status:i}:{},...void 0!==n?{featured:n}:{},...h.length?{categories:h}:{},variants:s}}),d("name_en")||d("short_en")||d("size_en")){let c=await a.payload.findByID({collection:"products",id:r.id,locale:"en",depth:0,req:a,overrideAccess:!0});await a.payload.update({collection:"products",id:r.id,locale:"en",req:a,overrideAccess:!0,data:{...d("name_en")?{name:d("name_en")}:{},...d("short_en")?{shortDescription:d("short_en")}:{},variants:(c.variants??[]).map(({stock:a,...c})=>c.sku===b&&d("size_en")?{...c,label:d("size_en")}:c)}})}m++}catch(a){n.push(`row ${f}: ${a instanceof Error?a.message:"error"}`)}}return Response.json({created:l,updated:m,errors:n})}}}};